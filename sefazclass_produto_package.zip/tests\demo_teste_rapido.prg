#include "sefazclass.ch"

PROCEDURE Main()
   LOCAL oSefaz := SefazClass():New()
   LOCAL cIni := IIf( hb_ArgC() >= 1, hb_ArgV( 1 ), "sefaz.ini" )
   LOCAL hCert

   ? "SEFAZClass - teste rapido"
   ? "INI:", cIni
   ?

   IF ! File( cIni )
      ? "Arquivo INI nao encontrado."
      ? "Copie tests\\sefaz.ini.example para sefaz.ini e ajuste certificado/UF/ambiente."
      RETURN
   ENDIF

   oSefaz:LoadConfigIni( cIni )

   hCert := oSefaz:ValidarCertificado()
   ? "Certificado OK:", hCert[ "ok" ]
   ? "Motivo........:", hCert[ "motivo" ]
   ? "UF............:", oSefaz:cUF
   ? "Ambiente......:", oSefaz:cAmbiente
   ? "Transporte....:", oSefaz:cTransportePreferido
   ?

   IF ! hCert[ "ok" ]
      ? oSefaz:Diagnostico()
      RETURN
   ENDIF

   TestaStatus( oSefaz, "NFE" )
   TestaStatus( oSefaz, "CTE" )
   TestaStatus( oSefaz, "MDFE" )

   ?
   ? "Diagnostico final:"
   ? oSefaz:Diagnostico()
RETURN

STATIC PROCEDURE TestaStatus( oSefaz, cDoc )
   LOCAL cRet := ""
   LOCAL cFile := "ret_" + Lower( cDoc ) + "_status.xml"

   ? "Consultando status", cDoc + "..."

   DO CASE
   CASE cDoc == "NFE"
      cRet := oSefaz:NFeStatus( oSefaz:cUF, oSefaz:cCertificado, oSefaz:cAmbiente )
   CASE cDoc == "CTE"
      cRet := oSefaz:CTeStatus( oSefaz:cUF, oSefaz:cCertificado, oSefaz:cAmbiente )
   CASE cDoc == "MDFE"
      cRet := oSefaz:MDFeStatus( oSefaz:cUF, oSefaz:cCertificado, oSefaz:cAmbiente )
   ENDCASE

   hb_MemoWrit( cFile, cRet )

   ? "  Status.....:", oSefaz:cStatus
   ? "  Motivo.....:", oSefaz:cMotivo
   ? "  Transporte.:", oSefaz:cUltimoTransporte
   ? "  HTTP.......:", oSefaz:nWinHttpStatus
   ? "  Arquivo....:", cFile
   ?
RETURN


#include "sefazclass.ch"

PROCEDURE Main()
   LOCAL oSefaz := SefazClass():New()

   ? "Demo de configuracao WinHTTP nativo para transporte SOAP."
   ? "Este demo nao envia para a SEFAZ; serve como modelo de uso."
   ?
   ? "A1 PFX/P12 sem instalar no Windows:"
   ? '  oSefaz:CertificadoPfx( "C:\certificados\empresa.pfx", "senha" )'
   ? '  oSefaz:UseWinHttp( .T., "C:\certificados\empresa.pfx", "senha" )'
   ?
   ? "A3 ou certificado ja instalado no CurrentUser\\MY:"
   ? '  oSefaz:cCertificado := "NOME OU THUMBPRINT DO CERTIFICADO"'
   ? '  oSefaz:UseWinHttp( .T. )'
   ?

   oSefaz:UseWinHttp( .T., "C:\certificados\empresa.pfx", "senha" )

   ? "lUseWinHttp.....:", oSefaz:lUseWinHttp
   ? "cCertificado....:", oSefaz:cCertificado
   ? "nWinHttpStatus..:", oSefaz:nWinHttpStatus
   ? "cWinHttpLastErr.:", oSefaz:cWinHttpLastError
RETURN

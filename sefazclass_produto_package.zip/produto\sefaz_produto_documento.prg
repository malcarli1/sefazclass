#include "hbclass.ch"

CREATE CLASS TSefazProdutoDocumento

   DATA oProduto
   DATA cDoc

   METHOD New( oProduto, cDoc )
   METHOD Status()
   METHOD Enviar( cXml )
   METHOD RetEnvio( cRecibo )
   METHOD Protocolo( cChave )
   METHOD Inutilizar( ... )
   METHOD Evento( ... )
   METHOD Cancelar( ... )
   METHOD CartaCorrecao( ... )
   METHOD AddCancelamento( ... )
   METHOD GeraAutorizado( ... )
   METHOD GeraEventoAutorizado( ... )
   METHOD Distribuicao( ... )
   METHOD Cadastro( ... )
   METHOD Manifestacao( ... )
   METHOD GTIN( ... )
   METHOD EmAberto( ... )
   METHOD Contingencia( ... )
   METHOD Destinadas( ... )
   METHOD Download( ... )
   METHOD AutorizarXml( ... )
   METHOD CancelarSubstituicao( ... )
   METHOD DataEntrega( ... )
   METHOD Entrega( ... )
   METHOD InsucessoEntrega( ... )
   METHOD CancelarEntrega( ... )
   METHOD CancelarInsucessoEntrega( ... )
   METHOD Desacordo( ... )
   METHOD Encerramento( ... )
   METHOD Condutor( ... )
   METHOD Pagamento( ... )
   METHOD Call( cMetodo, aParams )

ENDCLASS

METHOD New( oProduto, cDoc ) CLASS TSefazProdutoDocumento
   ::oProduto := oProduto
   ::cDoc     := cDoc
RETURN Self

METHOD Status() CLASS TSefazProdutoDocumento
RETURN ::Call( ::cDoc + "Status", { ::oProduto:oBase:cUF, ::oProduto:oBase:cCertificado, ::oProduto:oBase:cAmbiente } )

METHOD Enviar( cXml ) CLASS TSefazProdutoDocumento
RETURN ::Call( ::cDoc + "Envio", { cXml } )

METHOD RetEnvio( cRecibo ) CLASS TSefazProdutoDocumento
RETURN ::Call( ::cDoc + "RetEnvio", { cRecibo } )

METHOD Protocolo( cChave ) CLASS TSefazProdutoDocumento
RETURN ::Call( ::cDoc + "Protocolo", { cChave } )

METHOD Inutilizar( ... ) CLASS TSefazProdutoDocumento
RETURN ::Call( ::cDoc + "Inutiliza", hb_AParams() )

METHOD Evento( ... ) CLASS TSefazProdutoDocumento
RETURN ::Call( ::cDoc + "Evento", hb_AParams() )

METHOD Cancelar( ... ) CLASS TSefazProdutoDocumento
RETURN ::Call( ::cDoc + "EventoCancela", hb_AParams() )

METHOD CartaCorrecao( ... ) CLASS TSefazProdutoDocumento
RETURN ::Call( ::cDoc + "EventoCarta", hb_AParams() )

METHOD AddCancelamento( ... ) CLASS TSefazProdutoDocumento
RETURN ::Call( ::cDoc + "AddCancelamento", hb_AParams() )

METHOD GeraAutorizado( ... ) CLASS TSefazProdutoDocumento
RETURN ::Call( ::cDoc + "GeraAutorizado", hb_AParams() )

METHOD GeraEventoAutorizado( ... ) CLASS TSefazProdutoDocumento
RETURN ::Call( ::cDoc + "GeraEventoAutorizado", hb_AParams() )

METHOD Distribuicao( ... ) CLASS TSefazProdutoDocumento
RETURN ::Call( ::cDoc + "Distribuicao", hb_AParams() )

METHOD Cadastro( ... ) CLASS TSefazProdutoDocumento
RETURN ::Call( ::cDoc + "Cadastro", hb_AParams() )

METHOD Manifestacao( ... ) CLASS TSefazProdutoDocumento
RETURN ::Call( ::cDoc + "EventoManifestacao", hb_AParams() )

METHOD GTIN( ... ) CLASS TSefazProdutoDocumento
RETURN ::Call( ::cDoc + "GTIN", hb_AParams() )

METHOD EmAberto( ... ) CLASS TSefazProdutoDocumento
RETURN ::Call( ::cDoc + "EmAberto", hb_AParams() )

METHOD Contingencia( ... ) CLASS TSefazProdutoDocumento
RETURN ::Call( ::cDoc + "Contingencia", hb_AParams() )

METHOD Destinadas( ... ) CLASS TSefazProdutoDocumento
RETURN ::Call( ::cDoc + "Destinadas", hb_AParams() )

METHOD Download( ... ) CLASS TSefazProdutoDocumento
RETURN ::Call( ::cDoc + "Download", hb_AParams() )

METHOD AutorizarXml( ... ) CLASS TSefazProdutoDocumento
RETURN ::Call( ::cDoc + "EventoAutor", hb_AParams() )

METHOD CancelarSubstituicao( ... ) CLASS TSefazProdutoDocumento
RETURN ::Call( ::cDoc + "EventoCancelaSubstituicao", hb_AParams() )

METHOD DataEntrega( ... ) CLASS TSefazProdutoDocumento
RETURN ::Call( ::cDoc + "EventoDataEntrega", hb_AParams() )

METHOD Entrega( ... ) CLASS TSefazProdutoDocumento
RETURN ::Call( ::cDoc + "EventoEntrega", hb_AParams() )

METHOD InsucessoEntrega( ... ) CLASS TSefazProdutoDocumento
RETURN ::Call( ::cDoc + "EventoInsucessoEntrega", hb_AParams() )

METHOD CancelarEntrega( ... ) CLASS TSefazProdutoDocumento
RETURN ::Call( ::cDoc + "EventoCancEntrega", hb_AParams() )

METHOD CancelarInsucessoEntrega( ... ) CLASS TSefazProdutoDocumento
RETURN ::Call( ::cDoc + "EventoCancInsucessoEntrega", hb_AParams() )

METHOD Desacordo( ... ) CLASS TSefazProdutoDocumento
RETURN ::Call( ::cDoc + "EventoDesacordo", hb_AParams() )

METHOD Encerramento( ... ) CLASS TSefazProdutoDocumento
RETURN ::Call( ::cDoc + "EventoEncerramento", hb_AParams() )

METHOD Condutor( ... ) CLASS TSefazProdutoDocumento
RETURN ::Call( ::cDoc + "EventoCondutor", hb_AParams() )

METHOD Pagamento( ... ) CLASS TSefazProdutoDocumento
RETURN ::Call( ::cDoc + "EventoPagamento", hb_AParams() )

METHOD Call( cMetodo, aParams ) CLASS TSefazProdutoDocumento
RETURN ::oProduto:Call( cMetodo, aParams, ::cDoc + "." + cMetodo )

# Manual rapido - SefazClass Core

Este pacote foi preparado para uso sem CAPICOM real. A assinatura usa APIs nativas do Windows e o transporte pode usar MSXML, WinHTTP nativo ou curl.

## Compilacao

Com Borland/Harbour:

```bat
set PATH=C:\xbase\bcc582\Bin;C:\xbase\harbour_1608\bin;%PATH%
set HB_COMPILER=bcc
hbmk2 -comp=bcc sefazclass_core.hbp
```

O resultado principal fica em:

- `lib\sefazclass_core.lib`
- `lib\sefazclass_core.hbx`

## Configuracao por INI

Copie `tests\sefaz.ini.example` para `sefaz.ini` e ajuste:

```ini
[certificado]
tipo=A1
pfx=C:\certificados\empresa.pfx
senha=123456
nome=

[sefaz]
ambiente=2
uf=SP
transporte=AUTO
fallback=1
debug=1
logdir=C:\logs\sefaz
```

Uso no Harbour:

```harbour
oSefaz := SefazClass():New()
oSefaz:LoadConfigIni( "sefaz.ini" )
```

## Certificado A1

Para PFX/P12 direto do arquivo:

```harbour
oSefaz:SetCertificadoA1( "C:\certificados\empresa.pfx", "senha" )
```

O PFX e importado em memoria para uso temporario; nao instala o certificado no `CurrentUser\MY`.

## Certificado A3

Para certificado instalado/token/cartao:

```harbour
oSefaz:SetCertificadoA3( "NOME OU THUMBPRINT" )
```

O A3 depende do driver do fornecedor expor a chave privada via CSP/CNG no Windows. A janela de PIN e controlada pelo driver do token/cartao.

## Transporte

Opcoes:

```harbour
oSefaz:SetTransporte( "AUTO", .T. )
oSefaz:SetTransporte( "WINHTTP", .T. )
oSefaz:SetTransporte( "MSXML", .T. )
oSefaz:SetTransporte( "CURL", .T. )
```

`AUTO` tenta o transporte nativo e usa fallback somente em erro de comunicacao/TLS/transporte. Rejeicao fiscal da SEFAZ nao deve cair para outro transporte.

## Demos de status

Os demos abaixo fazem chamada real de status de servico, desde que o certificado e ambiente estejam corretos no INI:

```bat
tests\demo_nfe_status.exe sefaz.ini
tests\demo_cte_status.exe sefaz.ini
tests\demo_mdfe_status.exe sefaz.ini
```

Eles gravam os retornos:

- `ret_nfe_status.xml`
- `ret_cte_status.xml`
- `ret_mdfe_status.xml`

## Diagnostico

```bat
tests\demo_diagnostico.exe sefaz.ini
```

O diagnostico mostra certificado, transporte, ambiente, ultimo erro e ultimo status HTTP.


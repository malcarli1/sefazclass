PROCEDURE Main()

   LOCAL cXml, cHtmlFile := "danfe_simplificado.html", cTxtFile := "danfe_simplificado.txt"

   IF hb_ArgC() >= 1
      cXml := hb_ArgV( 1 )
   ELSE
      ? "Informe o XML autorizado nfeProc/NFe."
      ? "Exemplo: demo_danfe_simplificado_html.exe nfe_autorizada.xml"
      RETURN
   ENDIF

   SefazDanfeSimplificadoSalvarHtml( cXml, cHtmlFile )
   hb_MemoWrit( cTxtFile, SefazDanfeSimplificadoTexto( cXml ) )

   ? "HTML gerado:", cHtmlFile
   ? "Texto gerado:", cTxtFile
RETURN


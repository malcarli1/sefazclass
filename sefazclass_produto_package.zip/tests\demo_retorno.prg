#include "sefazclass.ch"

PROCEDURE Main()
   LOCAL hRet, hEvt, nI

   IF hb_ArgC() < 1
      ? "Uso: demo_retorno retorno.xml"
      RETURN
   ENDIF

   hRet := SefazRetornoParse( hb_MemoRead( hb_ArgV( 1 ) ) )

   ? "Tipo.....:", hRet[ "tipo" ]
   ? "Status...:", hRet[ "status" ]
   ? "ErroCod..:", hRet[ "codigoErro" ]
   ? "Motivo...:", hRet[ "motivo" ]
   ? "OK.......:", hRet[ "ok" ]
   ? "Recibo...:", hRet[ "recibo" ]
   ? "Protocolo:", hRet[ "protocolo" ]
   ? "Chave....:", hRet[ "chave" ]
   ? "Eventos..:", hRet[ "eventCount" ]

   FOR nI := 1 TO hRet[ "eventCount" ]
      hEvt := SefazRetornoEvento( hRet, nI )
      ? ""
      ? "Evento", nI
      ? "  Tipo.....:", hEvt[ "tipo" ]
      ? "  Status...:", hEvt[ "status" ]
      ? "  Motivo...:", hEvt[ "motivo" ]
      ? "  OK.......:", hEvt[ "ok" ]
      ? "  Chave....:", hEvt[ "chave" ]
      ? "  Protocolo:", hEvt[ "protocolo" ]
      ? "  TpEvento.:", hEvt[ "tpEvento" ]
   NEXT

   ? ""
   ? SefazRetornoResumo( hRet )
RETURN

# Changelog core

## 2026-06-06

- Assinatura SHA1 para NFe/NFCe/CTe/MDFe/BPe usando CryptoAPI/CNG nativo do Windows.
- Compatibilidade publica com chamadas antigas de CAPICOM, sem instanciar CAPICOM real.
- Leitura de certificado A1 PFX/P12 em memoria, sem instalar no store do usuario.
- Suporte a A3 pelo store `CurrentUser\MY`, desde que o driver exponha CSP/CNG.
- Transporte WinHTTP nativo com certificado cliente.
- Transporte curl opcional.
- Fallback automatico controlado entre transportes.
- Parser de retorno por lote e por evento.
- Diagnostico de certificado, ambiente, transporte e ultimo erro.
- Carregamento de configuracao por INI.
- Demos para status NFe, CTe e MDFe.
- Pacote core sem PDF/DANFE para evitar dependencias de hbhpdf/hbzebra/harupdf.


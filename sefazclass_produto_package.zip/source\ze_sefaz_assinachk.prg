/*
ZE_SPEDSSINACHK - Checagem de assinatura sem CAPICOM.          
Mantem MSXML2.MXDigitalSignature.5.0 para validacao XMLDSig.   
*/

#define DSIGNS "xmlns:ds='http://www.w3.org/2000/09/xmldsig#'"

FUNCTION ChkSignature( cXml, cCertificadoCN )

   LOCAL XmlDoc, XmlDSig, cXmlRetorno := "Undefined Error"
   LOCAL oKeyInfo, oPubKey, oVerifiedKey, oSignature

   BEGIN SEQUENCE WITH __BreakBlock()

      XmlDoc  := win_OleCreateObject( "MSXML2.DOMDocument.5.0" )
      XmlDSig := win_OleCreateObject( "MSXML2.MXDigitalSignature.5.0" )

      XmlDoc:Async              := .F.
      XmlDoc:PreserveWhiteSpace := .T.
      XmlDoc:ValidateOnParse    := .F.
      XmlDoc:ResolveExternals   := .F.

      IF ! XmlDoc:LoadXml( cXml )
         cXmlRetorno := iif( cXmlRetorno == Nil, "", "Cannot load file. reason " + XmlDoc:ParseError:Reason )
         BREAK
      ENDIF
      XmlDoc:SetProperty( "SelectionNamespaces", DSIGNS )
      oSignature := XmlDoc:SelectSingleNode( ".//ds:Signature" )
      IF oSignature == NIL
         cXmlRetorno := "Not Found Signature"
         BREAK
      ENDIF
      XmlDSig:Signature := oSignature
      oKeyInfo := XmlDoc:selectSingleNode( ".//ds:KeyInfo/ds:X509Data" )
      IF oKeyInfo == NIL
         cXmlRetorno := iif( cXmlRetorno == Nil, "", "Invalid <KeyInfo> Element" )
         BREAK
      ENDIF
      oPubKey := XmlDSig:CreateKeyFromNode( oKeyInfo )
      IF oPubKey == NIL
         cXmlRetorno := iif( cXmlRetorno == Nil, "", "Cannot generate public key for verification" )
         BREAK
      ENDIF
      cXmlRetorno := iif( cXmlRetorno == Nil, "", "Invalid Signature" )
      oVerifiedKey := XmlDSig:Verify( oPubKey )
      IF oVerifiedKey == NIL
         cXmlRetorno := "Signature not verified"
         BREAK
      ENDIF
      cXmlRetorno := iif( cXmlRetorno == Nil, "", "OK" )

   ENDSEQUENCE

   HB_SYMBOL_UNUSED( cCertificadoCN )
RETURN cXmlRetorno
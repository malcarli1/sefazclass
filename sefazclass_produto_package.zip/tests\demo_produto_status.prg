PROCEDURE Main()

   LOCAL oSefaz := TSefazProduto():New()
   LOCAL cIni := IIf( hb_ArgC() >= 1, hb_ArgV( 1 ), "sefaz.ini" )
   LOCAL hRet

   IF ! File( cIni )
      ? "Arquivo INI nao encontrado:", cIni
      ? "Copie sefaz.ini.example para sefaz.ini e ajuste certificado/UF/ambiente."
      RETURN
   ENDIF

   oSefaz:LoadConfigIni( cIni )
   hRet := oSefaz:NFe():Status()

   hb_MemoWrit( "produto_ret_nfe_status.xml", hRet[ "xml" ] )

   ? "OK.........:", hRet[ "ok" ]
   ? "Status.....:", hRet[ "status" ]
   ? "Motivo.....:", hRet[ "motivo" ]
   ? "Transporte.:", hRet[ "transporte" ]
   ? "XML salvo..: produto_ret_nfe_status.xml"
RETURN


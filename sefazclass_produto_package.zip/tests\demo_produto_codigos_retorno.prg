PROCEDURE Main()

   LOCAL cXml, hRet
   LOCAL cCnpjAlfa := "12ABC34501DE35"
   LOCAL cChaveAlfa := "35260612ABC34501DE35550020000000111000000102"
   LOCAL cOut := ""

   cOut += "NFe 100: " + SefazRetornoCodigoDescricao( "NFE", 100 ) + hb_Eol()
   cOut += "CTe 100: " + SefazRetornoCodigoDescricao( "CTE", 100 ) + hb_Eol()
   cOut += "NFe 201: " + SefazRetornoCodigoDescricao( "NFE", 201 ) + hb_Eol()
   cOut += "CNPJ alfa valido: " + IIf( ValidCnpj( cCnpjAlfa ), "SIM", "NAO" ) + " " + FormatCnpj( cCnpjAlfa ) + hb_Eol()
   cOut += "Chave alfa: " + SefazDanfeFormatChave( cChaveAlfa ) + hb_Eol()
   ? "NFe 100:", SefazRetornoCodigoDescricao( "NFE", 100 )
   ? "CTe 100:", SefazRetornoCodigoDescricao( "CTE", 100 )
   ? "NFe 201:", SefazRetornoCodigoDescricao( "NFE", 201 )
   ? "CNPJ alfa valido:", ValidCnpj( cCnpjAlfa ), FormatCnpj( cCnpjAlfa )
   ? "Chave alfa.....:", SefazDanfeFormatChave( cChaveAlfa )

   cXml := '<retConsSitNFe><cStat>201</cStat><xMotivo></xMotivo></retConsSitNFe>'
   hRet := SefazRetornoParse( cXml )

   ? "Documento....:", hRet[ "documento" ]
   ? "Codigo real..:", hRet[ "codigoReal" ]
   ? "Motivo tabela:", hRet[ "motivoTabela" ]
   ? "Motivo final.:", hRet[ "motivo" ]
   cOut += "Documento: " + hRet[ "documento" ] + hb_Eol()
   cOut += "Codigo real: " + hRet[ "codigoReal" ] + hb_Eol()
   cOut += "Motivo tabela: " + hRet[ "motivoTabela" ] + hb_Eol()
   cOut += "Motivo final: " + hRet[ "motivo" ] + hb_Eol()
   hb_MemoWrit( "produto_codigos_retorno.out", cOut )

RETURN

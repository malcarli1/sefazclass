#include "sefazclass.ch"

PROCEDURE Main()
   LOCAL oSefaz := SefazClass():New()
   LOCAL hCert

   ? "Demo diagnostico SEFAZClass."
   ? "Este demo nao envia para a SEFAZ."
   ?

   oSefaz:SetTransporte( "AUTO", .T. )
   oSefaz:SetDebug( .T., "logs" )
   oSefaz:SetCertificadoA3( "NOME OU THUMBPRINT DO CERTIFICADO" )

   hCert := oSefaz:ValidarCertificado()
   ? "Certificado OK:", hCert[ "ok" ]
   ? "Motivo........:", hCert[ "motivo" ]
   ?
   ? oSefaz:Diagnostico()
RETURN

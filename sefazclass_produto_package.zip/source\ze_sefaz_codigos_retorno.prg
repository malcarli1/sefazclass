#include "fileio.ch"

FUNCTION SefazRetornoCodigoDescricao( cDocumento, nCodigo )

   LOCAL hTabela := SefazRetornoCodigoTabela( cDocumento )
   LOCAL cCodigo := AllTrim( IIf( ValType( nCodigo ) == "N", Str( nCodigo ), hb_DefaultValue( nCodigo, "" ) ) )

   IF ValType( hTabela ) == "H" .AND. hb_HHasKey( hTabela, cCodigo )
      RETURN hTabela[ cCodigo ]
   ENDIF

RETURN ""

FUNCTION SefazRetornoCodigoTabela( cDocumento )

   STATIC hCache
   LOCAL cDoc := Upper( AllTrim( hb_DefaultValue( cDocumento, "" ) ) )
   LOCAL cFile, hTabela

   IF hCache == NIL
      hCache := hb_Hash()
   ENDIF

   DO CASE
   CASE "CTE" $ cDoc
      cDoc := "CTE"
   CASE "NFE" $ cDoc .OR. "NFCE" $ cDoc
      cDoc := "NFE"
   OTHERWISE
      cDoc := "NFE"
   ENDCASE

   IF hb_HHasKey( hCache, cDoc )
      RETURN hCache[ cDoc ]
   ENDIF

   cFile := SefazRetornoCodigoArquivo( cDoc )
   hTabela := SefazRetornoCodigoLoad( cFile )
   hCache[ cDoc ] := hTabela

RETURN hTabela

FUNCTION SefazRetornoCodigoArquivo( cDocumento )

   LOCAL cNome := "codigos-retorno-" + Lower( cDocumento ) + ".txt"
   LOCAL aDirs := { "", ".\", "..\", "..\..\", hb_DirBase(), hb_DirBase() + "..\" }
   LOCAL cDir, cFile

   FOR EACH cDir IN aDirs
      cFile := cDir + cNome
      IF File( cFile )
         RETURN cFile
      ENDIF
   NEXT

RETURN cNome

STATIC FUNCTION SefazRetornoCodigoLoad( cFile )

   LOCAL hTabela := hb_Hash()
   LOCAL cTxt, aLines, cLine, nPos, cCodigo, cTexto

   IF Empty( cFile ) .OR. ! File( cFile )
      RETURN hTabela
   ENDIF

   cTxt := hb_MemoRead( cFile )
   cTxt := StrTran( cTxt, Chr( 13 ), "" )
   aLines := hb_ATokens( cTxt, Chr( 10 ) )

   FOR EACH cLine IN aLines
      cLine := AllTrim( cLine )
      IF Empty( cLine ) .OR. Left( cLine, 1 ) == "#"
         LOOP
      ENDIF
      nPos := At( "|", cLine )
      IF nPos <= 1
         LOOP
      ENDIF
      cCodigo := AllTrim( Left( cLine, nPos - 1 ) )
      cTexto  := AllTrim( SubStr( cLine, nPos + 1 ) )
      IF ! Empty( cCodigo ) .AND. ! Empty( cTexto )
         hTabela[ cCodigo ] := cTexto
      ENDIF
   NEXT

RETURN hTabela

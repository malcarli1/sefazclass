/*
DANFE simplificado em formato etiqueta.
Gera HTML para visualizacao/impressao interna, sem PDF e sem componente externo.
*/

FUNCTION SefazDanfeSimplificadoHtml( cXmlOuArquivo, cLogoHtml )

   LOCAL h := SefazDanfeSimplificadoDados( cXmlOuArquivo )
   LOCAL cLogo := hb_DefaultValue( cLogoHtml, "" )

   IF ! h[ "ok" ]
      RETURN '<div style="font-family:Arial;color:#900">DANFE simplificado: ' + ;
         SefazDanfeHtmlEscape( h[ "erro" ] ) + '</div>'
   ENDIF

RETURN ;
   '<!doctype html>' + hb_Eol() + ;
   '<html><head><meta charset="utf-8">' + hb_Eol() + ;
   '<style>' + hb_Eol() + ;
   'body{margin:0;background:#fff;color:#111;font-family:"Courier New",monospace;font-size:13px;}' + hb_Eol() + ;
   '.danfe-etq{box-sizing:border-box;width:100%;max-width:760px;border:2px solid #111;margin:0 auto;background:#fff;}' + hb_Eol() + ;
   '.danfe-title{font-weight:bold;text-align:center;font-size:18px;padding:10px;border-bottom:2px solid #111;letter-spacing:.5px;}' + hb_Eol() + ;
   '.danfe-box{border-bottom:2px solid #111;padding:8px 10px;}' + hb_Eol() + ;
   '.danfe-row{display:flex;border-bottom:2px solid #111;}' + hb_Eol() + ;
   '.danfe-col{box-sizing:border-box;padding:7px 8px;border-right:2px solid #111;min-height:54px;}' + hb_Eol() + ;
   '.danfe-col:last-child{border-right:0;}' + hb_Eol() + ;
   '.lbl{font-size:12px;font-weight:bold;display:block;margin-bottom:4px;}' + hb_Eol() + ;
   '.val{font-size:16px;font-weight:bold;word-break:break-word;}' + hb_Eol() + ;
   '.small{font-size:13px;}.center{text-align:center}.right{text-align:right}.logo{width:180px;display:flex;align-items:center;justify-content:center;}' + hb_Eol() + ;
   '.barcode svg{width:100%;height:96px;display:block}.chave{font-size:14px;letter-spacing:1px;text-align:center;margin-top:3px;}' + hb_Eol() + ;
   '@media print{body{margin:0}.danfe-etq{max-width:none;width:100%;page-break-inside:avoid}}' + hb_Eol() + ;
   '</style></head><body>' + hb_Eol() + ;
   '<div class="danfe-etq">' + hb_Eol() + ;
   '<div class="danfe-title">DANFE simplificado - Etiqueta</div>' + hb_Eol() + ;
   '<div class="danfe-box"><span class="lbl">Chave de acesso:</span><div class="barcode">' + ;
      SefazDanfeCode128Svg( h[ "chave" ], 2, 92 ) + '</div><div class="chave">' + ;
      SefazDanfeFormatChave( h[ "chave" ] ) + '</div></div>' + hb_Eol() + ;
   '<div class="danfe-row">' + ;
      '<div class="danfe-col logo">' + cLogo + '</div>' + ;
      '<div class="danfe-col" style="flex:1">' + ;
         SefazDanfeCampoHtml( "NOME/RAZAO SOCIAL", h[ "emitNome" ] ) + ;
         SefazDanfeCampoHtml( "CNPJ", SefazDanfeFormatDoc( h[ "emitDoc" ] ) ) + ;
         SefazDanfeCampoHtml( "IE", h[ "emitIE" ] ) + ;
         SefazDanfeCampoHtml( "ENDERECO", h[ "emitEnd" ] ) + ;
         SefazDanfeCampoHtml( "CEP", SefazDanfeFormatCep( h[ "emitCep" ] ) + "    TEL: " + SefazDanfeFormatFone( h[ "emitFone" ] ) ) + ;
      '</div></div>' + hb_Eol() + ;
   '<div class="danfe-row">' + ;
      '<div class="danfe-col" style="width:33%">' + SefazDanfeCampoHtml( "N", h[ "nNF" ] ) + SefazDanfeCampoHtml( "SERIE", h[ "serie" ] ) + '</div>' + ;
      '<div class="danfe-col center" style="width:34%">' + SefazDanfeCampoHtml( "DATA DA EMISSAO", h[ "dhEmi" ] ) + '</div>' + ;
      '<div class="danfe-col center" style="width:33%">' + SefazDanfeCampoHtml( "HORA DA EMISSAO", h[ "hEmi" ] ) + '</div>' + ;
   '</div>' + hb_Eol() + ;
   '<div class="danfe-title" style="font-size:16px;padding:7px">DESTINATARIO</div>' + hb_Eol() + ;
   '<div class="danfe-box">' + SefazDanfeCampoHtml( "NOME/RAZAO SOCIAL", h[ "destNome" ] ) + '</div>' + hb_Eol() + ;
   '<div class="danfe-row">' + ;
      '<div class="danfe-col" style="width:42%">' + SefazDanfeCampoHtml( "CNPJ/CPF/ID", SefazDanfeFormatDoc( h[ "destDoc" ] ) ) + '</div>' + ;
      '<div class="danfe-col center" style="width:40%">' + SefazDanfeCampoHtml( "INSCRICAO ESTADUAL", h[ "destIE" ] ) + '</div>' + ;
      '<div class="danfe-col center" style="width:18%">' + SefazDanfeCampoHtml( "UF", h[ "destUF" ] ) + '</div>' + ;
   '</div>' + hb_Eol() + ;
   '<div class="danfe-row">' + ;
      '<div class="danfe-col" style="width:55%">' + SefazDanfeCampoHtml( "PROTOCOLO DE AUTORIZACAO", h[ "protocolo" ] ) + '</div>' + ;
      '<div class="danfe-col right" style="width:45%">' + SefazDanfeCampoHtml( "VALOR TOTAL DA NOTA", SefazDanfeFormatValor( h[ "valor" ] ) ) + '</div>' + ;
   '</div>' + hb_Eol() + ;
   '</div></body></html>'

FUNCTION SefazDanfeSimplificadoTexto( cXmlOuArquivo )

   LOCAL h := SefazDanfeSimplificadoDados( cXmlOuArquivo )

   IF ! h[ "ok" ]
      RETURN "DANFE simplificado: " + h[ "erro" ]
   ENDIF

RETURN ;
   "DANFE simplificado - Etiqueta" + hb_Eol() + ;
   "Chave: " + SefazDanfeFormatChave( h[ "chave" ] ) + hb_Eol() + ;
   "Emitente: " + h[ "emitNome" ] + hb_Eol() + ;
   "CNPJ: " + SefazDanfeFormatDoc( h[ "emitDoc" ] ) + " IE: " + h[ "emitIE" ] + hb_Eol() + ;
   "NF: " + h[ "nNF" ] + " Serie: " + h[ "serie" ] + " Emissao: " + h[ "dhEmi" ] + " " + h[ "hEmi" ] + hb_Eol() + ;
   "Destinatario: " + h[ "destNome" ] + hb_Eol() + ;
   "Doc: " + SefazDanfeFormatDoc( h[ "destDoc" ] ) + " IE: " + h[ "destIE" ] + " UF: " + h[ "destUF" ] + hb_Eol() + ;
   "Protocolo: " + h[ "protocolo" ] + hb_Eol() + ;
   "Valor: " + SefazDanfeFormatValor( h[ "valor" ] )

FUNCTION SefazDanfeSimplificadoSalvarHtml( cXmlOuArquivo, cArquivoSaida, cLogoHtml )

   IF Empty( cArquivoSaida )
      RETURN .F.
   ENDIF

RETURN hb_MemoWrit( cArquivoSaida, SefazDanfeSimplificadoHtml( cXmlOuArquivo, cLogoHtml ) )

FUNCTION SefazDanfeSimplificadoDados( cXmlOuArquivo )

   LOCAL h := {=>}, cXml, cNFe, cInfNFe, cIde, cEmit, cDest, cTotal, cICMSTot
   LOCAL cEnderEmit, cEnderDest, cInfProt, cId, cDhEmi

   h[ "ok" ]   := .F.
   h[ "erro" ] := ""

   cXml := SefazDanfeLoadXml( cXmlOuArquivo )
   IF Empty( cXml )
      h[ "erro" ] := "XML vazio"
      RETURN h
   ENDIF

   cNFe := XmlNode( cXml, "NFe", .T. )
   IF Empty( cNFe )
      cNFe := cXml
   ENDIF

   cInfNFe := XmlNode( cNFe, "infNFe", .T. )
   IF Empty( cInfNFe )
      h[ "erro" ] := "Nao localizou infNFe. Informe XML autorizado nfeProc/NFe completo."
      RETURN h
   ENDIF

   cId       := XmlElement( cInfNFe, "Id" )
   cIde      := XmlNode( cInfNFe, "ide", .T. )
   cEmit     := XmlNode( cInfNFe, "emit", .T. )
   cDest     := XmlNode( cInfNFe, "dest", .T. )
   cTotal    := XmlNode( cInfNFe, "total", .T. )
   cICMSTot  := XmlNode( cTotal, "ICMSTot", .T. )
   cInfProt  := XmlNode( cXml, "infProt", .T. )
   cEnderEmit := XmlNode( cEmit, "enderEmit", .T. )
   cEnderDest := XmlNode( cDest, "enderDest", .T. )

   h[ "chave" ]     := SefazDanfeOnlyDigits( IIf( Left( cId, 3 ) == "NFe", SubStr( cId, 4 ), cId ) )
   h[ "emitNome" ]  := XmlNode( cEmit, "xNome" )
   h[ "emitDoc" ]   := IIf( Empty( XmlNode( cEmit, "CNPJ" ) ), XmlNode( cEmit, "CPF" ), XmlNode( cEmit, "CNPJ" ) )
   h[ "emitIE" ]    := XmlNode( cEmit, "IE" )
   h[ "emitEnd" ]   := AllTrim( XmlNode( cEnderEmit, "xLgr" ) + " " + XmlNode( cEnderEmit, "nro" ) + " " + XmlNode( cEnderEmit, "xBairro" ) + " " + XmlNode( cEnderEmit, "xMun" ) + " UF: " + XmlNode( cEnderEmit, "UF" ) )
   h[ "emitCep" ]   := XmlNode( cEnderEmit, "CEP" )
   h[ "emitFone" ]  := XmlNode( cEnderEmit, "fone" )
   h[ "nNF" ]       := XmlNode( cIde, "nNF" )
   h[ "serie" ]     := XmlNode( cIde, "serie" )
   cDhEmi           := IIf( Empty( XmlNode( cIde, "dhEmi" ) ), XmlNode( cIde, "dEmi" ), XmlNode( cIde, "dhEmi" ) )
   h[ "dhEmi" ]     := SefazDanfeData( cDhEmi )
   h[ "hEmi" ]      := SefazDanfeHora( cDhEmi )
   h[ "destNome" ]  := XmlNode( cDest, "xNome" )
   h[ "destDoc" ]   := SefazDanfeDestDoc( cDest )
   h[ "destIE" ]    := XmlNode( cDest, "IE" )
   h[ "destUF" ]    := IIf( Empty( XmlNode( cEnderDest, "UF" ) ), XmlNode( cDest, "UF" ), XmlNode( cEnderDest, "UF" ) )
   h[ "protocolo" ] := XmlNode( cInfProt, "nProt" )
   h[ "valor" ]     := XmlNode( cICMSTot, "vNF" )
   h[ "ok" ]        := ! Empty( h[ "chave" ] )

   IF ! h[ "ok" ]
      h[ "erro" ] := "Nao localizou chave de acesso no Id da infNFe"
   ENDIF

RETURN h

STATIC FUNCTION SefazDanfeLoadXml( cXmlOuArquivo )

   IF Empty( cXmlOuArquivo )
      RETURN ""
   ENDIF
   IF File( cXmlOuArquivo )
      RETURN hb_MemoRead( cXmlOuArquivo )
   ENDIF
RETURN cXmlOuArquivo

STATIC FUNCTION SefazDanfeCampoHtml( cLabel, cValor )
RETURN '<span class="lbl">' + SefazDanfeHtmlEscape( cLabel ) + ':</span><div class="val">' + SefazDanfeHtmlEscape( hb_DefaultValue( cValor, "" ) ) + '</div>'

STATIC FUNCTION SefazDanfeHtmlEscape( cText )
   cText := hb_DefaultValue( cText, "" )
   cText := StrTran( cText, "&", "&amp;" )
   cText := StrTran( cText, "<", "&lt;" )
   cText := StrTran( cText, ">", "&gt;" )
   cText := StrTran( cText, ["], "&quot;" )
RETURN cText

STATIC FUNCTION SefazDanfeDestDoc( cDest )
   IF ! Empty( XmlNode( cDest, "CNPJ" ) )
      RETURN XmlNode( cDest, "CNPJ" )
   ENDIF
   IF ! Empty( XmlNode( cDest, "CPF" ) )
      RETURN XmlNode( cDest, "CPF" )
   ENDIF
RETURN XmlNode( cDest, "idEstrangeiro" )

STATIC FUNCTION SefazDanfeOnlyDigits( cText )
   LOCAL nI, c, cOut := ""
   cText := hb_DefaultValue( cText, "" )
   FOR nI := 1 TO Len( cText )
      c := SubStr( cText, nI, 1 )
      IF c >= "0" .AND. c <= "9"
         cOut += c
      ENDIF
   NEXT
RETURN cOut

STATIC FUNCTION SefazDanfeOnlyAlnum( cText )

   LOCAL nI, c, cOut := ""
   cText := Upper( hb_DefaultValue( cText, "" ) )
   FOR nI := 1 TO Len( cText )
      c := SubStr( cText, nI, 1 )
      IF ( c >= "0" .AND. c <= "9" ) .OR. ( c >= "A" .AND. c <= "Z" )
         cOut += c
      ENDIF
   NEXT
RETURN cOut

FUNCTION SefazDanfeFormatChave( cChave )
   LOCAL nI, cOut := ""
   cChave := SefazDanfeOnlyAlnum( cChave )
   FOR nI := 1 TO Len( cChave ) STEP 4
      cOut += SubStr( cChave, nI, 4 ) + " "
   NEXT
RETURN RTrim( cOut )

FUNCTION SefazDanfeFormatDoc( cDoc )
   cDoc := SefazDanfeOnlyAlnum( cDoc )
   DO CASE
   CASE Len( cDoc ) == 14
      RETURN SubStr( cDoc, 1, 2 ) + "." + SubStr( cDoc, 3, 3 ) + "." + SubStr( cDoc, 6, 3 ) + "/" + SubStr( cDoc, 9, 4 ) + "-" + SubStr( cDoc, 13, 2 )
   CASE Len( cDoc ) == 11
      RETURN SubStr( cDoc, 1, 3 ) + "." + SubStr( cDoc, 4, 3 ) + "." + SubStr( cDoc, 7, 3 ) + "-" + SubStr( cDoc, 10, 2 )
   ENDCASE
RETURN cDoc

FUNCTION SefazDanfeFormatCep( cCep )
   cCep := SefazDanfeOnlyDigits( cCep )
   IF Len( cCep ) == 8
      RETURN SubStr( cCep, 1, 5 ) + "-" + SubStr( cCep, 6, 3 )
   ENDIF
RETURN cCep

FUNCTION SefazDanfeFormatFone( cFone )
   cFone := SefazDanfeOnlyDigits( cFone )
RETURN cFone

FUNCTION SefazDanfeFormatValor( cValor )
   LOCAL nValor := Val( hb_DefaultValue( cValor, "0" ) )
RETURN "R$" + StrTran( AllTrim( Transform( nValor, "999,999,999.99" ) ), ".", "," )

STATIC FUNCTION SefazDanfeData( cDh )
   IF Len( cDh ) >= 10 .AND. SubStr( cDh, 5, 1 ) == "-"
      RETURN SubStr( cDh, 9, 2 ) + "/" + SubStr( cDh, 6, 2 ) + "/" + SubStr( cDh, 1, 4 )
   ENDIF
RETURN cDh

STATIC FUNCTION SefazDanfeHora( cDh )
   IF Len( cDh ) >= 19 .AND. SubStr( cDh, 11, 1 ) $ "T "
      RETURN SubStr( cDh, 12, 8 )
   ENDIF
RETURN ""

STATIC FUNCTION SefazDanfeCode128Svg( cDigits, nBarWidth, nHeight )

   LOCAL aCodes := {}, nI, nPair, nChecksum, nWeight := 1, cSvg := "", nX := 0
   LOCAL cText := SefazDanfeOnlyAlnum( cDigits )

   IF cText == SefazDanfeOnlyDigits( cText )
      IF Len( cText ) % 2 != 0
         cText := "0" + cText
      ENDIF

      AAdd( aCodes, 105 )
      FOR nI := 1 TO Len( cText ) STEP 2
         nPair := Val( SubStr( cText, nI, 2 ) )
         AAdd( aCodes, nPair )
      NEXT
   ELSE
      AAdd( aCodes, 104 )
      FOR nI := 1 TO Len( cText )
         AAdd( aCodes, Asc( SubStr( cText, nI, 1 ) ) - 32 )
      NEXT
   ENDIF

   nChecksum := aCodes[ 1 ]
   FOR nI := 2 TO Len( aCodes )
      nChecksum += aCodes[ nI ] * nWeight
      nWeight++
   NEXT
   AAdd( aCodes, nChecksum % 103 )
   AAdd( aCodes, 106 )

   FOR nI := 1 TO Len( aCodes )
      cSvg += SefazDanfeCode128Bars( aCodes[ nI ], @nX, nBarWidth, nHeight )
   NEXT

RETURN '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + AllTrim( Str( nX ) ) + ' ' + ;
   AllTrim( Str( nHeight ) ) + '" preserveAspectRatio="none">' + cSvg + '</svg>'

STATIC FUNCTION SefazDanfeCode128Bars( nCode, nX, nBarWidth, nHeight )

   LOCAL aPatterns := SefazDanfeCode128Patterns()
   LOCAL cPattern := aPatterns[ nCode + 1 ], nI, nW, cSvg := "", lBar := .T.

   FOR nI := 1 TO Len( cPattern )
      nW := Val( SubStr( cPattern, nI, 1 ) ) * nBarWidth
      IF lBar
         cSvg += '<rect x="' + AllTrim( Str( nX ) ) + '" y="0" width="' + AllTrim( Str( nW ) ) + '" height="' + AllTrim( Str( nHeight ) ) + '"/>'
      ENDIF
      nX += nW
      lBar := ! lBar
   NEXT

RETURN cSvg

STATIC FUNCTION SefazDanfeCode128Patterns()
RETURN { ;
   "212222","222122","222221","121223","121322","131222","122213","122312","132212","221213", ;
   "221312","231212","112232","122132","122231","113222","123122","123221","223211","221132", ;
   "221231","213212","223112","312131","311222","321122","321221","312212","322112","322211", ;
   "212123","212321","232121","111323","131123","131321","112313","132113","132311","211313", ;
   "231113","231311","112133","112331","132131","113123","113321","133121","313121","211331", ;
   "231131","213113","213311","213131","311123","311321","331121","312113","312311","332111", ;
   "314111","221411","431111","111224","111422","121124","121421","141122","141221","112214", ;
   "112412","122114","122411","142112","142211","241211","221114","413111","241112","134111", ;
   "111242","121142","121241","114212","124112","124211","411212","421112","421211","212141", ;
   "214121","412121","111143","111341","131141","114113","114311","411113","411311","113141", ;
   "114131","311141","411131","211412","211214","211232","2331112" }

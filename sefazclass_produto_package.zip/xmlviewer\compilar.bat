@echo off
setlocal
set PATH=C:\xbase\bcc582\Bin;C:\xbase\harbour_1608\bin;%PATH%
set HB_COMPILER=bcc

hbmk2 -comp=bcc demo_xml_visualizacao.hbp || exit /b 1

echo.
echo XML viewer compilado com sucesso.
endlocal


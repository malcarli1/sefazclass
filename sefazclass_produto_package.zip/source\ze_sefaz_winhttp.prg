#include "hbclass.ch"

FUNCTION SefazWinHttpPost( cUrl, cSoapAction, cXml, cCertSubject, cPfxFile, cPassword, ;
   nTimeout, cProxyUrl, cProxyUser, cProxyPassword, lIgnoreSsl, cError, nHttpStatus )

   LOCAL cRet

   hb_Default( @cUrl, "" )
   hb_Default( @cSoapAction, "" )
   hb_Default( @cXml, "" )
   hb_Default( @cCertSubject, "" )
   hb_Default( @cPfxFile, "" )
   hb_Default( @cPassword, "" )
   hb_Default( @nTimeout, 15000 )
   hb_Default( @cProxyUrl, "" )
   hb_Default( @cProxyUser, "" )
   hb_Default( @cProxyPassword, "" )
   hb_Default( @lIgnoreSsl, .F. )

   cRet := __SefazWinHttpPost( cUrl, cSoapAction, cXml, cCertSubject, cPfxFile, cPassword, ;
      nTimeout, cProxyUrl, cProxyUser, cProxyPassword, lIgnoreSsl, @cError, @nHttpStatus )

RETURN cRet

#pragma BEGINDUMP

#include "hbapi.h"
#include "hbapiitm.h"
#include <string.h>
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <winhttp.h>
#include <wincrypt.h>

#ifndef CERT_NCRYPT_KEY_SPEC
#define CERT_NCRYPT_KEY_SPEC 0xFFFFFFFF
#endif
#ifndef HCRYPTPROV_OR_NCRYPT_KEY_HANDLE
typedef ULONG_PTR HCRYPTPROV_OR_NCRYPT_KEY_HANDLE;
#endif
#ifndef NCRYPT_HANDLE
typedef ULONG_PTR NCRYPT_HANDLE;
#endif
#ifndef SECURITY_STATUS
typedef LONG SECURITY_STATUS;
#endif
typedef SECURITY_STATUS ( WINAPI * SEFAZ_NCRYPTFREEOBJECT )( NCRYPT_HANDLE hObject );

static void sefaz_ncrypt_free_object( NCRYPT_HANDLE hObject )
{
   HMODULE hMod;
   SEFAZ_NCRYPTFREEOBJECT pfn;

   hMod = LoadLibraryA( "ncrypt.dll" );
   if( hMod != NULL )
   {
      pfn = ( SEFAZ_NCRYPTFREEOBJECT ) GetProcAddress( hMod, "NCryptFreeObject" );
      if( pfn != NULL )
         pfn( hObject );
      FreeLibrary( hMod );
   }
}

static wchar_t * sefaz_to_wide( const char * pszText )
{
   int nLen;
   wchar_t * pWide;

   if( pszText == NULL )
      pszText = "";

   nLen = MultiByteToWideChar( CP_ACP, 0, pszText, -1, NULL, 0 );
   if( nLen <= 0 )
      nLen = 1;

   pWide = ( wchar_t * ) hb_xgrab( nLen * sizeof( wchar_t ) );
   if( ! MultiByteToWideChar( CP_ACP, 0, pszText, -1, pWide, nLen ) )
      pWide[ 0 ] = 0;

   return pWide;
}

static void sefaz_upper_copy( char * dst, const char * src, DWORD nMax )
{
   DWORD n;

   if( dst == NULL || nMax == 0 )
      return;

   if( src == NULL )
      src = "";

   for( n = 0; n + 1 < nMax && src[ n ] != 0; ++n )
   {
      char c = src[ n ];
      if( c >= 'a' && c <= 'z' )
         c = ( char ) ( c - 32 );
      dst[ n ] = c;
   }
   dst[ n ] = 0;
}

static BOOL sefaz_contains_i( const char * pszText, const char * pszFind )
{
   char aText[ 2048 ];
   char aFind[ 512 ];

   if( pszFind == NULL || pszFind[ 0 ] == 0 )
      return TRUE;

   sefaz_upper_copy( aText, pszText, sizeof( aText ) );
   sefaz_upper_copy( aFind, pszFind, sizeof( aFind ) );

   return strstr( aText, aFind ) != NULL;
}

static void sefaz_hash_hex( PCCERT_CONTEXT pCert, char * pszHex, DWORD nHexLen )
{
   BYTE bHash[ 64 ];
   DWORD cbHash;
   DWORD n;
   static const char * sHex = "0123456789ABCDEF";

   if( pszHex == NULL || nHexLen == 0 )
      return;

   pszHex[ 0 ] = 0;
   cbHash = sizeof( bHash );

   if( pCert == NULL || ! CertGetCertificateContextProperty( pCert, CERT_HASH_PROP_ID, bHash, &cbHash ) )
      return;

   if( nHexLen < ( cbHash * 2 + 1 ) )
      return;

   for( n = 0; n < cbHash; ++n )
   {
      pszHex[ n * 2 ] = sHex[ ( bHash[ n ] >> 4 ) & 0x0F ];
      pszHex[ n * 2 + 1 ] = sHex[ bHash[ n ] & 0x0F ];
   }
   pszHex[ cbHash * 2 ] = 0;
}

static PCCERT_CONTEXT sefaz_find_cert_with_key( HCERTSTORE hStore, const char * pszFind )
{
   PCCERT_CONTEXT pCert;
   PCCERT_CONTEXT pDup;
   char szName[ 1024 ];
   char szHash[ 128 ];
   HCRYPTPROV_OR_NCRYPT_KEY_HANDLE hKey;
   DWORD dwKeySpec;
   BOOL fCallerFree;

   pCert = NULL;
   while( ( pCert = CertEnumCertificatesInStore( hStore, pCert ) ) != NULL )
   {
      szName[ 0 ] = 0;
      szHash[ 0 ] = 0;
      CertGetNameStringA( pCert, CERT_NAME_SIMPLE_DISPLAY_TYPE, 0, NULL, szName, sizeof( szName ) );
      sefaz_hash_hex( pCert, szHash, sizeof( szHash ) );

      if( sefaz_contains_i( szName, pszFind ) || sefaz_contains_i( szHash, pszFind ) )
      {
         hKey = 0;
         dwKeySpec = 0;
         fCallerFree = FALSE;
         if( CryptAcquireCertificatePrivateKey( pCert, CRYPT_ACQUIRE_COMPARE_KEY_FLAG | CRYPT_ACQUIRE_SILENT_FLAG, NULL, &hKey, &dwKeySpec, &fCallerFree ) )
         {
            if( fCallerFree )
            {
               if( dwKeySpec == CERT_NCRYPT_KEY_SPEC )
                  sefaz_ncrypt_free_object( ( NCRYPT_HANDLE ) hKey );
               else
                  CryptReleaseContext( ( HCRYPTPROV ) hKey, 0 );
            }
            pDup = CertDuplicateCertificateContext( pCert );
            return pDup;
         }
      }
   }

   return NULL;
}

static HCERTSTORE sefaz_open_pfx_store( const char * pszFile, const char * pszPassword )
{
   HANDLE hFile;
   DWORD dwSize;
   DWORD dwRead;
   BYTE * pData;
   CRYPT_DATA_BLOB blob;
   HCERTSTORE hStore;
   wchar_t * pPass;

   if( pszFile == NULL || pszFile[ 0 ] == 0 )
      return NULL;

   hFile = CreateFileA( pszFile, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL );
   if( hFile == INVALID_HANDLE_VALUE )
      return NULL;

   dwSize = GetFileSize( hFile, NULL );
   if( dwSize == INVALID_FILE_SIZE || dwSize == 0 )
   {
      CloseHandle( hFile );
      return NULL;
   }

   pData = ( BYTE * ) hb_xgrab( dwSize );
   dwRead = 0;
   if( ! ReadFile( hFile, pData, dwSize, &dwRead, NULL ) || dwRead != dwSize )
   {
      hb_xfree( pData );
      CloseHandle( hFile );
      return NULL;
   }
   CloseHandle( hFile );

   blob.cbData = dwSize;
   blob.pbData = pData;
   pPass = sefaz_to_wide( pszPassword );
   hStore = PFXImportCertStore( &blob, pPass, 0 );
   hb_xfree( pPass );
   hb_xfree( pData );

   return hStore;
}

static char * sefaz_last_error_text( const char * pszPrefix )
{
   DWORD dwErr;
   char * pszMsg;

   dwErr = GetLastError();
   pszMsg = ( char * ) hb_xgrab( 256 );
   wsprintfA( pszMsg, "%s - Win32 %lu", pszPrefix == NULL ? "Erro" : pszPrefix, ( unsigned long ) dwErr );
   return pszMsg;
}

HB_FUNC( __SEFAZWINHTTPPOST )
{
   const char * pszUrl = hb_parc( 1 );
   const char * pszAction = hb_parc( 2 );
   const char * pszXml = hb_parc( 3 );
   const char * pszSubject = hb_parc( 4 );
   const char * pszPfx = hb_parc( 5 );
   const char * pszPassword = hb_parc( 6 );
   DWORD dwTimeout = ( DWORD ) hb_parni( 7 );
   const char * pszProxy = hb_parc( 8 );
   const char * pszProxyUser = hb_parc( 9 );
   const char * pszProxyPassword = hb_parc( 10 );
   BOOL fIgnoreSsl = hb_parl( 11 );
   wchar_t * pUrl = NULL;
   wchar_t * pHost = NULL;
   wchar_t * pPath = NULL;
   wchar_t * pProxy = NULL;
   wchar_t * pProxyUser = NULL;
   wchar_t * pProxyPassword = NULL;
   wchar_t * pHeaders = NULL;
   URL_COMPONENTS uc;
   HINTERNET hSession = NULL;
   HINTERNET hConnect = NULL;
   HINTERNET hRequest = NULL;
   HCERTSTORE hPfxStore = NULL;
   HCERTSTORE hMyStore = NULL;
   PCCERT_CONTEXT pCert = NULL;
   DWORD dwFlags;
   DWORD dwStatus;
   DWORD dwStatusSize;
   DWORD dwSecurityFlags;
   DWORD dwRead;
   DWORD dwTotal;
   DWORD dwXmlLen;
   BOOL fOk;
   char * pResp;
   char * pNew;
   char buffer[ 8192 ];
   char * pszError = NULL;
   char * pszHeaderA = NULL;

   if( dwTimeout == 0 )
      dwTimeout = 15000;

   pUrl = sefaz_to_wide( pszUrl );
   memset( &uc, 0, sizeof( uc ) );
   uc.dwStructSize = sizeof( uc );
   uc.dwSchemeLength = ( DWORD ) -1;
   uc.dwHostNameLength = ( DWORD ) -1;
   uc.dwUrlPathLength = ( DWORD ) -1;
   uc.dwExtraInfoLength = ( DWORD ) -1;

   if( ! WinHttpCrackUrl( pUrl, 0, 0, &uc ) )
   {
      pszError = sefaz_last_error_text( "WinHttpCrackUrl falhou" );
      hb_storc( pszError, 12 );
      hb_storni( 0, 13 );
      hb_xfree( pszError );
      hb_xfree( pUrl );
      hb_retc( "" );
      return;
   }

   pHost = ( wchar_t * ) hb_xgrab( ( uc.dwHostNameLength + 1 ) * sizeof( wchar_t ) );
   memcpy( pHost, uc.lpszHostName, uc.dwHostNameLength * sizeof( wchar_t ) );
   pHost[ uc.dwHostNameLength ] = 0;

   pPath = ( wchar_t * ) hb_xgrab( ( uc.dwUrlPathLength + uc.dwExtraInfoLength + 1 ) * sizeof( wchar_t ) );
   memcpy( pPath, uc.lpszUrlPath, uc.dwUrlPathLength * sizeof( wchar_t ) );
   if( uc.dwExtraInfoLength > 0 )
      memcpy( pPath + uc.dwUrlPathLength, uc.lpszExtraInfo, uc.dwExtraInfoLength * sizeof( wchar_t ) );
   pPath[ uc.dwUrlPathLength + uc.dwExtraInfoLength ] = 0;

   if( pszProxy != NULL && pszProxy[ 0 ] != 0 )
   {
      pProxy = sefaz_to_wide( pszProxy );
      hSession = WinHttpOpen( L"sefazclass-winhttp/1.0", WINHTTP_ACCESS_TYPE_NAMED_PROXY, pProxy, WINHTTP_NO_PROXY_BYPASS, 0 );
   }
   else
      hSession = WinHttpOpen( L"sefazclass-winhttp/1.0", WINHTTP_ACCESS_TYPE_DEFAULT_PROXY, WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0 );

   if( hSession != NULL )
      WinHttpSetTimeouts( hSession, dwTimeout, dwTimeout, dwTimeout, dwTimeout );

   if( hSession == NULL )
      pszError = sefaz_last_error_text( "WinHttpOpen falhou" );

   if( pszError == NULL )
   {
      hConnect = WinHttpConnect( hSession, pHost, uc.nPort, 0 );
      if( hConnect == NULL )
         pszError = sefaz_last_error_text( "WinHttpConnect falhou" );
   }

   if( pszError == NULL )
   {
      dwFlags = ( uc.nScheme == INTERNET_SCHEME_HTTPS ) ? WINHTTP_FLAG_SECURE : 0;
      hRequest = WinHttpOpenRequest( hConnect, L"POST", pPath, NULL, WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES, dwFlags );
      if( hRequest == NULL )
         pszError = sefaz_last_error_text( "WinHttpOpenRequest falhou" );
   }

   if( pszError == NULL && fIgnoreSsl )
   {
      dwSecurityFlags = SECURITY_FLAG_IGNORE_UNKNOWN_CA | SECURITY_FLAG_IGNORE_CERT_DATE_INVALID | SECURITY_FLAG_IGNORE_CERT_CN_INVALID | SECURITY_FLAG_IGNORE_CERT_WRONG_USAGE;
      WinHttpSetOption( hRequest, WINHTTP_OPTION_SECURITY_FLAGS, &dwSecurityFlags, sizeof( dwSecurityFlags ) );
   }

   if( pszError == NULL && pszProxyUser != NULL && pszProxyUser[ 0 ] != 0 )
   {
      pProxyUser = sefaz_to_wide( pszProxyUser );
      pProxyPassword = sefaz_to_wide( pszProxyPassword );
      WinHttpSetCredentials( hRequest, WINHTTP_AUTH_TARGET_PROXY, WINHTTP_AUTH_SCHEME_BASIC, pProxyUser, pProxyPassword, NULL );
   }

   if( pszError == NULL )
   {
      if( pszPfx != NULL && pszPfx[ 0 ] != 0 )
      {
         hPfxStore = sefaz_open_pfx_store( pszPfx, pszPassword );
         if( hPfxStore == NULL )
            pszError = sefaz_last_error_text( "PFXImportCertStore falhou" );
         else
            pCert = sefaz_find_cert_with_key( hPfxStore, "" );
      }
      else if( pszSubject != NULL && pszSubject[ 0 ] != 0 )
      {
         hMyStore = CertOpenStore( CERT_STORE_PROV_SYSTEM_A, 0, 0, CERT_SYSTEM_STORE_CURRENT_USER, "MY" );
         if( hMyStore == NULL )
            pszError = sefaz_last_error_text( "CertOpenStore MY falhou" );
         else
            pCert = sefaz_find_cert_with_key( hMyStore, pszSubject );
      }

      if( pszError == NULL && ( ( pszPfx != NULL && pszPfx[ 0 ] != 0 ) || ( pszSubject != NULL && pszSubject[ 0 ] != 0 ) ) && pCert == NULL )
         pszError = sefaz_last_error_text( "Certificado com chave privada nao encontrado" );

      if( pszError == NULL && pCert != NULL )
      {
         if( ! WinHttpSetOption( hRequest, WINHTTP_OPTION_CLIENT_CERT_CONTEXT, ( LPVOID ) pCert, sizeof( CERT_CONTEXT ) ) )
            pszError = sefaz_last_error_text( "WinHttpSetOption certificado falhou" );
      }
   }

   if( pszError == NULL )
   {
      if( pszAction != NULL && pszAction[ 0 ] != 0 )
      {
         DWORD nLen = ( DWORD ) ( strlen( pszAction ) + 128 );
         pszHeaderA = ( char * ) hb_xgrab( nLen );
         wsprintfA( pszHeaderA, "Content-Type: application/soap+xml; charset=utf-8\r\nSOAPAction: %s\r\n", pszAction );
      }
      else
      {
         pszHeaderA = ( char * ) hb_xgrab( 80 );
         lstrcpyA( pszHeaderA, "Content-Type: application/soap+xml; charset=utf-8\r\n" );
      }
      pHeaders = sefaz_to_wide( pszHeaderA );
      hb_xfree( pszHeaderA );
      pszHeaderA = NULL;

      dwXmlLen = ( DWORD ) strlen( pszXml == NULL ? "" : pszXml );
      fOk = WinHttpSendRequest( hRequest, pHeaders, ( DWORD ) -1, ( LPVOID ) pszXml, dwXmlLen, dwXmlLen, 0 );
      if( ! fOk )
         pszError = sefaz_last_error_text( "WinHttpSendRequest falhou" );
   }

   if( pszError == NULL )
   {
      if( ! WinHttpReceiveResponse( hRequest, NULL ) )
         pszError = sefaz_last_error_text( "WinHttpReceiveResponse falhou" );
   }

   dwStatus = 0;
   if( pszError == NULL )
   {
      dwStatusSize = sizeof( dwStatus );
      WinHttpQueryHeaders( hRequest, WINHTTP_QUERY_STATUS_CODE | WINHTTP_QUERY_FLAG_NUMBER, WINHTTP_HEADER_NAME_BY_INDEX, &dwStatus, &dwStatusSize, WINHTTP_NO_HEADER_INDEX );
   }

   pResp = NULL;
   dwTotal = 0;
   if( pszError == NULL )
   {
      pResp = ( char * ) hb_xgrab( 1 );
      pResp[ 0 ] = 0;
      do
      {
         dwRead = 0;
         if( ! WinHttpReadData( hRequest, buffer, sizeof( buffer ), &dwRead ) )
         {
            pszError = sefaz_last_error_text( "WinHttpReadData falhou" );
            break;
         }
         if( dwRead > 0 )
         {
            pNew = ( char * ) hb_xrealloc( pResp, dwTotal + dwRead + 1 );
            pResp = pNew;
            memcpy( pResp + dwTotal, buffer, dwRead );
            dwTotal += dwRead;
            pResp[ dwTotal ] = 0;
         }
      }
      while( dwRead > 0 );
   }

   hb_storc( pszError == NULL ? "" : pszError, 12 );
   hb_storni( ( int ) dwStatus, 13 );

   if( pCert != NULL )
      CertFreeCertificateContext( pCert );
   if( hPfxStore != NULL )
      CertCloseStore( hPfxStore, 0 );
   if( hMyStore != NULL )
      CertCloseStore( hMyStore, 0 );
   if( hRequest != NULL )
      WinHttpCloseHandle( hRequest );
   if( hConnect != NULL )
      WinHttpCloseHandle( hConnect );
   if( hSession != NULL )
      WinHttpCloseHandle( hSession );

   if( pHeaders != NULL )
      hb_xfree( pHeaders );
   if( pProxyPassword != NULL )
      hb_xfree( pProxyPassword );
   if( pProxyUser != NULL )
      hb_xfree( pProxyUser );
   if( pProxy != NULL )
      hb_xfree( pProxy );
   if( pPath != NULL )
      hb_xfree( pPath );
   if( pHost != NULL )
      hb_xfree( pHost );
   if( pUrl != NULL )
      hb_xfree( pUrl );
   if( pszError != NULL )
      hb_xfree( pszError );

   if( pResp != NULL )
      hb_retc_buffer( pResp );
   else
      hb_retc( "" );
}

#pragma ENDDUMP

PROCEDURE Main()

   LOCAL oSefaz := TSefazProduto():New()
   LOCAL cXml := IIf( hb_ArgC() >= 1, hb_ArgV( 1 ), "nfe_teste_danfe_simplificado.xml" )
   LOCAL cHtml := "produto_danfe_simplificado.html"
   LOCAL cTxt  := "produto_danfe_simplificado.txt"

   oSefaz:Danfe():SimplificadoSalvarHtml( cHtml, cXml )
   hb_MemoWrit( cTxt, oSefaz:Danfe():SimplificadoTexto( cXml ) )

   ? "HTML:", cHtml
   ? "TXT.:", cTxt
RETURN


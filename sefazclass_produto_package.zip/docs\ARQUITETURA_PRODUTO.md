# Arquitetura da versao produto

## Camadas

- `source/`: motor original da SefazClass.
- `produto/`: API nova, modular e padronizada.
- `tests/`: demos da versao original e demos novos do produto.
- `xmlviewer/`: visualizacao interna de XML, separada.
- `docs/`: documentacao.

## Principio

Nao reescrever toda a regra fiscal de uma vez.

A versao produto encapsula a classe original para preservar a cobertura completa ja existente e adiciona:

- retorno padronizado;
- modulos por documento;
- certificado por modulo;
- DANFE simplificado por modulo;
- acesso direto ao motor original quando necessario.

## Cobertura

A cobertura completa vem de duas formas:

1. Metodos amigaveis:
   - `Status`
   - `Enviar`
   - `RetEnvio`
   - `Protocolo`
   - `Cancelar`
   - `CartaCorrecao`
   - `Distribuicao`
   - `Cadastro`
   - `Manifestacao`
   - `GTIN`

2. Metodo generico:

```harbour
hRet := oSefaz:NFe():Call( "NomeMetodoOriginal", { param1, param2 } )
```

Isso evita esquecer algum evento ou servico ja existente na SefazClass original.


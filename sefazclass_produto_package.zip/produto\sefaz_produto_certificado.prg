#include "hbclass.ch"

CREATE CLASS TSefazProdutoCertificado

   DATA oProduto

   METHOD New( oProduto )
   METHOD A1( cPfxFile, cPassword )
   METHOD A3( cNomeOuThumbprint )
   METHOD Validar()
   METHOD Diagnostico()

ENDCLASS

METHOD New( oProduto ) CLASS TSefazProdutoCertificado
   ::oProduto := oProduto
RETURN Self

METHOD A1( cPfxFile, cPassword ) CLASS TSefazProdutoCertificado
   ::oProduto:oBase:SetCertificadoA1( cPfxFile, cPassword )
RETURN ::Validar()

METHOD A3( cNomeOuThumbprint ) CLASS TSefazProdutoCertificado
   ::oProduto:oBase:SetCertificadoA3( cNomeOuThumbprint )
RETURN ::Validar()

METHOD Validar() CLASS TSefazProdutoCertificado

   LOCAL hCert := ::oProduto:oBase:ValidarCertificado()
   LOCAL h := {=>}

   h[ "ok" ]          := hCert[ "ok" ]
   h[ "motivo" ]      := hCert[ "motivo" ]
   h[ "diagnostico" ] := ::oProduto:oBase:Diagnostico()

RETURN h

METHOD Diagnostico() CLASS TSefazProdutoCertificado
RETURN ::oProduto:oBase:Diagnostico()


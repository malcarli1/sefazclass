# Guia do programador

Este guia e para integrar rapido sem estudar todos os fontes.

## 1. Compile a biblioteca

```bat
set PATH=C:\xbase\bcc582\Bin;C:\xbase\harbour_1608\bin;%PATH%
set HB_COMPILER=bcc
hbmk2 -comp=bcc sefazclass_core.hbp
```

## 2. Configure o INI

Copie:

```bat
copy tests\sefaz.ini.example sefaz.ini
```

Edite `sefaz.ini`:

```ini
[certificado]
tipo=A1
pfx=C:\certificados\empresa.pfx
senha=123456
nome=

[sefaz]
ambiente=2
uf=SP
transporte=AUTO
fallback=1
debug=1
logdir=C:\logs\sefaz
```

Para A3:

```ini
[certificado]
tipo=A3
pfx=
senha=
nome=NOME OU THUMBPRINT DO CERTIFICADO
```

## 3. Rode o teste rapido

```bat
cd tests
demo_teste_rapido.exe ..\sefaz.ini
```

Ele testa:

- leitura do INI
- certificado
- ambiente
- transporte
- status NFe
- status CTe
- status MDFe

## 4. Padrao recomendado no sistema

```harbour
#include "sefazclass.ch"

LOCAL oSefaz := SefazClass():New()
LOCAL cRet

oSefaz:LoadConfigIni( "sefaz.ini" )

IF ! oSefaz:ValidarCertificado()[ "ok" ]
   ? oSefaz:Diagnostico()
   RETURN
ENDIF

cRet := oSefaz:NFeStatus( oSefaz:cUF, oSefaz:cCertificado, oSefaz:cAmbiente )

? oSefaz:cStatus
? oSefaz:cMotivo
? oSefaz:cUltimoTransporte
```

## 5. Regra importante de fallback

Fallback e para erro de comunicacao/TLS/transporte.

Rejeicao fiscal da SEFAZ nao deve tentar outro transporte, porque nesse caso a comunicacao funcionou e o erro esta no XML, schema, regra fiscal, certificado/procuracao ou cadastro.

## 6. Arquivos de log

Com `debug=1`, a classe grava logs na pasta configurada:

- SOAP enviado
- retorno recebido
- log tecnico

Esses arquivos sao os primeiros que devem ser pedidos quando o cliente disser "deu erro".


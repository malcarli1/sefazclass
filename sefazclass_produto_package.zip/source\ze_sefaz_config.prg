#include "sefazclass.ch"

FUNCTION SefazIniLoad( cFileName )

   LOCAL hIni := hb_Hash(), cTxt, aLines, cLine, cSec := "", nPos, cKey, cVal

   IF Empty( cFileName ) .OR. ! File( cFileName )
      RETURN hIni
   ENDIF

   cTxt := hb_MemoRead( cFileName )
   cTxt := StrTran( cTxt, Chr( 13 ) + Chr( 10 ), Chr( 10 ) )
   cTxt := StrTran( cTxt, Chr( 13 ), Chr( 10 ) )
   aLines := hb_ATokens( cTxt, Chr( 10 ) )

   FOR EACH cLine IN aLines
      cLine := AllTrim( cLine )
      IF Empty( cLine ) .OR. Left( cLine, 1 ) == ";" .OR. Left( cLine, 1 ) == "#"
         LOOP
      ENDIF
      IF Left( cLine, 1 ) == "[" .AND. Right( cLine, 1 ) == "]"
         cSec := Lower( AllTrim( SubStr( cLine, 2, Len( cLine ) - 2 ) ) )
         LOOP
      ENDIF
      nPos := At( "=", cLine )
      IF nPos > 0
         cKey := Lower( AllTrim( Left( cLine, nPos - 1 ) ) )
         cVal := AllTrim( SubStr( cLine, nPos + 1 ) )
         IF Len( cVal ) >= 2 .AND. Left( cVal, 1 ) == '"' .AND. Right( cVal, 1 ) == '"'
            cVal := SubStr( cVal, 2, Len( cVal ) - 2 )
         ENDIF
         hIni[ cSec + "." + cKey ] := cVal
      ENDIF
   NEXT

RETURN hIni

FUNCTION SefazIniGet( hIni, cSection, cKey, cDefault )

   LOCAL cFull := Lower( hb_DefaultValue( cSection, "" ) ) + "." + Lower( hb_DefaultValue( cKey, "" ) )

   hb_Default( @cDefault, "" )
   IF ValType( hIni ) == "H" .AND. hb_HHasKey( hIni, cFull )
      RETURN hIni[ cFull ]
   ENDIF

RETURN cDefault

FUNCTION SefazIniGetLogico( hIni, cSection, cKey, lDefault )

   LOCAL cVal

   hb_Default( @lDefault, .F. )
   cVal := Upper( AllTrim( SefazIniGet( hIni, cSection, cKey, IIf( lDefault, "1", "0" ) ) ) )

RETURN cVal $ "1,S,SIM,T,TRUE,Y,YES"

FUNCTION SefazAplicarConfigIni( oSefaz, cFileName )

   LOCAL hIni := SefazIniLoad( cFileName )
   LOCAL cTipo, cPfx, cSenha, cNome, cTransporte, cAmbiente, cUF, cDebug, cLogDir

   IF ValType( oSefaz ) != "O"
      RETURN .F.
   ENDIF

   cTipo := Upper( SefazIniGet( hIni, "certificado", "tipo", "" ) )
   cPfx := SefazIniGet( hIni, "certificado", "pfx", "" )
   cSenha := SefazIniGet( hIni, "certificado", "senha", "" )
   cNome := SefazIniGet( hIni, "certificado", "nome", "" )
   cTransporte := SefazIniGet( hIni, "sefaz", "transporte", "AUTO" )
   cAmbiente := SefazIniGet( hIni, "sefaz", "ambiente", "" )
   cUF := SefazIniGet( hIni, "sefaz", "uf", "" )
   cDebug := SefazIniGet( hIni, "sefaz", "debug", "" )
   cLogDir := SefazIniGet( hIni, "sefaz", "logdir", "logs" )

   IF ! Empty( cAmbiente )
      oSefaz:cAmbiente := cAmbiente
   ENDIF
   IF ! Empty( cUF )
      oSefaz:cUF := Upper( cUF )
   ENDIF

   DO CASE
   CASE cTipo == "A1" .OR. ! Empty( cPfx )
      oSefaz:SetCertificadoA1( cPfx, cSenha )
   CASE cTipo == "A3" .OR. ! Empty( cNome )
      oSefaz:SetCertificadoA3( cNome )
   ENDCASE

   oSefaz:SetTransporte( cTransporte, SefazIniGetLogico( hIni, "sefaz", "fallback", .T. ) )
   IF ! Empty( cDebug )
      oSefaz:SetDebug( SefazIniGetLogico( hIni, "sefaz", "debug", .F. ), cLogDir )
   ENDIF

RETURN .T.

#include "sefazclass.ch"

PROCEDURE Main()
   LOCAL cNome, dIni, dFim, oCert

   ? "Selecionando certificado do repositorio Windows..."
   cNome := SefazCertEscolhe( @dIni, @dFim )

   IF Empty( cNome ) .OR. cNome == "NENHUM"
      ? "Nenhum certificado selecionado."
      RETURN
   ENDIF

   ? "Selecionado:", cNome
   ? "Validade:", DToC( dIni ), DToC( dFim )

   oCert := SefazCertificado( cNome, @dIni, @dFim, .F. )
   IF oCert == NIL
      ? "Nao localizou o certificado pelo nome selecionado."
      RETURN
   ENDIF

   ? "Subject:", oCert:SubjectName
   ? "Thumbprint:", oCert:ThumbPrint
   ? "Serial:", oCert:SerialNumber
RETURN

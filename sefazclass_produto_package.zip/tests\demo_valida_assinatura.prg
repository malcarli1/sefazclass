#include "sefazclass.ch"

PROCEDURE Main()
   LOCAL cRet

   IF hb_ArgC() < 1
      ? "Uso: demo_valida_assinatura xml_assinado.xml [certificado]"
      RETURN
   ENDIF

   cRet := ChkSignature( hb_MemoRead( hb_ArgV( 1 ) ), IIf( hb_ArgC() >= 2, hb_ArgV( 2 ), "" ) )
   ? cRet
RETURN

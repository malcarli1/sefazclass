/*
ZE_CAPICOM - Camada de compatibilidade sem CAPICOM
Mantem os nomes antigos, usando CryptoAPI/CryptUI nativo.
*/

#include "hbclass.ch"
#include "sefazclass.ch"

CREATE CLASS SefazCertInfo
   VAR SubjectName   INIT ""
   VAR IssuerName    INIT ""
   VAR ThumbPrint    INIT ""
   VAR ValidFromDate INIT Ctod( "" )
   VAR ValidToDate   INIT Ctod( "" )
   VAR SerialNumber  INIT ""
   VAR Version       INIT 0
   VAR Installed     INIT .F.
   VAR Expired       INIT .F.

   VAR cCertNomecer  INIT ""
   VAR cCertificado  INIT ""
   VAR cCertEmissor  INIT ""
   VAR dCertDataini  INIT Ctod( "" )
   VAR dCertDatafim  INIT Ctod( "" )
   VAR cCertImprDig  INIT ""
   VAR cCertSerial   INIT ""
   VAR nCertVersao   INIT 0
   VAR lCertInstall  INIT .F.
   VAR lCertVencido  INIT .F.
ENDCLASS

FUNCTION CapicomEscolheCertificado( dValidFrom, dValidTo )
RETURN SefazCertEscolhe( @dValidFrom, @dValidTo )

FUNCTION SefazCertEscolhe( dValidFrom, dValidTo )

   LOCAL cDados := SefazNativeSelectCertificate()
   LOCAL oInfo

   IF Empty( cDados ) .OR. Left( cDados, 5 ) == "ERRO:"
      RETURN "NENHUM"
   ENDIF

   oInfo := SefazCertInfoFromString( cDados )
   dValidFrom := oInfo:ValidFromDate
   dValidTo := oInfo:ValidToDate
RETURN SefazCertSimpleName( oInfo:SubjectName )

FUNCTION CapicomCertificado( cNomeCertificado, dValidFrom, dValidTo, lValidDate )
RETURN SefazCertFind( cNomeCertificado, @dValidFrom, @dValidTo, lValidDate, "MY" )

FUNCTION SefazCertificado( cNomeCertificado, dValidFrom, dValidTo, lValidDate )
RETURN SefazCertFind( cNomeCertificado, @dValidFrom, @dValidTo, lValidDate, "MY" )

FUNCTION SefazCertFind( cNomeCertificado, dValidFrom, dValidTo, lValidDate, cStore )

   LOCAL cDados, oInfo

   hb_Default( @lValidDate, .T. )
   cDados := SefazNativeFindCertificate( hb_DefaultValue( cNomeCertificado, "" ), hb_DefaultValue( cStore, "MY" ) )
   IF Empty( cDados ) .OR. Left( cDados, 5 ) == "ERRO:"
      RETURN Nil
   ENDIF

   oInfo := SefazCertInfoFromString( cDados )
   IF lValidDate .AND. ( oInfo:ValidFromDate > Date() .OR. oInfo:ValidToDate < Date() )
      RETURN Nil
   ENDIF

   dValidFrom := oInfo:ValidFromDate
   dValidTo := oInfo:ValidToDate
RETURN oInfo

FUNCTION CapicomRemoveCertificado( cNomeCertificado, lValidDate )
RETURN SefazCertRemove( cNomeCertificado, lValidDate, "MY" )

FUNCTION SefazCertRemove( cNomeCertificado, lValidDate, cStore )

   HB_SYMBOL_UNUSED( lValidDate )
RETURN SefazNativeRemoveCertificate( hb_DefaultValue( cNomeCertificado, "" ), hb_DefaultValue( cStore, "MY" ) ) == "OK"

FUNCTION CapicomInstalaPFX( cFileName, cPassword, lREMOVER )
RETURN SefazCertInstalaPFX( cFileName, cPassword, lREMOVER )

FUNCTION SefazCertInstalaPFX( cFileName, cPassword, lREMOVER )

   LOCAL cRet

   hb_Default( @lREMOVER, .F. )
   IF lREMOVER
      RETURN ""
   ENDIF

   cRet := SefazNativeInstallPfx( hb_DefaultValue( cFileName, "" ), hb_DefaultValue( cPassword, "" ) )
   IF Left( cRet, 5 ) == "ERRO:"
      RETURN ""
   ENDIF
RETURN SefazCertSimpleName( SefazToken( cRet, 1 ) )

FUNCTION fCertificadoPfx( cFileName, cPassword )
RETURN ImportarCertificadoPfxNative( cFileName, cPassword )

FUNCTION ImportarCertificadoPfxNative( cFileName, cPassword )

   LOCAL cDados, oInfo

   cDados := SefazNativePfxInfo( hb_DefaultValue( cFileName, "" ), hb_DefaultValue( cPassword, "" ) )
   IF Empty( cDados ) .OR. Left( cDados, 5 ) == "ERRO:"
      RETURN Nil
   ENDIF

   oInfo := SefazCertInfoFromString( cDados )
   oInfo:Installed := .F.
   oInfo:lCertInstall := .F.
RETURN oInfo

FUNCTION CapicomInstalaCER( cFileName, cPassword, lREMOVER )
RETURN SefazCertInstalaCER( cFileName, cPassword, lREMOVER )

FUNCTION SefazCertInstalaCER( cFileName, cPassword, lREMOVER )

   LOCAL cRet

   HB_SYMBOL_UNUSED( cPassword )
   hb_Default( @lREMOVER, .F. )
   IF lREMOVER
      RETURN ""
   ENDIF

   cRet := SefazNativeInstallCerRoot( hb_DefaultValue( cFileName, "" ) )
   IF Left( cRet, 5 ) == "ERRO:"
      RETURN ""
   ENDIF
RETURN SefazCertSimpleName( SefazToken( cRet, 1 ) )

FUNCTION CapicomCertificadoRoot( cNomeCertificado, dValidFrom, dValidTo, lValidDate )
RETURN SefazCertRoot( cNomeCertificado, @dValidFrom, @dValidTo, lValidDate )

FUNCTION SefazCertRoot( cNomeCertificado, dValidFrom, dValidTo, lValidDate )

   LOCAL cDados, oInfo

   hb_Default( @lValidDate, .T. )
   cDados := SefazNativeFindCertificate( hb_DefaultValue( cNomeCertificado, "" ), "Root" )
   IF Empty( cDados ) .OR. Left( cDados, 5 ) == "ERRO:"
      RETURN Nil
   ENDIF

   oInfo := SefazCertInfoFromString( cDados )
   IF lValidDate .AND. ( oInfo:ValidFromDate > Date() .OR. oInfo:ValidToDate < Date() )
      RETURN Nil
   ENDIF

   dValidFrom := oInfo:ValidFromDate
   dValidTo := oInfo:ValidToDate
RETURN oInfo

STATIC FUNCTION SefazCertInfoFromString( cDados )
   LOCAL oInfo := SefazCertInfo():New()
   oInfo:SubjectName := SefazToken( cDados, 1 )
   oInfo:ValidFromDate := StoD( SefazToken( cDados, 2 ) )
   oInfo:ValidToDate := StoD( SefazToken( cDados, 3 ) )
   oInfo:ThumbPrint := SefazToken( cDados, 4 )
   oInfo:SerialNumber := SefazToken( cDados, 5 )
   oInfo:Installed := SefazToken( cDados, 6 ) == "1"
   oInfo:IssuerName := SefazToken( cDados, 7 )
   oInfo:Version := Val( SefazToken( cDados, 8 ) )
   oInfo:Expired := oInfo:ValidToDate < Date()

   oInfo:cCertNomecer := SefazCertSimpleName( oInfo:SubjectName )
   oInfo:cCertificado := oInfo:SubjectName
   oInfo:cCertEmissor := oInfo:IssuerName
   oInfo:dCertDataini := oInfo:ValidFromDate
   oInfo:dCertDatafim := oInfo:ValidToDate
   oInfo:cCertImprDig := oInfo:ThumbPrint
   oInfo:cCertSerial := oInfo:SerialNumber
   oInfo:nCertVersao := oInfo:Version
   oInfo:lCertInstall := oInfo:Installed
   oInfo:lCertVencido := oInfo:Expired
RETURN oInfo

STATIC FUNCTION SefazCertSimpleName( cSubject )
   LOCAL cNome := hb_DefaultValue( cSubject, "" )
   IF "CN=" $ cNome
      cNome := SubStr( cNome, At( "CN=", cNome ) + 3 )
      IF "," $ cNome
         cNome := SubStr( cNome, 1, At( ",", cNome ) - 1 )
      ENDIF
   ENDIF
RETURN AllTrim( cNome )

STATIC FUNCTION SefazToken( cText, nToken )
   LOCAL nI, nStart := 1, nEnd, cRet := ""
   FOR nI := 1 TO nToken
      nEnd := hb_At( "|", cText, nStart )
      IF nEnd == 0
         nEnd := Len( cText ) + 1
      ENDIF
      cRet := SubStr( cText, nStart, nEnd - nStart )
      nStart := nEnd + 1
   NEXT
RETURN cRet

#pragma BEGINDUMP

#include "hbapi.h"
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <wincrypt.h>
PCCERT_CONTEXT WINAPI CryptUIDlgSelectCertificateFromStore( HCERTSTORE hCertStore, HWND hwnd, LPCWSTR pwszTitle, LPCWSTR pwszDisplayString, DWORD dwDontUseColumn, DWORD dwFlags, void * pvReserved );
#include <string.h>

static void hb_sefazcert_hex( const BYTE * data, DWORD cb, char * out, DWORD outSize )
{
   static const char * hex = "0123456789ABCDEF";
   DWORD i, p = 0;
   for( i = 0; i < cb && p + 2 < outSize; ++i )
   {
      out[ p++ ] = hex[ data[ i ] >> 4 ];
      out[ p++ ] = hex[ data[ i ] & 0x0F ];
   }
   out[ p ] = 0;
}

static void hb_sefazcert_filetime_date( FILETIME ft, char * out )
{
   SYSTEMTIME st;
   FileTimeToSystemTime( &ft, &st );
   wsprintfA( out, "%04u%02u%02u", st.wYear, st.wMonth, st.wDay );
}

static void hb_sefazcert_info( PCCERT_CONTEXT pCert )
{
   char subject[ 2048 ];
   char issuer[ 2048 ];
   char validFrom[ 16 ];
   char validTo[ 16 ];
   char thumb[ 128 ];
   char serial[ 128 ];
   char ret[ 8192 ];
   BYTE hash[ 64 ];
   DWORD cbHash = sizeof( hash );

   CertGetNameStringA( pCert, CERT_NAME_SIMPLE_DISPLAY_TYPE, 0, NULL, subject, sizeof( subject ) );
   CertGetNameStringA( pCert, CERT_NAME_SIMPLE_DISPLAY_TYPE, CERT_NAME_ISSUER_FLAG, NULL, issuer, sizeof( issuer ) );
   hb_sefazcert_filetime_date( pCert->pCertInfo->NotBefore, validFrom );
   hb_sefazcert_filetime_date( pCert->pCertInfo->NotAfter, validTo );

   if( CertGetCertificateContextProperty( pCert, CERT_HASH_PROP_ID, hash, &cbHash ) )
      hb_sefazcert_hex( hash, cbHash, thumb, sizeof( thumb ) );
   else
      thumb[ 0 ] = 0;

   hb_sefazcert_hex( pCert->pCertInfo->SerialNumber.pbData, pCert->pCertInfo->SerialNumber.cbData, serial, sizeof( serial ) );
   wsprintfA( ret, "%s|%s|%s|%s|%s|1|%s|%lu", subject, validFrom, validTo, thumb, serial, issuer, ( unsigned long ) pCert->pCertInfo->dwVersion + 1 );
   hb_retc( ret );
}

static PCCERT_CONTEXT hb_sefazcert_find( HCERTSTORE hStore, const char * name )
{
   PCCERT_CONTEXT pCert = NULL;
   while( ( pCert = CertEnumCertificatesInStore( hStore, pCert ) ) != NULL )
   {
      char subject[ 2048 ];
      char thumb[ 128 ];
      BYTE hash[ 64 ];
      DWORD cbHash = sizeof( hash );
      DWORD cbInfo = 0;
      CertGetNameStringA( pCert, CERT_NAME_SIMPLE_DISPLAY_TYPE, 0, NULL, subject, sizeof( subject ) );
      if( CertGetCertificateContextProperty( pCert, CERT_HASH_PROP_ID, hash, &cbHash ) )
         hb_sefazcert_hex( hash, cbHash, thumb, sizeof( thumb ) );
      else
         thumb[ 0 ] = 0;
      CertGetCertificateContextProperty( pCert, CERT_KEY_PROV_INFO_PROP_ID, NULL, &cbInfo );
      if( ! name || ! name[ 0 ] || strstr( subject, name ) || lstrcmpiA( thumb, name ) == 0 )
         return CertDuplicateCertificateContext( pCert );
   }
   return NULL;
}

static HCERTSTORE hb_sefazcert_open_store( const char * storeName, DWORD flags )
{
   return CertOpenStore( CERT_STORE_PROV_SYSTEM_A, 0, 0, CERT_SYSTEM_STORE_CURRENT_USER | flags, storeName );
}

HB_FUNC( SEFAZNATIVESELECTCERTIFICATE )
{
   HCERTSTORE hStore = hb_sefazcert_open_store( "MY", CERT_STORE_READONLY_FLAG );
   PCCERT_CONTEXT pCert;
   if( ! hStore ) { hb_retc( "ERRO:CertOpenStore" ); return; }
   pCert = CryptUIDlgSelectCertificateFromStore( hStore, 0, L"Selecione o certificado", L"Selecione o certificado para uso fiscal", 0, 0, NULL );
   if( pCert )
   {
      hb_sefazcert_info( pCert );
      CertFreeCertificateContext( pCert );
   }
   else
      hb_retc( "" );
   CertCloseStore( hStore, 0 );
}

HB_FUNC( SEFAZNATIVEFINDCERTIFICATE )
{
   const char * name = hb_parc( 1 );
   const char * store = hb_parc( 2 );
   HCERTSTORE hStore = hb_sefazcert_open_store( ( store && store[ 0 ] ) ? store : "MY", CERT_STORE_READONLY_FLAG );
   PCCERT_CONTEXT pCert;
   if( ! hStore ) { hb_retc( "ERRO:CertOpenStore" ); return; }
   pCert = hb_sefazcert_find( hStore, name );
   if( pCert )
   {
      hb_sefazcert_info( pCert );
      CertFreeCertificateContext( pCert );
   }
   else
      hb_retc( "ERRO:find-cert" );
   CertCloseStore( hStore, 0 );
}

HB_FUNC( SEFAZNATIVEREMOVECERTIFICATE )
{
   const char * name = hb_parc( 1 );
   const char * store = hb_parc( 2 );
   HCERTSTORE hStore = hb_sefazcert_open_store( ( store && store[ 0 ] ) ? store : "MY", 0 );
   PCCERT_CONTEXT pCert;
   if( ! hStore ) { hb_retc( "ERRO:CertOpenStore" ); return; }
   pCert = hb_sefazcert_find( hStore, name );
   if( pCert )
   {
      if( CertDeleteCertificateFromStore( pCert ) ) hb_retc( "OK" ); else hb_retc( "ERRO:CertDelete" );
   }
   else hb_retc( "ERRO:find-cert" );
   CertCloseStore( hStore, 0 );
}

static BYTE * hb_sefazcert_read_file( const char * fileName, DWORD * size )
{
   HANDLE hFile = CreateFileA( fileName, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL );
   DWORD readSize;
   BYTE * data;
   if( hFile == INVALID_HANDLE_VALUE ) return NULL;
   *size = GetFileSize( hFile, NULL );
   if( *size == INVALID_FILE_SIZE || *size == 0 ) { CloseHandle( hFile ); return NULL; }
   data = ( BYTE * ) hb_xgrab( *size );
   if( ! ReadFile( hFile, data, *size, &readSize, NULL ) || readSize != *size )
   {
      hb_xfree( data );
      CloseHandle( hFile );
      return NULL;
   }
   CloseHandle( hFile );
   return data;
}

HB_FUNC( SEFAZNATIVEINSTALLPFX )
{
   const char * fileName = hb_parc( 1 );
   const char * password = hb_parc( 2 );
   DWORD size = 0;
   BYTE * data = hb_sefazcert_read_file( fileName, &size );
   CRYPT_DATA_BLOB blob;
   WCHAR wszPassword[ 512 ];
   HCERTSTORE hPfx, hMy;
   PCCERT_CONTEXT pCert = NULL, pFirst = NULL;
   if( ! data ) { hb_retc( "ERRO:read-pfx" ); return; }
   ZeroMemory( wszPassword, sizeof( wszPassword ) );
   if( password && password[ 0 ] ) MultiByteToWideChar( CP_ACP, 0, password, -1, wszPassword, sizeof( wszPassword ) / sizeof( WCHAR ) );
   blob.cbData = size; blob.pbData = data;
   hPfx = PFXImportCertStore( &blob, ( password && password[ 0 ] ) ? wszPassword : L"", CRYPT_USER_KEYSET );
   hb_xfree( data );
   if( ! hPfx ) { hb_retc( "ERRO:PFXImportCertStore" ); return; }
   hMy = hb_sefazcert_open_store( "MY", 0 );
   if( ! hMy ) { CertCloseStore( hPfx, 0 ); hb_retc( "ERRO:CertOpenStore" ); return; }
   while( ( pCert = CertEnumCertificatesInStore( hPfx, pCert ) ) != NULL )
   {
      CertAddCertificateContextToStore( hMy, pCert, CERT_STORE_ADD_REPLACE_EXISTING, NULL );
      if( ! pFirst ) pFirst = CertDuplicateCertificateContext( pCert );
   }
   if( pFirst ) { hb_sefazcert_info( pFirst ); CertFreeCertificateContext( pFirst ); } else hb_retc( "ERRO:no-cert" );
   CertCloseStore( hMy, 0 );
   CertCloseStore( hPfx, 0 );
}

HB_FUNC( SEFAZNATIVEPFXINFO )
{
   const char * fileName = hb_parc( 1 );
   const char * password = hb_parc( 2 );
   DWORD size = 0;
   BYTE * data = hb_sefazcert_read_file( fileName, &size );
   CRYPT_DATA_BLOB blob;
   WCHAR wszPassword[ 512 ];
   HCERTSTORE hPfx;
   PCCERT_CONTEXT pCert = NULL;
   if( ! data ) { hb_retc( "ERRO:read-pfx" ); return; }
   ZeroMemory( wszPassword, sizeof( wszPassword ) );
   if( password && password[ 0 ] ) MultiByteToWideChar( CP_ACP, 0, password, -1, wszPassword, sizeof( wszPassword ) / sizeof( WCHAR ) );
   blob.cbData = size; blob.pbData = data;
   hPfx = PFXImportCertStore( &blob, ( password && password[ 0 ] ) ? wszPassword : L"", 0 );
   hb_xfree( data );
   if( ! hPfx ) { hb_retc( "ERRO:PFXImportCertStore" ); return; }
   pCert = hb_sefazcert_find( hPfx, "" );
   if( pCert ) { hb_sefazcert_info( pCert ); CertFreeCertificateContext( pCert ); } else hb_retc( "ERRO:no-cert" );
   CertCloseStore( hPfx, 0 );
}

HB_FUNC( SEFAZNATIVEINSTALLCERROOT )
{
   const char * fileName = hb_parc( 1 );
   DWORD size = 0;
   BYTE * data = hb_sefazcert_read_file( fileName, &size );
   HCERTSTORE hRoot;
   PCCERT_CONTEXT pCert;
   if( ! data ) { hb_retc( "ERRO:read-cer" ); return; }
   pCert = CertCreateCertificateContext( X509_ASN_ENCODING | PKCS_7_ASN_ENCODING, data, size );
   hb_xfree( data );
   if( ! pCert ) { hb_retc( "ERRO:CertCreateCertificateContext" ); return; }
   hRoot = hb_sefazcert_open_store( "Root", 0 );
   if( ! hRoot ) { CertFreeCertificateContext( pCert ); hb_retc( "ERRO:CertOpenStore" ); return; }
   if( CertAddCertificateContextToStore( hRoot, pCert, CERT_STORE_ADD_REPLACE_EXISTING, NULL ) ) hb_sefazcert_info( pCert ); else hb_retc( "ERRO:CertAdd" );
   CertFreeCertificateContext( pCert );
   CertCloseStore( hRoot, 0 );
}

#pragma ENDDUMP

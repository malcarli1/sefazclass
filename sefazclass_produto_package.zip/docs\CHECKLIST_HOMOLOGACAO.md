# Checklist de homologacao

Use este checklist antes de entregar para cliente ou tester.

## Maquina

- Windows com cadeia de certificados raiz/intermediaria atualizada.
- Data/hora corretas.
- Harbour e compilador configurados.
- Acesso HTTPS liberado para os endpoints da SEFAZ.

## Certificado

- A1: arquivo `.pfx` ou `.p12` valido, senha correta e certificado nao vencido.
- A3: driver/token instalado, PIN funcionando e certificado visivel no Windows.
- CNPJ do certificado compativel com o emitente ou procuracao eletronica valida.

## Configuracao

- `ambiente=2` para homologacao.
- `ambiente=1` somente para producao.
- UF correta no INI.
- `transporte=AUTO` para teste geral.
- `debug=1` e `logdir` apontando para pasta gravavel durante homologacao.

## Primeiro teste

1. Compile `sefazclass_core.hbp`.
2. Compile os demos de status.
3. Execute `demo_diagnostico.exe sefaz.ini`.
4. Execute `demo_nfe_status.exe sefaz.ini`.
5. Execute `demo_cte_status.exe sefaz.ini`.
6. Execute `demo_mdfe_status.exe sefaz.ini`.

## Interpretacao de retorno

- Erro de transporte/TLS: revisar certificado, firewall, cadeia, proxy ou endpoint.
- HTTP retornado sem XML SEFAZ: revisar endpoint/UF/ambiente.
- `cStat` fiscal: chamada chegou na SEFAZ; tratar conforme regra do documento.
- Rejeicao fiscal nao e erro de transporte e nao deve acionar fallback.

## Entrega para teste

Enviar a pasta empacotada com:

- `source`
- `include`
- `lib`
- `tests`
- `docs`
- `sefazclass_core.hbp`
- `sefazclass_core.hbc`
- `sefazclass_core_sources.hbm`


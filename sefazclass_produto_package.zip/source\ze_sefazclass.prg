/*
/*
ZE_SEFAZCLASS - Rotinas pra comunica��o com SEFAZ
Jos� Quintas
*/

#include "hbclass.ch"
#include "sefazclass.ch"

CREATE CLASS SefazClass

   /* configura��o */

   VAR    cProjeto        INIT NIL
   VAR    cAmbiente       INIT WS_AMBIENTE_PRODUCAO
   VAR    cVersao         INIT NIL
   VAR    cUF             INIT "SP"                    // Modificada conforme m�todo
   VAR    cCertificado    INIT ""                      // CN (NOME) do certificado

   /* conting�ncia e sinc/assinc */

   VAR    lEnvioSinc      INIT .T.                     // Envio j� retorna protocolo
   VAR    lEnvioZip       INIT .F.                     // Envio de zip
   VAR    lConsumidor     INIT .F.                     // NFCe

   /* pra NFCe */

   VAR    lContingencia   INIT .F.
   VAR    cIdToken        INIT StrZero( 0, 6 )         // Para NFCe obrigatorio identificador do CSC C�digo de Seguran�a do Contribuinte
   VAR    cCSC            INIT StrZero( 0, 36 )        // Para NFCe obrigatorio CSC C�digo de Seguran�a do Contribuinte

   /* configura��o n�o comum */

   VAR    cVersaoQrCode   INIT "2.00"                  // Versao do QRCode
   VAR    nTempoEspera    INIT 10                      // intervalo entre envia lote e consulta recibo
   VAR    nSoapTimeOut    INIT 15000                  // Limite de espera por resposta em segundos * 1000
   VAR    ValidFromDate   INIT ""                      // Validade do certificado
   VAR    ValidToDate     INIT ""                      // Validade do certificado
   VAR    cUFTimeZone     INIT ""                      // Para TimeZone diferente da UF de comunica��o
   VAR    cUserTimeZone   INIT ""                      // Para TimeZone definido pelo usu�rio
   VAR    cPassword       INIT ""                      // Senha de arquivo PFX
   VAR    cCertNomecer    INIT ""
   VAR    cCertEmissor    INIT ""
   VAR    dCertDataini    INIT Ctod( "" )
   VAR    dCertDatafim    INIT Ctod( "" )
   VAR    cCertImprDig    INIT ""
   VAR    cCertSerial     INIT ""
   VAR    nCertVersao     INIT 0
   VAR    lCertInstall    INIT .F.
   VAR    lCertVencido    INIT .F.
   VAR    cProxyUrl       INIT ""
   VAR    cProxyUser      INIT ""
   VAR    cProxyPassword  INIT ""
   VAR    cTransportePreferido INIT "MSXML"
   VAR    lFallbackAutomatico INIT .T.
   VAR    cUltimoTransporte INIT ""
   VAR    cUltimoErroTransporte INIT ""
   VAR    nTempoUltimoEnvio INIT 0
   VAR    lDebug         INIT .F.
   VAR    cLogDir        INIT ""
   VAR    lUseWinHttp     INIT .F.                    // Transporte nativo via WinHTTP
   VAR    lWinHttpInsecure INIT .F.
   VAR    nWinHttpStatus  INIT 0
   VAR    cWinHttpLastError INIT ""
   VAR    lUseCurl        INIT .F.                    // Transporte alternativo via curl.exe
   VAR    cCurlExe        INIT "curl.exe"
   VAR    cCurlCertFile   INIT ""                     // PFX/P12 ou PEM publico
   VAR    cCurlKeyFile    INIT ""                     // chave privada PEM, quando aplicavel
   VAR    cCurlCertType   INIT "P12"                  // P12/PEM/DER
   VAR    cCurlCertPassword INIT ""
   VAR    cCurlCAInfo     INIT ""
   VAR    lCurlInsecure   INIT .F.
   VAR    nCurlHttpStatus INIT 0
   VAR    cCurlLastError  INIT ""
   VAR    lCurlKeepTemp   INIT .F.
   VAR    cCurlTempBase   INIT ""

   /* XMLs de cada etapa, se precisar conferir */

   VAR    cXmlDocumento   INIT ""                      // O documento oficial, com ou sem assinatura, depende do documento
   VAR    cXmlEnvio       INIT ""                      // usado pra criar/complementar XML do documento
   VAR    cXmlSoap        INIT ""                      // XML completo enviado pra Sefaz, incluindo informa��es do envelope
   VAR    cXmlRetorno     INIT [<erro text="*ERRO* Erro Desconhecido" />]    // Retorno do webservice e/ou rotina
   VAR    cXmlRecibo      INIT ""                      // XML recibo (obtido no envio do lote)
   VAR    cXmlProtocolo   INIT ""                      // XML protocolo (obtido no consulta recibo e/ou envio de outros docs)
   VAR    cXmlAutorizado  INIT ""                      // XML autorizado, caso tudo ocorra sem problemas
   VAR    cRecibo         INIT ""                      // N�mero do recibo
   VAR    cMotivo         INIT ""                      // Motivo constante no Recibo
   VAR    nStatus         INIT 0                       // Status retornado pela SEFAZ
   VAR    oRetorno        INIT NIL                     // Hash padronizado do ultimo retorno
   VAR    aRetornoEventos INIT {}                      // Eventos/protocolos retornados no ultimo lote

   /* uso interno */

   VAR    cSoapAction     INIT ""                      // webservice Action
   VAR    cSoapURL        INIT ""                      // webservice Endere�o
   VAR    cXmlNameSpace   INIT "xmlns="
   VAR    aSoapUrlList    INIT {}

   METHOD BPeProtocolo( ... )             INLINE ze_sefaz_BPeProtocolo( Self, ... )
   METHOD BPeStatus( ... )                INLINE ze_sefaz_BPeStatus( Self, ... )
   METHOD CTeAddCancelamento( ... )       INLINE ze_sefaz_CTeAddCancelamento( Self, ... )
   METHOD CTeEnvio( ... )                 INLINE ze_sefaz_CTeEnvio( Self, ... )
   METHOD CTeEvento( ... )                INLINE ze_sefaz_CTeEvento( Self, ... )
   METHOD CTeEventoCancela( ... )         INLINE ze_sefaz_CTeEventoCancela( Self, ... )
   METHOD CTeEventoCancEntrega( ... )     INLINE ze_sefaz_CTeEventoCancEntrega( Self, ... )
   METHOD CTeEventoCancInsucessoEntrega( ... ) INLINE ze_sefaz_CTeEventoCancInsucessoEntrega( Self, ... )
   METHOD CTeEventoCarta( ... )           INLINE ze_sefaz_CTeEventoCarta( Self, ... )
   METHOD CTeEventoDesacordo( ... )       INLINE ze_sefaz_CTeEventoDesacordo( Self, ... )
   METHOD CTeEventoEntrega( ... )         INLINE ze_sefaz_CTeEventoEntrega( Self, ... )
   METHOD CTeEventoInsucessoEntrega( ... ) INLINE ze_sefaz_CTeEventoInsucessoEntrega( Self, ... )
   METHOD CTeGeraAutorizado( ... )        INLINE ze_sefaz_CTeGeraAutorizado( Self, ... )
   METHOD CTeGeraEventoAutorizado( ... )  INLINE ze_sefaz_CTeGeraEventoAutorizado( Self, ... )
   METHOD CTeInutiliza( ... )             INLINE ze_sefaz_CTeInutiliza( Self, ... )
   METHOD CTeProtocolo( ... )             INLINE ze_sefaz_CTeProtocolo( Self, ... )
   METHOD CTeRetEnvio( ... )              INLINE ze_sefaz_CTeRetEnvio( Self, ... )
   METHOD CTeStatus( ... )                INLINE ze_sefaz_CTeStatus( Self, ... )
   METHOD MDFeDistribuicao( ... )         INLINE ze_sefaz_MDFeDistribuicao( Self, ... )
   METHOD MDFeEnvio( ... )                INLINE ze_sefaz_MDFeEnvio( Self, ... )
   METHOD MDFeEmAberto( ... )             INLINE ze_sefaz_MDFeEmAberto( Self, ... )
   METHOD MDFeEvento( ... )               INLINE ze_sefaz_MDFeEvento( Self, ... )
   METHOD MDFeEventoCancela( ... )        INLINE ze_sefaz_MDFeEventoCancela( Self, ... )
   METHOD MDFeEventoCondutor( ... )       INLINE ze_sefaz_MDFeEventoCondutor( Self, ... )
   METHOD MDFeEventoEncerramento( ... )   INLINE ze_sefaz_MDFeEventoEncerramento( Self, ... )
   METHOD MDFeEventoPagamento( ... )      INLINE ze_sefaz_MDFeEventoPagamento( Self, ... )
   METHOD MDFeGeraAutorizado( ... )       INLINE ze_sefaz_MDFeGeraAutorizado( Self, ... )
   METHOD MDFeGeraEventoAutorizado( ... ) INLINE ze_sefaz_MDFeGeraEventoAutorizado( Self, ... )
   METHOD MDFeProtocolo( ... )            INLINE ze_sefaz_MDFeProtocolo( Self, ... )
   METHOD MDFeRetEnvio( ... )             INLINE ze_sefaz_MDFeRetEnvio( Self, ... )
   METHOD MDFeStatus( ... )               INLINE ze_sefaz_MDFeStatus( Self, ... )
   METHOD NFeAddCancelamento( ... )       INLINE ze_sefaz_NFeAddCancelamento( Self, ... )
   METHOD NFeCadastro( ... )              INLINE ze_sefaz_NFeCadastro( Self, ... )
   METHOD NFeContingencia( ... )          INLINE ze_sefaz_NFeContingencia( Self, ... )
   METHOD NFeDestinadas( ... )            INLINE ze_sefaz_NfeDestinadas( Self, ... )
   METHOD NFeDistribuicao( ... )          INLINE ze_sefaz_NFeDistribuicao( Self, ... )
   METHOD NFeDownload( cCnpj, cChave, cCertificado, cAmbiente ) ;
      INLINE ::NfeDistribuicao( cCnpj, "", "", cChave, ::UFCodigo( Left( cChave, 2 ) ), cCertificado, cAmbiente )
   METHOD NFeEnvio( ... )                 INLINE ze_sefaz_NfeEnvio( Self, ... )
   METHOD NFeEvento( ... )                INLINE ze_sefaz_NFeEvento( Self, ... )
   METHOD NFeEventoAutor( ... )           INLINE ze_sefaz_NFeEventoAutor( Self, ... )
   METHOD NFeEventoCancela( ... )         INLINE ze_sefaz_NFeEventoCancela( Self, ... )
   METHOD NFeEventoCancelaSubstituicao( ... ) INLINE ze_sefaz_NFeEventoCancelaSubstituicao( Self, ... )
   METHOD NFeEventoCarta( ... )           INLINE ze_sefaz_NFeEventoCarta( Self, ... )
   METHOD NFeEventoDataEntrega( ... )     INLINE ze_sefaz_NFeEventoDataEntrega( Self, ... )
   METHOD NFeEventoManifestacao( ... )    INLINE ze_sefaz_NFeEventoManifestacao( Self, ... )
   METHOD NFeGeraAutorizado( ... )        INLINE ze_sefaz_NFeGeraAutorizado( Self, ... )
   METHOD NFeGeraEventoAutorizado( ... )  INLINE ze_sefaz_NFeGeraEventoAutorizado( Self, ... )
   METHOD NFeGTIN( ... )                  INLINE ze_sefaz_NFeGTIN( Self, ... )
   METHOD NFeInutiliza( ... )             INLINE ze_sefaz_NFeInutiliza( Self, ... )
   METHOD NFeProtocolo( ... )             INLINE ze_sefaz_NfeProtocolo( Self, ... )
   METHOD NFeRetEnvio( ... )              INLINE ze_sefaz_NFeRetEnvio( Self, ... )
   METHOD NFeStatus( ... )                INLINE ze_sefaz_NFeStatus( Self, ... )

   METHOD Setup( ... )                    INLINE ze_sefaz_Setup( Self, ... )

   /* Uso interno */

   METHOD CertificadoPfx( cFileName, cPassword )
   METHOD SetCertificadoA1( cPfxFile, cPassword )
   METHOD SetCertificadoA3( cNomeOuThumbprint )
   METHOD LoadConfigIni( cFileName )
   METHOD UseCurl( lUse, cCertFile, cPassword, cCertType, cKeyFile )
   METHOD UseWinHttp( lUse, cPfxFile, cPassword, lIgnoreSsl )
   METHOD SetTransporte( cTransporte, lFallback )
   METHOD SetDebug( lDebug, cLogDir )
   METHOD ValidarCertificado()
   METHOD Diagnostico()
   METHOD DanfeSimplificadoHtml( cXml, cLogoHtml )
   METHOD DanfeSimplificadoTexto( cXml )
   METHOD DanfeSimplificadoSalvarHtml( cArquivoSaida, cXml, cLogoHtml )
   METHOD XmlSoapPost()
   METHOD MicrosoftXmlSoapPost()
   METHOD WinHttpSoapPost()
   METHOD CurlSoapPost()
   METHOD ExecutaTransporte()
   METHOD LogTecnico( cEtapa )

   /* Apenas redirecionamento */

   METHOD AssinaXml()
   METHOD TipoXml( cXml )                             INLINE TipoXml( cXml )
   METHOD UFCodigo( cSigla )                          INLINE UFCodigo( cSigla )
   METHOD UFSigla( cCodigo )                          INLINE UFSigla( cCodigo )
   METHOD DateTimeXml( dDate, cTime, lUTC )           INLINE DateTimeXml( dDate, cTime, iif( Empty( ::cUFTimeZone ), ::cUF, ::cUFTimeZone ), lUTC, ::cUserTimeZone )
   METHOD ValidaXml( cXml, cFileXsd, cIgnoreList )    INLINE ::cXmlRetorno := DomDocValidaXml( cXml, cFileXsd, cIgnoreList )

   /* obsoleto / compatibilidade */

   METHOD cStatus         SETGET           // Status da resposta da SEFAZ, 3 ou 4 caracteres
   METHOD NFeStatusSVC( cUF, cCertificado, cAmbiente ) ;
                                          INLINE ::NfeStatus( cUF, cCertificado, cAmbiente, .T. )
   METHOD cIndSinc( cValue )                SETGET
   METHOD cFusoHorario                      SETGET
   METHOD cNFCe                             SETGET
   METHOD lSincrono                         SETGET
   METHOD CTeConsultaProtocolo( ... )       INLINE ::CTeProtocolo( ... )
   METHOD CTeConsultaRecibo( ... )          INLINE ::CTeRetEnvio( ... )
   METHOD CTeLoteEnvia( cXml, cLote, ... )  INLINE (cLote),::CTeEnvio( cXml, ... )
   METHOD CTeStatusServico( ... )           INLINE ::CTeStatus( ... )
   METHOD NFeLoteEnvia( cXml, cLote, ... )  INLINE (cLote), ::NFeEnvio( cXml, ... )
   METHOD NFeConsultaRecibo( ... )          INLINE ::NFeRetEnvio( ... )
   METHOD NFeConsultaProtocolo( ... )       INLINE ::NFeProtocolo( ... )
   METHOD NFeStatusServico( ... )           INLINE ::NFeStatus( ... )
   METHOD NFeConsultaCadastro( ... )        INLINE ::NFeCadastro( ... )
   METHOD NFeConsultaGTIN( ... )            INLINE ::NFeGTIN( ... )
   METHOD NFeDistribuicaoDFe( ... )         INLINE ::NFeDistribuicao( ... )
   METHOD NFeConsultaDest( ... )            INLINE ::NfeDestinadas( ... )
   METHOD MDFeLoteEnvia( cXml, cLote, ...)  INLINE (cLote), ::MDFeEnvio( cXml, ... )
   METHOD MDFeConsultaRecibo( ... )         INLINE ::MDFeRetEnvio( ... )
   METHOD MDFeConsultaProtocolo( ... )      INLINE ::MDFeProtocolo( ... )
   METHOD MDFeStatusServico( ... )          INLINE ::MDFeStatus( ... )
   METHOD MDFeConsNaoEnc( ... )             INLINE ::MDFeEmAberto( ... )
   METHOD MDFeDistribuicaoDFe( ...)         INLINE ::MDFeDistribuicao( ... )
   METHOD MDFeEventoInclusaoCondutor( ... ) INLINE ::MDFeCondutor( ... )
   METHOD NFeStatusServicoSVC( ... )        INLINE ::NFeStatusSVC( ... )

   ENDCLASS

METHOD cStatus( xValue )  CLASS SefazClass

   IF ::nStatus < 1000
      xValue := StrZero( ::nStatus, 3 )
   ELSE
      xValue := StrZero( ::nStatus, 4 )
   ENDIF

   RETURN xValue

METHOD cIndSinc( cValue ) CLASS SefazClass

   IF cValue != Nil
      IF ValType( cValue ) == "C" .AND. cValue == "1"
         ::lEnvioSinc := .T.
      ELSE
         ::lEnvioSinc := .F.
      ENDIF
   ENDIF

   RETURN iif( ::lEnvioSinc, "1", "0" )

METHOD cFusoHorario( cValue ) CLASS SefazClass

   IF cValue != Nil
      ::cUserTimeZone := cValue
   ENDIF

   RETURN ::cUserTimeZone

METHOD cNFCe( cValue ) CLASS Sefazclass

   IF cValue != Nil
      ::lConsumidor := ( cValue == "S" )
   ENDIF

   RETURN iif( ::lConsumidor, "S", "N" )

METHOD lSincrono( lValue ) CLASS SefazClass


   IF lValue != Nil
      ::lEnvioSinc := lValue
   ENDIF

   RETURN ::lEnvioSinc

METHOD AssinaXml() CLASS SefazClass

   ::cXmlRetorno := SefazAssinaXmlSha1( @::cXmlDocumento, ::cCertificado, ::cPassword )
   IF ::cXmlRetorno != "OK"
      ::nStatus := 999
      ::cMotivo := ::cXmlRetorno
      ::cXmlRetorno := [<erro text="] + "*erro* " + ::cXmlRetorno + ["</erro>]
   ENDIF

   RETURN ::cXmlRetorno

METHOD CertificadoPfx( cFileName, cPassword ) CLASS SefazClass

   LOCAL oCert := ImportarCertificadoPfxNative( cFileName, cPassword )

   IF oCert == NIL
      ::nStatus := 999
      ::cMotivo := "Erro importando PFX em memoria"
      RETURN NIL
   ENDIF

   ::cCertificado := cFileName
   ::cPassword := hb_DefaultValue( cPassword, ::cPassword )
   ::cCertNomecer := oCert:cCertNomecer
   ::cCertEmissor := oCert:cCertEmissor
   ::dCertDataini := oCert:dCertDataini
   ::dCertDatafim := oCert:dCertDatafim
   ::cCertImprDig := oCert:cCertImprDig
   ::cCertSerial := oCert:cCertSerial
   ::nCertVersao := oCert:nCertVersao
   ::lCertInstall := .F.
   ::lCertVencido := oCert:lCertVencido

RETURN oCert
METHOD LoadConfigIni( cFileName ) CLASS SefazClass
RETURN SefazAplicarConfigIni( Self, hb_DefaultValue( cFileName, "sefaz.ini" ) )
METHOD DanfeSimplificadoHtml( cXml, cLogoHtml ) CLASS SefazClass

   IF Empty( cXml )
      cXml := IIf( Empty( ::cXmlAutorizado ), ::cXmlRetorno, ::cXmlAutorizado )
   ENDIF

RETURN SefazDanfeSimplificadoHtml( cXml, cLogoHtml )

METHOD DanfeSimplificadoTexto( cXml ) CLASS SefazClass

   IF Empty( cXml )
      cXml := IIf( Empty( ::cXmlAutorizado ), ::cXmlRetorno, ::cXmlAutorizado )
   ENDIF

RETURN SefazDanfeSimplificadoTexto( cXml )

METHOD DanfeSimplificadoSalvarHtml( cArquivoSaida, cXml, cLogoHtml ) CLASS SefazClass

   IF Empty( cXml )
      cXml := IIf( Empty( ::cXmlAutorizado ), ::cXmlRetorno, ::cXmlAutorizado )
   ENDIF

RETURN SefazDanfeSimplificadoSalvarHtml( cXml, cArquivoSaida, cLogoHtml )
METHOD SetCertificadoA1( cPfxFile, cPassword ) CLASS SefazClass

   LOCAL oCert := ::CertificadoPfx( cPfxFile, cPassword )

   IF oCert != NIL
      ::UseWinHttp( .T., cPfxFile, cPassword )
   ENDIF

RETURN oCert

METHOD SetCertificadoA3( cNomeOuThumbprint ) CLASS SefazClass

   ::cCertificado := hb_DefaultValue( cNomeOuThumbprint, ::cCertificado )
   ::cPassword := ""
   ::SetTransporte( "WINHTTP" )

RETURN ::cCertificado
METHOD UseCurl( lUse, cCertFile, cPassword, cCertType, cKeyFile ) CLASS SefazClass

   IF lUse != NIL
      ::lUseCurl := lUse
   ELSE
      ::lUseCurl := .T.
   ENDIF
   IF cCertFile != NIL
      ::cCurlCertFile := cCertFile
   ENDIF
   IF cPassword != NIL
      ::cCurlCertPassword := cPassword
      ::cPassword := cPassword
   ENDIF
   IF cCertType != NIL
      ::cCurlCertType := Upper( cCertType )
   ENDIF
   IF cKeyFile != NIL
      ::cCurlKeyFile := cKeyFile
   ENDIF

RETURN ::lUseCurl

METHOD UseWinHttp( lUse, cPfxFile, cPassword, lIgnoreSsl ) CLASS SefazClass

   IF lUse != NIL
      ::lUseWinHttp := lUse
   ELSE
      ::lUseWinHttp := .T.
   ENDIF
   IF cPfxFile != NIL
      ::cCertificado := cPfxFile
      ::cCurlCertFile := cPfxFile
      ::cCurlCertType := "P12"
   ENDIF
   IF cPassword != NIL
      ::cPassword := cPassword
      ::cCurlCertPassword := cPassword
   ENDIF
   IF lIgnoreSsl != NIL
      ::lWinHttpInsecure := lIgnoreSsl
   ENDIF

RETURN ::lUseWinHttp


METHOD SetTransporte( cTransporte, lFallback ) CLASS SefazClass

   IF cTransporte != NIL
      ::cTransportePreferido := Upper( AllTrim( cTransporte ) )
   ENDIF
   IF Empty( ::cTransportePreferido )
      ::cTransportePreferido := "MSXML"
   ENDIF
   IF lFallback != NIL
      ::lFallbackAutomatico := lFallback
   ENDIF
   ::lUseWinHttp := ::cTransportePreferido == "WINHTTP" .OR. ::cTransportePreferido == "AUTO"
   ::lUseCurl := ::cTransportePreferido == "CURL"

RETURN ::cTransportePreferido

METHOD SetDebug( lDebug, cLogDir ) CLASS SefazClass

   IF lDebug != NIL
      ::lDebug := lDebug
   ELSE
      ::lDebug := .T.
   ENDIF
   IF cLogDir != NIL
      ::cLogDir := cLogDir
   ENDIF
   IF Empty( ::cLogDir )
      ::cLogDir := "logs"
   ENDIF
   SefazEnsureDir( ::cLogDir )

RETURN ::lDebug
METHOD XmlSoapPost() CLASS SefazClass

   LOCAL cXmlns := ;
      [xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" ] + ;
      [xmlns:xsd="http://www.w3.org/2001/XMLSchema" ] + ;
      [xmlns:soap12="http://www.w3.org/2003/05/soap-envelope"]
   LOCAL cSoapVersion, cSoapService

   DO CASE
   CASE Empty( ::cSoapURL )
      ::cXmlRetorno := [<erro text="*ERRO* XmlSoapPost(): N�o h� endere�o de webservice" />]
      ::nStatus     := 999
      ::cMotivo     := "Erro de comunica��o: sem endere�o de internet"
      SefazRetornoAplicar( Self, ::cXmlRetorno )
      RETURN NIL
   CASE Empty( ::cSoapAction )
      ::cXmlRetorno := [<erro text="*ERRO* XmlSoapPost(): N�o h� endere�o de SOAP Action" />]
      ::nStatus     := 999
      ::cMotivo     := "Erro de comunica��o: sem SOAP Action"
      SefazRetornoAplicar( Self, ::cXmlRetorno )
      RETURN NIL
   ENDCASE

   cSoapService := Substr( ::cSoapAction, 1, Rat( "/", ::cSoapAction ) - 1 )
   ::cSoapAction  := Substr( ::cSoapAction, Rat( "/", ::cSoapAction ) + 1 )

   cSoapVersion := ::cVersao
   IF "CadConsultaCadastro" $ ::cSoapAction
      cSoapVersion := "2.00"
   ELSEIF "nfeRecepcaoEvento" $ ::cSoapAction
      cSoapVersion := "1.00"
   ENDIF
   ::cXmlSoap := XML_UTF8
   ::cXmlSoap += [<soap12:Envelope ] + cXmlns + [>]
   IF "GTIN" $ Upper( ::cSoapAction )
      ::cXmlSoap += [<soap12:Body>]
      ::cXmlSoap +=    [<ccgConsGTIN xmlns="] + cSoapService + [">]
      ::cXmlSoap +=       [<] + ::cProjeto + [DadosMsg xmlns="] + cSoapService + [">]
      ::cXmlSoap +=          ::cXmlEnvio
      ::cXmlSoap +=       [</] + ::cProjeto + [DadosMsg>]
      ::cXmlSoap +=    [</ccgConsGTIN>]
      ::cXmlSoap += [</soap12:Body>]
   ELSEIF "nfeDistDFeInteresse" $ ::cSoapAction
      ::cXmlSoap += [<soap12:Body>]
      ::cXmlSoap +=    [<nfeDistDFeInteresse xmlns="] + cSoapService + [">]
      ::cXmlSoap +=       [<] + ::cProjeto + [DadosMsg>]
      ::cXmlSoap +=          ::cXmlEnvio
      ::cXmlSoap +=       [</] + ::cProjeto + [DadosMsg>]
      ::cXmlSoap +=    [</nfeDistDFeInteresse>]
      ::cXmlSoap += [</soap12:Body>]
   ELSEIF ::cProjeto == WS_PROJETO_MDFE .OR. ::cProjeto == WS_PROJETO_CTE
      ::cXmlSoap += [<soap12:Body>]
      ::cXmlSoap +=    [<] + ::cProjeto + [DadosMsg xmlns="] + cSoapService + [">]
      IF ::lEnvioZip
         ::cXmlSoap += hb_base64Encode( hb_gzCompress( ::cXmlEnvio ) )
      ELSE
         ::cXmlSoap +=       ::cXmlEnvio
      ENDIF
      ::cXmlSoap +=    [</] + ::cProjeto + [DadosMsg>]
      ::cXmlSoap += [</soap12:Body>]
   ELSEIF "LOTEZIP" $ Upper( ::cSoapAction ) // aqui DadosMsgZip
      ::cXmlSoap += [<soap12:Body>]
      ::cXmlSoap +=    [<] + ::cProjeto + [DadosMsgZip xmlns="] + cSoapService + [">]
      ::cXmlSoap += hb_base64Encode( hb_gzCompress( ::cXmlEnvio ) )
      ::cXmlSoap +=    [</] + ::cProjeto + [DadosMsgZip>]
      ::cXmlSoap += [</soap12:Body>]
   ELSE
      IF ! "NFERECEPCAOEVENTO" $ Upper( ::cSoapAction )
         ::cXmlSoap += [<soap12:Header>]
         ::cXmlSoap +=    [<] + ::cProjeto + [CabecMsg xmlns="] + cSoapService + [">]
         ::cXmlSoap +=       [<cUF>] + ::UFCodigo( ::cUF ) + [</cUF>]
         ::cXmlSoap +=       [<versaoDados>] + cSoapVersion + [</versaoDados>]
         ::cXmlSoap +=    [</] + ::cProjeto + [CabecMsg>]
         ::cXmlSoap += [</soap12:Header>]
      ENDIF
      ::cXmlSoap += [<soap12:Body>]
      ::cXmlSoap +=    [<] + ::cProjeto + [DadosMsg xmlns="] + cSoapService + [">]
      IF ::lEnvioZip
         ::cXmlSoap += hb_base64Encode( hb_gzCompress( ::cXmlEnvio ) )
      ELSE
         ::cXmlSoap += ::cXmlEnvio
      ENDIF
      ::cXmlSoap +=    [</] + ::cProjeto + [DadosMsg>]
      ::cXmlSoap += [</soap12:Body>]
   ENDIF
   ::cXmlSoap += [</soap12:Envelope>]
   ::LogTecnico( "antes_envio" )
   ::ExecutaTransporte()
   ::LogTecnico( "apos_envio" )
   ::lEnvioZip := .F. // somente autoriza��o � zip

   RETURN NIL

METHOD ExecutaTransporte() CLASS SefazClass

   LOCAL aTransp := SefazTransporteLista( ::cTransportePreferido, ::lUseWinHttp, ::lUseCurl, ::lFallbackAutomatico )
   LOCAL cTransp, nInicio, lOk := .F.

   ::cUltimoErroTransporte := ""
   FOR EACH cTransp IN aTransp
      nInicio := Seconds()
      ::cUltimoTransporte := cTransp
      ::nStatus := 0
      ::cMotivo := ""
      ::cXmlRetorno := ""
      DO CASE
      CASE cTransp == "WINHTTP"
         ::WinHttpSoapPost()
         ::cUltimoErroTransporte := SefazWinHttpErroAmigavel( ::cWinHttpLastError )
      CASE cTransp == "CURL"
         ::CurlSoapPost()
         ::cUltimoErroTransporte := ::cCurlLastError
      OTHERWISE
         ::MicrosoftXmlSoapPost()
         ::cUltimoErroTransporte := ::cMotivo
      ENDCASE
      ::nTempoUltimoEnvio := Max( 0, Seconds() - nInicio )
      ::LogTecnico( "transporte_" + Lower( cTransp ) )
      lOk := ! SefazErroComunicacao( ::nStatus, ::cXmlRetorno, ::cMotivo )
      IF lOk .OR. ! ::lFallbackAutomatico
         EXIT
      ENDIF
   NEXT

   IF ! lOk .AND. Empty( ::cMotivo ) .AND. ! Empty( ::cUltimoErroTransporte )
      ::cMotivo := ::cUltimoErroTransporte
   ENDIF

RETURN lOk

METHOD ValidarCertificado() CLASS SefazClass

   LOCAL hRet := hb_Hash(), oCert := NIL, cCert := ::cCertificado

   hRet[ "ok" ] := .F.
   hRet[ "motivo" ] := ""
   hRet[ "tipo" ] := ""
   hRet[ "subject" ] := ""
   hRet[ "thumbprint" ] := ""
   hRet[ "validadeInicial" ] := Ctod( "" )
   hRet[ "validadeFinal" ] := Ctod( "" )
   hRet[ "vencido" ] := .F.

   IF Empty( cCert )
      hRet[ "motivo" ] := "Certificado nao informado"
      RETURN hRet
   ENDIF

   IF Lower( Right( cCert, 4 ) ) == ".pfx" .OR. Lower( Right( cCert, 4 ) ) == ".p12"
      hRet[ "tipo" ] := "A1-PFX"
      IF ! File( cCert )
         hRet[ "motivo" ] := "Arquivo PFX/P12 nao encontrado: " + cCert
         RETURN hRet
      ENDIF
      oCert := ImportarCertificadoPfxNative( cCert, ::cPassword )
      IF oCert == NIL
         hRet[ "motivo" ] := "PFX/P12 invalido ou senha incorreta"
         RETURN hRet
      ENDIF
   ELSE
      hRet[ "tipo" ] := "STORE/A3"
      oCert := SefazCertificado( cCert, , , .F. )
      IF oCert == NIL
         hRet[ "motivo" ] := "Certificado nao encontrado no CurrentUser\\MY: " + cCert
         RETURN hRet
      ENDIF
   ENDIF

   hRet[ "subject" ] := oCert:SubjectName
   hRet[ "thumbprint" ] := oCert:ThumbPrint
   hRet[ "validadeInicial" ] := oCert:ValidFromDate
   hRet[ "validadeFinal" ] := oCert:ValidToDate
   hRet[ "vencido" ] := oCert:ValidToDate < Date()

   DO CASE
   CASE oCert:ValidFromDate > Date()
      hRet[ "motivo" ] := "Certificado ainda nao esta valido"
   CASE oCert:ValidToDate < Date()
      hRet[ "motivo" ] := "Certificado vencido em " + DToC( oCert:ValidToDate )
   OTHERWISE
      hRet[ "ok" ] := .T.
      hRet[ "motivo" ] := "OK"
   ENDCASE

RETURN hRet

METHOD Diagnostico() CLASS SefazClass

   LOCAL hCert := ::ValidarCertificado(), cTxt := ""

   cTxt += "SEFAZClass diagnostico" + hb_Eol()
   cTxt += "Data/hora: " + DToC( Date() ) + " " + Time() + hb_Eol()
   cTxt += "Harbour: " + Version() + hb_Eol()
   cTxt += "Projeto: " + hb_DefaultValue( ::cProjeto, "" ) + hb_Eol()
   cTxt += "UF: " + hb_DefaultValue( ::cUF, "" ) + hb_Eol()
   cTxt += "Ambiente: " + hb_DefaultValue( ::cAmbiente, "" ) + hb_Eol()
   cTxt += "Transporte preferido: " + hb_DefaultValue( ::cTransportePreferido, "" ) + hb_Eol()
   cTxt += "Fallback automatico: " + IIf( ::lFallbackAutomatico, "SIM", "NAO" ) + hb_Eol()
   cTxt += "WinHTTP ativo: " + IIf( ::lUseWinHttp, "SIM", "NAO" ) + hb_Eol()
   cTxt += "Curl ativo: " + IIf( ::lUseCurl, "SIM", "NAO" ) + hb_Eol()
   cTxt += "Ultimo transporte: " + hb_DefaultValue( ::cUltimoTransporte, "" ) + hb_Eol()
   cTxt += "Ultimo HTTP WinHTTP: " + AllTrim( Str( ::nWinHttpStatus ) ) + hb_Eol()
   cTxt += "Ultimo erro WinHTTP: " + SefazWinHttpErroAmigavel( ::cWinHttpLastError ) + hb_Eol()
   cTxt += "Ultimo HTTP curl: " + AllTrim( Str( ::nCurlHttpStatus ) ) + hb_Eol()
   cTxt += "Ultimo erro curl: " + hb_DefaultValue( ::cCurlLastError, "" ) + hb_Eol()
   cTxt += "Certificado OK: " + IIf( hCert[ "ok" ], "SIM", "NAO" ) + hb_Eol()
   cTxt += "Certificado tipo: " + hCert[ "tipo" ] + hb_Eol()
   cTxt += "Certificado motivo: " + hCert[ "motivo" ] + hb_Eol()
   cTxt += "Certificado subject: " + hCert[ "subject" ] + hb_Eol()
   cTxt += "Certificado thumbprint: " + hCert[ "thumbprint" ] + hb_Eol()
   cTxt += "Certificado validade: " + DToC( hCert[ "validadeInicial" ] ) + " a " + DToC( hCert[ "validadeFinal" ] ) + hb_Eol()

RETURN cTxt

METHOD LogTecnico( cEtapa ) CLASS SefazClass

   LOCAL cDir, cBase, cTexto := "", cResumo := ""

   IF ! ::lDebug
      RETURN .F.
   ENDIF
   cDir := IIf( Empty( ::cLogDir ), "logs", ::cLogDir )
   SefazEnsureDir( cDir )
   cBase := SefazPathJoin( cDir, DToS( Date() ) + "_" + StrTran( Time(), ":", "" ) + "_" + SefazFileSafe( hb_DefaultValue( cEtapa, "log" ) ) )
   IF ValType( ::oRetorno ) == "H"
      cResumo := SefazRetornoResumo( ::oRetorno )
   ENDIF
   cTexto += "etapa=" + hb_DefaultValue( cEtapa, "" ) + hb_Eol()
   cTexto += "data=" + DToC( Date() ) + " " + Time() + hb_Eol()
   cTexto += "transporte=" + hb_DefaultValue( ::cUltimoTransporte, "" ) + hb_Eol()
   cTexto += "preferido=" + hb_DefaultValue( ::cTransportePreferido, "" ) + hb_Eol()
   cTexto += "tempo=" + AllTrim( Str( ::nTempoUltimoEnvio ) ) + hb_Eol()
   cTexto += "status=" + AllTrim( Str( ::nStatus ) ) + hb_Eol()
   cTexto += "motivo=" + hb_DefaultValue( ::cMotivo, "" ) + hb_Eol()
   cTexto += "resumo=" + cResumo + hb_Eol()
   cTexto += "winhttpStatus=" + AllTrim( Str( ::nWinHttpStatus ) ) + hb_Eol()
   cTexto += "winhttpErro=" + SefazWinHttpErroAmigavel( ::cWinHttpLastError ) + hb_Eol()
   cTexto += "curlStatus=" + AllTrim( Str( ::nCurlHttpStatus ) ) + hb_Eol()
   cTexto += "curlErro=" + hb_DefaultValue( ::cCurlLastError, "" ) + hb_Eol()
   hb_MemoWrit( cBase + ".log", cTexto )
   IF ! Empty( ::cXmlSoap )
      hb_MemoWrit( cBase + "_soap.xml", SefazXmlSanitize( ::cXmlSoap ) )
   ENDIF
   IF ! Empty( ::cXmlRetorno )
      hb_MemoWrit( cBase + "_retorno.xml", SefazXmlSanitize( ::cXmlRetorno ) )
   ENDIF

RETURN .T.
METHOD MicrosoftXmlSoapPost() CLASS SefazClass

   LOCAL oServer, nCont, cRetorno, lOk, cBlocoValido
   LOCAL cSoapAction

   cSoapAction := ::cSoapAction
   lOk := .F.
   BEGIN SEQUENCE WITH __BreakBlock()
      oServer := win_OleCreateObject( "MSXML2.ServerXMLHTTP.6.0" )
      lOk := .T.
   ENDSEQUENCE
   IF ! lOk
      ::cXmlRetorno := "<xml>*ERRO* Erro: No uso do objeto MSXML2.ServerXmlHTTP.6.0</xml>"
      SefazRetornoAplicar( Self, ::cXmlRetorno )
      RETURN Nil
   ENDIF
   IF ::cCertificado != NIL
      oServer:setOption( 3, "CURRENT_USER\MY\" + ::cCertificado )
   ENDIF
   oServer:SetTimeOuts( ::nSoapTimeOut, ::nSoapTimeOut, ::nSoapTimeOut, ::nSoapTimeOut )
   lOk := .F.
   BEGIN SEQUENCE WITH __BreakBlock()
      oServer:Open( "POST", ::cSoapURL, .F. )
      lOk := .T.
   ENDSEQUENCE
   IF ! lOk
      ::cXmlRetorno := "<xml>*ERRO* Erro: No Open() do endere�o " + ::cSoapURL + "</xml>"
      SefazRetornoAplicar( Self, ::cXmlRetorno )
      RETURN Nil
   ENDIF
   IF ! Empty( ::cProxyUrl )
      oServer:SetProxy( 2, ::cProxyUrl )
      IF ! Empty( ::cProxyUser ) .OR. ! Empty( ::cProxyPassword )
         oServer:SetProxyCredentials( ::cProxyUser, ::cProxyPassword )
      ENDIF
   ENDIF
   IF cSoapAction != NIL .AND. ! Empty( cSoapAction )
      oServer:SetRequestHeader( "SOAPAction", cSoapAction )
   ENDIF
   IF ::lEnvioZip
      oServer:SetRequestHeader( "Accept-Encoding", "gzip,deflate" )
      oServer:SetRequestHeader( "Content-Encoding", "gzip" )
   ENDIF
   oServer:SetRequestHeader( "Content-Type", "application/soap+xml; charset=utf-8" )
   oServer:SetRequestHeader( "content-Length", Ltrim( Str( Len( ::cXmlSoap ) ) ) )
   lOk := .F.
   BEGIN SEQUENCE WITH __BreakBlock()
      oServer:Send( ::cXmlSoap )
      lOk := .T.
   ENDSEQUENCE
   IF ! lOk
      ::cXmlRetorno := "<xml>*ERRO* Erro: Send falhou " + ::cSoapURL + "</xml>"
      SefazRetornoAplicar( Self, ::cXmlRetorno )
      RETURN Nil
   ENDIF
   cRetorno := oServer:ResponseXML:XML
   IF Empty( cRetorno )
      cRetorno := oServer:ResponseBody
      IF Empty( cRetorno )
         cRetorno := oServer:ResponseText
      ENDIF
   ENDIF
   IF ValType( cRetorno ) == "C"
      ::cXmlRetorno := cRetorno
   ELSEIF cRetorno == NIL
      ::cXmlRetorno := "Sem retorno do webservice"
   ELSEIF ValType( cRetorno ) == "A" // xharbour e harbour antigo???
      ::cXmlRetorno := ""
      FOR nCont = 1 TO Len( cRetorno )
         ::cXmlRetorno += Chr( cRetorno[ nCont ] )
      NEXT
   ENDIF
   IF "not have permission to view" $ ::cXmlRetorno
      ::nStatus     := 999
      ::cMotivo     := "problemas com Sefaz e/ou certificado"
      ::cXmlRetorno := "<xml>*ERRO* Erro: Sefaz e/ou certificado</xml>"
   ELSE
      lOk := .F.
      FOR EACH cBlocoValido IN { "soap:Body", "soapenv:Body", "env:Body", "S:Body" }
         IF ! Empty( XmlNode( ::cXmlRetorno, cBlocoValido ) )
            ::cXmlRetorno := XmlNode( ::cXmlRetorno, cBlocoValido )
            lOk := .T.
            EXIT
         ENDIF
      NEXT
      IF ! lOk
         // teste usando procname(2)
         ::cXmlRetorno := "<xml>*ERRO* Erro de retorno " + ProcName(2) + ;
            " body n�o identificado " + ::cXmlRetorno + "</xml>"
      ENDIF
   ENDIF
   SefazRetornoAplicar( Self, ::cXmlRetorno )

   RETURN NIL

STATIC FUNCTION UFCodigo( cSigla )

   LOCAL cUFs, cCodigo, nPosicao

   IF Val( cSigla ) > 0
      RETURN cSigla
   ENDIF
   cUFs := "AN,91,AC,12,AL,27,AM,13,AP,16,BA,29,CE,23,DF,53,ES,32,GO,52,MG,31,MS,50,MT,51,MA,21,PA,15,PB,25,PE,26,PI,22,PR,41,RJ,33,RO,11,RN,24,RR,14,RS,43,SC,42,SE,28,SP,35,TO,17,"
   nPosicao := At( cSigla, cUfs )
   IF nPosicao < 1
      cCodigo := "99"
   ELSE
      cCodigo := Substr( cUFs, nPosicao + 3, 2 )
   ENDIF

   RETURN cCodigo

STATIC FUNCTION UFSigla( cCodigo )

   LOCAL cUFs, cSigla, nPosicao

   cCodigo := Left( cCodigo, 2 ) // pode ser chave NFE
   IF Val( cCodigo ) == 0 // n�o � n�mero
      RETURN cCodigo
   ENDIF
   cUFs := "AN,91,AC,12,AL,27,AM,13,AP,16,BA,29,CE,23,DF,53,ES,32,GO,52,MG,31,MS,50,MT,51,MA,21,PA,15,PB,25,PE,26,PI,22,PR,41,RJ,33,RO,11,RN,24,RR,14,RS,43,SC,42,SE,28,SP,35,TO,17,"
   nPosicao := At( cCodigo, cUfs )
   IF nPosicao < 1
      cSigla := "XX"
   ELSE
      cSigla := Substr( cUFs, nPosicao - 3, 2 )
   ENDIF

   RETURN cSigla

STATIC FUNCTION TipoXml( cXml )

   LOCAL aTipos, cTipoXml, cTipoEvento, oElemento

   aTipos := { ;
      { [<infMDFe],   [MDFE] }, ;  // primeiro, pois tem nfe e cte
      { [<cancMDFe],  [MDFEC] }, ;
      { [<infCte],    [CTE]  }, ;  // segundo, pois tem nfe
      { [<cancCTe],   [CTEC] }, ;
      { [<infNFe],    [NFE]  }, ;
      { [<infCanc],   [NFEC] }, ;
      { [<infInut],   [INUT] }, ;
      { [<infEvento], [EVEN] } }

   cTipoXml := "XX"
   FOR EACH oElemento IN aTipos
      IF Upper( oElemento[ 1 ] ) $ Upper( cXml )
         cTipoXml := oElemento[ 2 ]
         IF cTipoXml == "EVEN"
            cTipoEvento := XmlTag( cXml, "tpEvento" )
            DO CASE
            CASE cTipoEvento == "110111"
               IF "<chNFe" $ cXml
                  cTipoXml := "NFEC"
               ENDIF
            CASE cTipoEvento == "110110"
               cTipoXml := "CCE"
            OTHERWISE
               cTipoXml := "OUTROEVENTO"
            ENDCASE
         ENDIF
         EXIT
      ENDIF
   NEXT

   RETURN cTipoXml

STATIC FUNCTION DomDocValidaXml( cXml, cFileXsd, cIgnoreList )

   LOCAL oXmlDomDoc, oXmlSchema, oXmlErro, cRetorno := "ERRO"

   hb_Default( @cFileXsd, "" )

   IF " <" $ cXml .OR. "> " $ cXml
      RETURN "Espa�os inv�lidos no XML entre as tags"
   ENDIF

   IF Empty( cFileXsd )
      RETURN SingleXmlValidate( cXml, cIgnoreList )
   ENDIF
   IF ! File( cFileXSD )
      RETURN "Erro n�o encontrado arquivo " + cFileXSD
   ENDIF

   BEGIN SEQUENCE WITH __BreakBlock()

      cRetorno   := "Erro Carregando MSXML2.DomDocument.6.0"
      oXmlDomDoc := win_OleCreateObject( "MSXML2.DomDocument.6.0" )
      oXmlDomDoc:aSync            := .F.
      oXmlDomDoc:ResolveExternals := .F.
      oXmlDomDoc:ValidateOnParse  := .T.

      cRetorno   := iif( cRetorno == Nil, "", "Erro Carregando XML" )
      oXmlDomDoc:LoadXml( cXml )
      IF oXmlDomDoc:ParseError:ErrorCode <> 0
         cRetorno := "Erro XML inv�lido " + ;
            " Linha: "   + AllTrim( Transform( oXmlDomDoc:ParseError:Line, "" ) ) + ;
            " coluna: "  + AllTrim( Transform( oXmlDomDoc:ParseError:LinePos, "" ) ) + ;
            " motivo: "  + AllTrim( Transform( oXmlDomDoc:ParseError:Reason, "" ) ) + ;
            " errcode: " + AllTrim( Transform( oXmlDomDoc:ParseError:ErrorCode, "" ) )
         BREAK
      ENDIF

      cRetorno   := iif( cRetorno == Nil, "", "Erro Carregando MSXML2.XMLSchemaCache.6.0" )
      oXmlSchema := win_OleCreateObject( "MSXML2.XMLSchemaCache.6.0" )

      cRetorno   := iif( cRetorno == Nil, "", "Erro carregando " + cFileXSD )
      DO CASE
      CASE "mdfe" $ Lower( cFileXsd )
         oXmlSchema:Add( "http://www.portalfiscal.inf.br/mdfe", cFileXSD )
      CASE "cte"  $ Lower( cFileXsd )
         oXmlSchema:Add( "http://www.portalfiscal.inf.br/cte", cFileXSD )
      CASE "nfe"  $ Lower( cFileXsd )
         oXmlSchema:Add( "http://www.portalfiscal.inf.br/nfe", cFileXSD )
      ENDCASE

      oXmlDomDoc:Schemas := oXmlSchema
      oXmlErro := oXmlDomDoc:Validate()
      IF oXmlErro:ErrorCode <> 0
         cRetorno := "Erro: " + AllTrim( Transform( oXmlErro:ErrorCode, "" ) ) + " " + ConverteErroValidacao( oXmlErro:Reason, "" )
         BREAK
      ENDIF
      cRetorno := iif( cRetorno == Nil, "", "OK" )

   ENDSEQUENCE

   RETURN cRetorno

STATIC FUNCTION ConverteErroValidacao( cTexto )

   LOCAL nPosIni, nPosFim

   cTexto := AllTrim( Transform( cTexto, "" ) )
   DO WHILE .T.
      IF ! "{" $ cTexto .OR. ! "}" $ cTexto
         EXIT
      ENDIF
      nPosIni := At( "{", cTexto ) - 1
      nPosFim := At( "}", cTexto ) + 1
      IF nPosIni > nPosFim
         EXIT
      ENDIF
      cTexto := Substr( cTexto, 1, nPosIni ) + Substr( cTexto, nPosFim )
   ENDDO

   RETURN cTexto

METHOD WinHttpSoapPost() CLASS SefazClass

   LOCAL cErro := "", nHttpStatus := 0, cResp, cBlocoValido
   LOCAL cPfxFile := "", cCertSubject := ""

   IF Lower( Right( ::cCertificado, 4 ) ) == ".pfx" .OR. Lower( Right( ::cCertificado, 4 ) ) == ".p12"
      cPfxFile := ::cCertificado
   ELSEIF Lower( Right( ::cCurlCertFile, 4 ) ) == ".pfx" .OR. Lower( Right( ::cCurlCertFile, 4 ) ) == ".p12"
      cPfxFile := ::cCurlCertFile
   ELSE
      cCertSubject := ::cCertificado
   ENDIF

   cResp := SefazWinHttpPost( ::cSoapURL, ::cSoapAction, ::cXmlSoap, cCertSubject, cPfxFile, ::cPassword, ;
      ::nSoapTimeOut, ::cProxyUrl, ::cProxyUser, ::cProxyPassword, ::lWinHttpInsecure, @cErro, @nHttpStatus )

   ::nWinHttpStatus := nHttpStatus
   ::cWinHttpLastError := cErro

   IF ! Empty( cResp )
      ::cXmlRetorno := cResp
      FOR EACH cBlocoValido IN { "soap:Body", "soapenv:Body", "env:Body", "S:Body", "Body" }
         IF ! Empty( XmlNode( ::cXmlRetorno, cBlocoValido ) )
            ::cXmlRetorno := XmlNode( ::cXmlRetorno, cBlocoValido )
            EXIT
         ENDIF
      NEXT
   ELSE
      ::nStatus := 999
      ::cMotivo := IIf( Empty( cErro ), "Erro WinHTTP sem retorno", cErro )
      ::cXmlRetorno := '<xml>*ERRO* WinHTTP ' + AllTrim( Str( nHttpStatus ) ) + IIf( Empty( cErro ), '', ' - ' + cErro ) + '</xml>'
   ENDIF

   IF nHttpStatus >= 400 .AND. Empty( cResp )
      ::nStatus := 999
      ::cMotivo := 'Erro HTTP WinHTTP ' + AllTrim( Str( nHttpStatus ) )
   ENDIF

   SefazRetornoAplicar( Self, ::cXmlRetorno )

RETURN NIL
METHOD CurlSoapPost() CLASS SefazClass

   LOCAL cTempBase, cReqFile, cRespFile, cCodeFile, cErrFile, cCfgFile
   LOCAL cCfg := "", cCmd, cHttp, cErr, cResp, cCertParam
   LOCAL cBlocoValido

   cTempBase := IIf( Empty( ::cCurlTempBase ), SefazCurlTempBase(), ::cCurlTempBase )
   cReqFile  := cTempBase + "_req.xml"
   cRespFile := cTempBase + "_resp.xml"
   cCodeFile := cTempBase + "_code.txt"
   cErrFile  := cTempBase + "_err.txt"
   cCfgFile  := cTempBase + "_curl.cfg"

   hb_MemoWrit( cReqFile, ::cXmlSoap )

   cCfg += 'url = "' + SefazCurlCfgEscape( ::cSoapURL ) + '"' + hb_Eol()
   cCfg += 'request = "POST"' + hb_Eol()
   cCfg += 'silent' + hb_Eol()
   cCfg += 'show-error' + hb_Eol()
   cCfg += 'location' + hb_Eol()
   cCfg += 'connect-timeout = "' + AllTrim( Str( Max( 1, Int( ::nSoapTimeOut / 1000 ) ) ) ) + '"' + hb_Eol()
   cCfg += 'max-time = "' + AllTrim( Str( Max( 1, Int( ::nSoapTimeOut / 1000 ) ) ) ) + '"' + hb_Eol()
   cCfg += 'header = "Content-Type: application/soap+xml; charset=utf-8"' + hb_Eol()
   IF ! Empty( ::cSoapAction )
      cCfg += 'header = "SOAPAction: ' + SefazCurlCfgEscape( ::cSoapAction ) + '"' + hb_Eol()
   ENDIF
   IF ::lEnvioZip
      cCfg += 'header = "Accept-Encoding: gzip,deflate"' + hb_Eol()
      cCfg += 'header = "Content-Encoding: gzip"' + hb_Eol()
   ENDIF
   cCfg += 'data-binary = "@' + SefazCurlCfgEscape( cReqFile ) + '"' + hb_Eol()
   cCfg += 'output = "' + SefazCurlCfgEscape( cRespFile ) + '"' + hb_Eol()
   cCfg += 'write-out = "%{http_code}"' + hb_Eol()

   IF ::lCurlInsecure
      cCfg += 'insecure' + hb_Eol()
   ENDIF
   IF ! Empty( ::cCurlCAInfo )
      cCfg += 'cacert = "' + SefazCurlCfgEscape( ::cCurlCAInfo ) + '"' + hb_Eol()
   ENDIF
   IF ! Empty( ::cProxyUrl )
      cCfg += 'proxy = "' + SefazCurlCfgEscape( ::cProxyUrl ) + '"' + hb_Eol()
      IF ! Empty( ::cProxyUser ) .OR. ! Empty( ::cProxyPassword )
         cCfg += 'proxy-user = "' + SefazCurlCfgEscape( ::cProxyUser + ':' + ::cProxyPassword ) + '"' + hb_Eol()
      ENDIF
   ENDIF

   IF ! Empty( ::cCurlCertFile )
      IF Empty( ::cCurlCertType )
         ::cCurlCertType := IIf( Lower( Right( ::cCurlCertFile, 4 ) ) == ".pfx" .OR. Lower( Right( ::cCurlCertFile, 4 ) ) == ".p12", "P12", "PEM" )
      ENDIF
      cCfg += 'cert-type = "' + SefazCurlCfgEscape( ::cCurlCertType ) + '"' + hb_Eol()
      IF Upper( ::cCurlCertType ) $ "P12,PFX"
         cCertParam := ::cCurlCertFile + IIf( Empty( ::cCurlCertPassword ), "", ":" + ::cCurlCertPassword )
         cCfg += 'cert = "' + SefazCurlCfgEscape( cCertParam ) + '"' + hb_Eol()
      ELSE
         cCfg += 'cert = "' + SefazCurlCfgEscape( ::cCurlCertFile ) + '"' + hb_Eol()
         IF ! Empty( ::cCurlKeyFile )
            cCfg += 'key = "' + SefazCurlCfgEscape( ::cCurlKeyFile ) + '"' + hb_Eol()
         ENDIF
         IF ! Empty( ::cCurlCertPassword )
            cCfg += 'pass = "' + SefazCurlCfgEscape( ::cCurlCertPassword ) + '"' + hb_Eol()
         ENDIF
      ENDIF
   ENDIF

   hb_MemoWrit( cCfgFile, cCfg )
   cCmd := SefazCmdQuote( ::cCurlExe ) + ' --config ' + SefazCmdQuote( cCfgFile ) + ' > ' + SefazCmdQuote( cCodeFile ) + ' 2> ' + SefazCmdQuote( cErrFile )
   __Run( cCmd )

   cHttp := AllTrim( hb_MemoRead( cCodeFile ) )
   cErr  := AllTrim( hb_MemoRead( cErrFile ) )
   cResp := hb_MemoRead( cRespFile )
   ::nCurlHttpStatus := Val( cHttp )
   ::cCurlLastError := cErr

   IF ! Empty( cResp )
      ::cXmlRetorno := cResp
      FOR EACH cBlocoValido IN { "soap:Body", "soapenv:Body", "env:Body", "S:Body", "Body" }
         IF ! Empty( XmlNode( ::cXmlRetorno, cBlocoValido ) )
            ::cXmlRetorno := XmlNode( ::cXmlRetorno, cBlocoValido )
            EXIT
         ENDIF
      NEXT
   ELSE
      ::cXmlRetorno := '<xml>*ERRO* Curl HTTP ' + cHttp + IIf( Empty( cErr ), '', ' - ' + cErr ) + '</xml>'
   ENDIF

   IF ::nCurlHttpStatus >= 400 .AND. Empty( cResp )
      ::nStatus := 999
      ::cMotivo := 'Erro HTTP curl ' + cHttp
   ENDIF

   SefazRetornoAplicar( Self, ::cXmlRetorno )

   IF ! ::lCurlKeepTemp
      FErase( cReqFile )
      FErase( cRespFile )
      FErase( cCodeFile )
      FErase( cErrFile )
      FErase( cCfgFile )
   ELSE
      ::cCurlTempBase := cTempBase
   ENDIF

RETURN NIL

STATIC FUNCTION SefazCurlTempBase()

   LOCAL cDir := GetEnv( "TEMP" )
   IF Empty( cDir )
      cDir := "."
   ENDIF
   IF Right( cDir, 1 ) != "\" .AND. Right( cDir, 1 ) != "/"
      cDir += "\"
   ENDIF
RETURN cDir + "sefazcurl_" + DToS( Date() ) + StrTran( Time(), ":", "" ) + "_" + AllTrim( Str( Seconds() * 1000, 10, 0 ) )

STATIC FUNCTION SefazCmdQuote( cText )
RETURN '"' + StrTran( hb_DefaultValue( cText, "" ), '"', '\"' ) + '"'

STATIC FUNCTION SefazCurlCfgEscape( cText )
RETURN StrTran( hb_DefaultValue( cText, "" ), '"', '\"' )

STATIC FUNCTION SefazTransporteLista( cPreferido, lWinHttp, lCurl, lFallback )

   LOCAL aList, cPref := Upper( AllTrim( hb_DefaultValue( cPreferido, "" ) ) )

   hb_Default( @lFallback, .T. )
   IF Empty( cPref )
      cPref := IIf( lWinHttp, "WINHTTP", IIf( lCurl, "CURL", "MSXML" ) )
   ENDIF

   DO CASE
   CASE cPref == "AUTO"
      aList := { "WINHTTP", "MSXML", "CURL" }
   CASE cPref == "WINHTTP"
      aList := { "WINHTTP" }
   CASE cPref == "CURL"
      aList := { "CURL" }
   OTHERWISE
      aList := { "MSXML" }
   ENDCASE

   IF lFallback
      IF AScan( aList, "WINHTTP" ) == 0
         AAdd( aList, "WINHTTP" )
      ENDIF
      IF AScan( aList, "MSXML" ) == 0
         AAdd( aList, "MSXML" )
      ENDIF
      IF AScan( aList, "CURL" ) == 0
         AAdd( aList, "CURL" )
      ENDIF
   ENDIF

RETURN aList

STATIC FUNCTION SefazErroComunicacao( nStatus, cXml, cMotivo )

   LOCAL cAll := Upper( hb_DefaultValue( cXml, "" ) + " " + hb_DefaultValue( cMotivo, "" ) )

   IF nStatus == 999
      RETURN .T.
   ENDIF
   IF Empty( cXml )
      RETURN .T.
   ENDIF
   IF "*ERRO*" $ cAll .OR. "WINHTTP" $ cAll .OR. "CURL HTTP" $ cAll .OR. "SERVERXMLHTTP" $ cAll .OR. "NO OPEN" $ cAll .OR. "SEND FALHOU" $ cAll
      RETURN .T.
   ENDIF

RETURN .F.

STATIC FUNCTION SefazWinHttpErroAmigavel( cErro )

   LOCAL cRet := hb_DefaultValue( cErro, "" ), nCode := Val( SefazOnlyDigitsAfterWin32( cRet ) )

   DO CASE
   CASE Empty( cRet )
      cRet := ""
   CASE nCode == 12029
      cRet += " - nao conectou ao servidor"
   CASE nCode == 12030
      cRet += " - conexao encerrada pelo servidor"
   CASE nCode == 12037
      cRet += " - certificado SSL do servidor vencido ou data invalida"
   CASE nCode == 12038
      cRet += " - nome do certificado SSL do servidor invalido"
   CASE nCode == 12044
      cRet += " - certificado cliente necessario ou rejeitado"
   CASE nCode == 12045
      cRet += " - autoridade certificadora desconhecida"
   CASE nCode == 12175
      cRet += " - erro de seguranca TLS/SSL"
   ENDCASE

RETURN cRet

STATIC FUNCTION SefazOnlyDigitsAfterWin32( cText )

   LOCAL nPos := At( "Win32 ", cText ), cRet := "", nI, c

   IF nPos == 0
      RETURN "0"
   ENDIF
   FOR nI := nPos + 6 TO Len( cText )
      c := SubStr( cText, nI, 1 )
      IF c $ "0123456789"
         cRet += c
      ELSEIF ! Empty( cRet )
         EXIT
      ENDIF
   NEXT

RETURN cRet

STATIC FUNCTION SefazEnsureDir( cDir )

   IF Empty( cDir )
      RETURN .F.
   ENDIF
   IF ! hb_DirExists( cDir )
      hb_DirCreate( cDir )
   ENDIF

RETURN hb_DirExists( cDir )

STATIC FUNCTION SefazPathJoin( cDir, cFile )

   IF Empty( cDir )
      RETURN cFile
   ENDIF
   IF Right( cDir, 1 ) == "\\" .OR. Right( cDir, 1 ) == "/"
      RETURN cDir + cFile
   ENDIF

RETURN cDir + "\\" + cFile

STATIC FUNCTION SefazFileSafe( cText )

   LOCAL cRet := "", nI, c

   FOR nI := 1 TO Len( hb_DefaultValue( cText, "" ) )
      c := SubStr( cText, nI, 1 )
      IF c $ "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-"
         cRet += c
      ELSE
         cRet += "_"
      ENDIF
   NEXT
   IF Empty( cRet )
      cRet := "log"
   ENDIF

RETURN cRet

FUNCTION SefazXmlSanitize( cXml )

   LOCAL cRet := "", nI, nAsc, c

   cXml := hb_DefaultValue( cXml, "" )
   IF Left( cXml, 3 ) == Chr( 239 ) + Chr( 187 ) + Chr( 191 )
      cXml := SubStr( cXml, 4 )
   ENDIF
   FOR nI := 1 TO Len( cXml )
      c := SubStr( cXml, nI, 1 )
      nAsc := Asc( c )
      IF nAsc == 9 .OR. nAsc == 10 .OR. nAsc == 13 .OR. nAsc >= 32
         cRet += c
      ENDIF
   NEXT

RETURN cRet
STATIC FUNCTION SingleXmlValidate( cXml, cIgnoreList )

   LOCAL nPos, aTagsAbre := {}, cTmp, oElement, cLetra, cTxt := ""

   hb_Default( @cIgnoreList, "" )
   DO WHILE .T.
      nPos := hb_At( "<", cXml, nPos )
      IF nPos < 1
         EXIT
      ENDIF
      IF Substr( cXml, nPos + 1, 1 ) == "/"
         IF ! ProcFecha( Substr( cXml, nPos, hb_At( ">", cXml, nPos ) - nPos ), aTagsAbre, @cTxt )
            EXIT
         ENDIF
      ELSE
         cTmp := Substr( cXml, nPos, hb_At( ">", cXml, nPos ) - nPos + 1 )
         IF ! "/>" $ cTmp .AND. ! "/ >" $ cTmp
            AAdd( aTagsAbre, cTmp )
            //? "Abriu " + Atail( aTagsAbre )
         ENDIF
      ENDIF
      nPos := nPos + 3
   ENDDO
   IF Len( aTagsAbre ) != 0
      cTxt += "Em aberto" + Space(3)
      FOR EACH oElement IN aTagsAbre
         cTxt += oElement + Space(3)
      NEXT
      RETURN "*ERRO* " + cTxt
   ENDIF
   FOR EACH cLetra IN cXml
      DO CASE
      CASE cLetra $ "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
      CASE cLetra $ "abcdefghijklmnopqrstuvwxyz"
      CASE cLetra $ "0123456789"
      CASE cLetra $ " <>=:/.,-+#$()_@;%"
      CASE cLetra == ["]
      CASE cLetra $ cIgnoreList
      OTHERWISE
         cTxt += "Caractere " + cLetra + " posi��o " + Ltrim( Str( cLetra:__EnumIndex ) ) + ;
            " aproximadamente aqui " + Substr( cXml, Max( 0, cLetra:__EnumIndex - 10 ), 20 ) + ", "
      ENDCASE
   NEXT
   IF " <" $ cXml .OR. "> " $ cXml
      cTxt += "espa�os em branco antes de < ou depois de >"
   ENDIF
   IF Len( cTxt ) > 0
      RETURN "*ERRO* " + cTxt
   ENDIF
   RETURN "OK"

STATIC FUNCTION ProcFecha( cTag, aTagsAbre, cTxt )

   LOCAL oElement

   FOR EACH oElement IN aTagsAbre
      IF " " $ oElement
         oElement := Substr( oElement, 1, At( " ", oElement ) - 1 )
      ENDIF
      IF ">" $ oElement
         oElement := Substr( oElement, 1, At( ">", oElement ) - 1 )
      ENDIF
      IF "<" $ oElement
         oElement := Trim( Substr( oElement, 2 ) )
      ENDIF
   NEXT
   cTag := Substr( cTag, 3 )
   IF ">" $ cTag
      cTag := Substr( cTag, 1, At( ">", cTag ) - 1 )
   ENDIF
   IF cTag == Atail( aTagsAbre )
      //? "fechou " + cTag
      hb_ADel( aTagsAbre, Len( aTagsAbre ), .T. )
   ELSE
      IF Len( aTagsAbre ) != 0
         cTxt += "erro fechada " + cTag + " esperada " + Atail( aTagsAbre ) + Space(3)
      ENDIF
      RETURN .F.
   ENDIF

   RETURN .T.

FUNCTION SefazClassValidaXml( cXml, cXsd )

   LOCAL oSefaz := SefazClass():New()

   RETURN oSefaz:ValidaXml( cXml, cXsd )

FUNCTION SefazClassTipoXml( cXml )

   LOCAL oSefaz := SefazClass():New()

   RETURN oSefaz:TipoXml( cXml )


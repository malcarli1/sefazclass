PROCEDURE Main()

   LOCAL oSefaz := TSefazProduto():New()
   LOCAL cIni := IIf( hb_ArgC() >= 1, hb_ArgV( 1 ), "sefaz.ini" )

   IF File( cIni )
      oSefaz:LoadConfigIni( cIni )
   ENDIF

   ? "SefazClass Produto - diagnostico"
   ? oSefaz:Diagnostico()
RETURN


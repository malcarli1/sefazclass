/*
ZE_SEFAZ_ASSINA - Assinatura XMLDSig RSA-SHA1 sem CAPICOM
Mantem a funcao publica CapicomAssinaXml() para compatibilidade.
*/

#include "common.ch"
#include "hbclass.ch"

FUNCTION CapicomAssinaXml( cTxtXml, cCertCN, lRemoveAnterior, cPassword, lComURI )
RETURN SefazAssinaXmlSha1( @cTxtXml, cCertCN, cPassword, lRemoveAnterior, lComURI )

FUNCTION SefazAssinaXmlSha1( cTxtXml, cCertSubject, cPassword, lRemoveAnterior, lComURI )

   LOCAL cRetorno := "", cXmlAssinado

   hb_Default( @lRemoveAnterior, .T. )
   hb_Default( @lComURI, .T. )

   cXmlAssinado := SefazNativeAssinaXmlSha1( cTxtXml, hb_DefaultValue( cCertSubject, "" ), "", hb_DefaultValue( cPassword, "" ), lRemoveAnterior, lComURI, @cRetorno )
   IF Empty( cXmlAssinado )
      IF Empty( cRetorno )
         cRetorno := "Erro Assinatura: " + SefazNativeCryptoLastError()
      ENDIF
      RETURN cRetorno
   ENDIF

   cTxtXml := cXmlAssinado
RETURN "OK"

FUNCTION SefazAssinaXmlSha1Thumbprint( cTxtXml, cThumbprint, cPassword, lRemoveAnterior, lComURI )

   LOCAL cRetorno := "", cXmlAssinado

   hb_Default( @lRemoveAnterior, .T. )
   hb_Default( @lComURI, .T. )

   cXmlAssinado := SefazNativeAssinaXmlSha1( cTxtXml, "", hb_DefaultValue( cThumbprint, "" ), hb_DefaultValue( cPassword, "" ), lRemoveAnterior, lComURI, @cRetorno )
   IF Empty( cXmlAssinado )
      IF Empty( cRetorno )
         cRetorno := "Erro Assinatura: " + SefazNativeCryptoLastError()
      ENDIF
      RETURN cRetorno
   ENDIF

   cTxtXml := cXmlAssinado
RETURN "OK"

FUNCTION SefazAssinaXmlSha1Pfx( cTxtXml, cPfxFile, cPassword, lRemoveAnterior, lComURI )
RETURN SefazAssinaXmlSha1( @cTxtXml, cPfxFile, cPassword, lRemoveAnterior, lComURI )

FUNCTION SefazNativeAssinaXmlSha1( cXml, cSubject, cThumbprint, cPassword, lRemoveAnterior, lComURI, cErro )
   LOCAL cOut := hb_DefaultValue( cXml, "" )
   LOCAL cTagAssinar, cTagFechar, cTagInserir, cId, cBloco, cBlocoCanon
   LOCAL cDigest, cSignedInfo, cSigBin, cCertDer, cSignature
   LOCAL nStart, nEnd, nInsert

   hb_Default( @lRemoveAnterior, .T. )
   hb_Default( @lComURI, .T. )
   cErro := ""

   IF lRemoveAnterior
      cOut := SefazAssinaRemoveSignature( cOut )
   ENDIF
   cOut := SefazAssinaRemoveXmlDecl( cOut )

   IF ! SefazAssinaLocaliza( cOut, @cTagAssinar, @cTagFechar, @cTagInserir, @cErro )
      RETURN ""
   ENDIF

   nStart := hb_At( "<" + cTagAssinar, cOut )
   nEnd := hb_At( "</" + cTagFechar + ">", cOut, nStart )
   IF nStart == 0 .OR. nEnd == 0
      cErro := "Erro Assinatura: Bloco a assinar nao encontrado"
      RETURN ""
   ENDIF
   nEnd += Len( "</" + cTagFechar + ">" ) - 1
   cBloco := SubStr( cOut, nStart, nEnd - nStart + 1 )

   cId := SefazXmlAttrValue( cBloco, "Id" )
   IF Empty( cId )
      cErro := "Erro Assinatura: Nao encontrado Id no bloco " + cTagAssinar
      RETURN ""
   ENDIF

   cBlocoCanon := SefazAssinaCanonBlock( cBloco, cOut )
   cDigest := SefazOneLineBase64( hb_Base64Encode( SefazHexToBin( hb_SHA1( cBlocoCanon ) ) ) )
   cSignedInfo := SefazSignedInfoCanon( IIf( lComURI, "#" + cId, "" ), cDigest )
   cSigBin := SefazNativeSignSha1Hash( SefazHexToBin( hb_SHA1( cSignedInfo ) ), cSubject, cThumbprint, cPassword )
   IF Empty( cSigBin )
      cErro := "Erro Assinatura: " + SefazNativeCryptoLastError()
      RETURN ""
   ENDIF

   cCertDer := SefazNativeCertDer( cSubject, cThumbprint, cPassword )
   IF Empty( cCertDer )
      cErro := "Erro Assinatura: certificado nao encontrado - " + SefazNativeCryptoLastError()
      RETURN ""
   ENDIF

   cSignature := SefazSignatureNode( IIf( lComURI, "#" + cId, "" ), cDigest, ;
      SefazOneLineBase64( hb_Base64Encode( cSigBin ) ), ;
      SefazOneLineBase64( hb_Base64Encode( cCertDer ) ) )

   nInsert := hb_At( cTagInserir, cOut )
   IF nInsert == 0
      cErro := "Erro Assinatura: local de insercao nao encontrado"
      RETURN ""
   ENDIF
RETURN SubStr( cOut, 1, nInsert - 1 ) + cSignature + SubStr( cOut, nInsert )

STATIC FUNCTION SefazAssinaLocaliza( cXml, cTagAssinar, cTagFechar, cTagInserir, cErro )
   LOCAL aList, nPos

   aList := { ;
      { "infNFe",                "infNFe",                "</NFe>" }, ;
      { "infCte",                "infCte",                "</CTe>" }, ;
      { "infMDFe",               "infMDFe",               "</MDFe>" }, ;
      { "infEvento",             "infEvento",             "</evento>" }, ;
      { "infInut",               "infInut",               "</inutNFe>" }, ;
      { "infCanc",               "infCanc",               "</cancNFe>" }, ;
      { "infInut",               "infInut",               "</inutCTe>" }, ;
      { "infDPEC",               "infDPEC",               "</envDPEC>" }, ;
      { "evtInfoEmpregador",     "evtInfoEmpregador",     "</eSocial>" }, ;
      { "PedidoEnvioLoteRPS",    "PedidoEnvioLoteRPS",    "</RPS>" }, ;
      { "PedidoEnvioRPS",        "PedidoEnvioRPS",        "</PedidoEnvioRPS>" }, ;
      { "infPedidoCancelamento", "infPedidoCancelamento", "</Pedido>" }, ;
      { "LoteRps",               "LoteRps",               "</EnviarLoteRpsEnvio>" }, ;
      { "infRps",                "infRps",                "</Rps>" } }

   nPos := hb_AScan( aList, { | a | ( "<" + a[ 1 ] ) $ cXml .AND. a[ 3 ] $ cXml } )
   IF nPos == 0
      cErro := "Erro Assinatura: Nao identificado documento"
      RETURN .F.
   ENDIF

   cTagAssinar := aList[ nPos, 1 ]
   cTagFechar := aList[ nPos, 2 ]
   cTagInserir := aList[ nPos, 3 ]
RETURN .T.

STATIC FUNCTION SefazAssinaRemoveSignature( cXml )
   LOCAL nStart, nEnd
   DO WHILE ( nStart := hb_At( "<Signature", cXml ) ) > 0 .AND. ( nEnd := hb_At( "</Signature>", cXml, nStart ) ) > 0
      nEnd += Len( "</Signature>" ) - 1
      cXml := Left( cXml, nStart - 1 ) + SubStr( cXml, nEnd + 1 )
   ENDDO
RETURN cXml

STATIC FUNCTION SefazAssinaRemoveXmlDecl( cXml )
   LOCAL nEnd
   cXml := AllTrim( cXml )
   IF Upper( Left( cXml, 5 ) ) == "<?XML"
      nEnd := hb_At( "?>", cXml )
      IF nEnd > 0
         cXml := AllTrim( SubStr( cXml, nEnd + 2 ) )
      ENDIF
   ENDIF
RETURN cXml

STATIC FUNCTION SefazAssinaCanonBlock( cBloco, cXmlCompleto )
   LOCAL cNs
   IF ! 'xmlns=' $ Left( cBloco, hb_At( ">", cBloco ) )
      cNs := SefazXmlDefaultNamespace( cXmlCompleto )
      IF ! Empty( cNs )
         cBloco := Stuff( cBloco, hb_At( ">", cBloco ), 0, ' xmlns="' + cNs + '"' )
      ENDIF
   ENDIF
RETURN cBloco

STATIC FUNCTION SefazXmlDefaultNamespace( cXml )
   LOCAL nStart, nEnd
   nStart := hb_At( 'xmlns="', cXml )
   IF nStart == 0
      RETURN ""
   ENDIF
   nStart += 7
   nEnd := hb_At( '"', cXml, nStart )
RETURN SubStr( cXml, nStart, nEnd - nStart )

STATIC FUNCTION SefazXmlAttrValue( cXml, cAttr )
   LOCAL nStart, nEnd
   nStart := hb_At( cAttr + '="', cXml )
   IF nStart == 0
      RETURN ""
   ENDIF
   nStart += Len( cAttr ) + 2
   nEnd := hb_At( '"', cXml, nStart )
RETURN SubStr( cXml, nStart, nEnd - nStart )

STATIC FUNCTION SefazSignedInfoCanon( cReferenceUri, cDigest )
   LOCAL cXml
   cXml := '<SignedInfo xmlns="http://www.w3.org/2000/09/xmldsig#">'
   cXml += '<CanonicalizationMethod Algorithm="http://www.w3.org/TR/2001/REC-xml-c14n-20010315"></CanonicalizationMethod>'
   cXml += '<SignatureMethod Algorithm="http://www.w3.org/2000/09/xmldsig#rsa-sha1"></SignatureMethod>'
   cXml += '<Reference URI="' + cReferenceUri + '">'
   cXml += '<Transforms>'
   cXml += '<Transform Algorithm="http://www.w3.org/2000/09/xmldsig#enveloped-signature"></Transform>'
   cXml += '<Transform Algorithm="http://www.w3.org/TR/2001/REC-xml-c14n-20010315"></Transform>'
   cXml += '</Transforms>'
   cXml += '<DigestMethod Algorithm="http://www.w3.org/2000/09/xmldsig#sha1"></DigestMethod>'
   cXml += '<DigestValue>' + cDigest + '</DigestValue>'
   cXml += '</Reference>'
   cXml += '</SignedInfo>'
RETURN cXml

STATIC FUNCTION SefazSignedInfoNode( cReferenceUri, cDigest )
   LOCAL cXml
   cXml := '<SignedInfo>'
   cXml += '<CanonicalizationMethod Algorithm="http://www.w3.org/TR/2001/REC-xml-c14n-20010315"/>'
   cXml += '<SignatureMethod Algorithm="http://www.w3.org/2000/09/xmldsig#rsa-sha1"/>'
   cXml += '<Reference URI="' + cReferenceUri + '">'
   cXml += '<Transforms>'
   cXml += '<Transform Algorithm="http://www.w3.org/2000/09/xmldsig#enveloped-signature"/>'
   cXml += '<Transform Algorithm="http://www.w3.org/TR/2001/REC-xml-c14n-20010315"/>'
   cXml += '</Transforms>'
   cXml += '<DigestMethod Algorithm="http://www.w3.org/2000/09/xmldsig#sha1"/>'
   cXml += '<DigestValue>' + cDigest + '</DigestValue>'
   cXml += '</Reference>'
   cXml += '</SignedInfo>'
RETURN cXml

STATIC FUNCTION SefazSignatureNode( cReferenceUri, cDigest, cSignature, cCert )
RETURN '<Signature xmlns="http://www.w3.org/2000/09/xmldsig#">' + SefazSignedInfoNode( cReferenceUri, cDigest ) + '<SignatureValue>' + cSignature + '</SignatureValue><KeyInfo><X509Data><X509Certificate>' + cCert + '</X509Certificate></X509Data></KeyInfo></Signature>'

STATIC FUNCTION SefazHexToBin( cHex )
   LOCAL cBin := "", nI
   FOR nI := 1 TO Len( cHex ) STEP 2
      cBin += Chr( hb_HexToNum( SubStr( cHex, nI, 2 ) ) )
   NEXT
RETURN cBin

STATIC FUNCTION SefazOneLineBase64( cText )
RETURN StrTran( StrTran( AllTrim( cText ), Chr( 13 ), "" ), Chr( 10 ), "" )

FUNCTION SefazNativeSignSha1Hash( cHashBin, cSubject, cThumbprint, cPassword )
RETURN __SefazNativeSignSha1Hash( cHashBin, hb_DefaultValue( cSubject, "" ), hb_DefaultValue( cThumbprint, "" ), hb_DefaultValue( cPassword, "" ) )

FUNCTION SefazNativeCryptoLastError()
RETURN __SefazNativeCryptoLastError()

FUNCTION SefazNativeCertDer( cSubject, cThumbprint, cPassword )
RETURN __SefazNativeCertDer( hb_DefaultValue( cSubject, "" ), hb_DefaultValue( cThumbprint, "" ), hb_DefaultValue( cPassword, "" ) )

#pragma BEGINDUMP

#include "hbapi.h"
#include "hbapiitm.h"

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <wincrypt.h>
#include <string.h>

#ifndef CRYPT_ACQUIRE_ALLOW_NCRYPT_KEY_FLAG
#define CRYPT_ACQUIRE_ALLOW_NCRYPT_KEY_FLAG 0x00010000
#endif
#ifndef CRYPT_ACQUIRE_PREFER_NCRYPT_KEY_FLAG
#define CRYPT_ACQUIRE_PREFER_NCRYPT_KEY_FLAG 0x00020000
#endif
#ifndef CERT_NCRYPT_KEY_SPEC
#define CERT_NCRYPT_KEY_SPEC 0xFFFFFFFF
#endif
#ifndef NCRYPT_PAD_PKCS1_FLAG
#define NCRYPT_PAD_PKCS1_FLAG 0x00000002
#endif
#ifndef ERROR_SUCCESS
#define ERROR_SUCCESS 0
#endif

typedef ULONG_PTR HB_SEFAZ_NCRYPT_KEY_HANDLE;
typedef struct _HB_SEFAZ_BCRYPT_PKCS1_PADDING_INFO { LPCWSTR pszAlgId; } HB_SEFAZ_BCRYPT_PKCS1_PADDING_INFO;
typedef LONG HB_SEFAZ_SECURITY_STATUS;
typedef HB_SEFAZ_SECURITY_STATUS ( WINAPI * HB_SEFAZ_NCRYPT_SIGN_HASH )( HB_SEFAZ_NCRYPT_KEY_HANDLE, void *, BYTE *, DWORD, BYTE *, DWORD, DWORD *, DWORD );
typedef HB_SEFAZ_SECURITY_STATUS ( WINAPI * HB_SEFAZ_NCRYPT_FREE_OBJECT )( HB_SEFAZ_NCRYPT_KEY_HANDLE );

static DWORD s_dwSefazLastError = 0;
static char s_szSefazLastStage[ 64 ] = "";

static void hb_sefaz_set_error( const char * pszStage )
{
   s_dwSefazLastError = GetLastError();
   lstrcpynA( s_szSefazLastStage, pszStage, sizeof( s_szSefazLastStage ) );
}

static BOOL hb_sefaz_ncrypt_sign_sha1( HB_SEFAZ_NCRYPT_KEY_HANDLE hKey, const BYTE * pbHash, DWORD cbHash )
{
   HMODULE hNCrypt = LoadLibraryA( "ncrypt.dll" );
   HB_SEFAZ_NCRYPT_SIGN_HASH pNCryptSignHash;
   HB_SEFAZ_BCRYPT_PKCS1_PADDING_INFO padding;
   DWORD cbSig = 0;
   BYTE * pbSig = NULL;
   HB_SEFAZ_SECURITY_STATUS status;

   if( ! hNCrypt ) { hb_sefaz_set_error( "LoadLibrary-ncrypt" ); return FALSE; }
   pNCryptSignHash = ( HB_SEFAZ_NCRYPT_SIGN_HASH ) GetProcAddress( hNCrypt, "NCryptSignHash" );
   if( ! pNCryptSignHash ) { hb_sefaz_set_error( "GetProcAddress-NCryptSignHash" ); FreeLibrary( hNCrypt ); return FALSE; }

   padding.pszAlgId = L"SHA1";
   status = pNCryptSignHash( hKey, &padding, ( PBYTE ) pbHash, cbHash, NULL, 0, &cbSig, NCRYPT_PAD_PKCS1_FLAG );
   if( status != ERROR_SUCCESS || cbSig == 0 )
   {
      s_dwSefazLastError = ( DWORD ) status;
      lstrcpynA( s_szSefazLastStage, "NCryptSignHash-size", sizeof( s_szSefazLastStage ) );
      FreeLibrary( hNCrypt );
      return FALSE;
   }

   pbSig = ( BYTE * ) hb_xgrab( cbSig );
   status = pNCryptSignHash( hKey, &padding, ( PBYTE ) pbHash, cbHash, pbSig, cbSig, &cbSig, NCRYPT_PAD_PKCS1_FLAG );
   if( status == ERROR_SUCCESS )
   {
      hb_retclen( ( const char * ) pbSig, cbSig );
      hb_xfree( pbSig );
      FreeLibrary( hNCrypt );
      return TRUE;
   }

   hb_xfree( pbSig );
   s_dwSefazLastError = ( DWORD ) status;
   lstrcpynA( s_szSefazLastStage, "NCryptSignHash-data", sizeof( s_szSefazLastStage ) );
   FreeLibrary( hNCrypt );
   return FALSE;
}

static int hb_sefaz_hexval( char c )
{
   if( c >= '0' && c <= '9' ) return c - '0';
   if( c >= 'a' && c <= 'f' ) return c - 'a' + 10;
   if( c >= 'A' && c <= 'F' ) return c - 'A' + 10;
   return -1;
}

static int hb_sefaz_thumbprint_to_bytes( const char * pszHex, BYTE * out, DWORD * pcbOut )
{
   DWORD n = 0;
   int hi = -1;
   while( pszHex && *pszHex )
   {
      int v = hb_sefaz_hexval( *pszHex++ );
      if( v < 0 ) continue;
      if( hi < 0 ) hi = v;
      else
      {
         if( n >= *pcbOut ) return 0;
         out[ n++ ] = ( BYTE ) ( ( hi << 4 ) | v );
         hi = -1;
      }
   }
   if( hi >= 0 ) return 0;
   *pcbOut = n;
   return n > 0;
}

static PCCERT_CONTEXT hb_sefaz_find_cert( HCERTSTORE hStore, const char * pszSubject, const char * pszThumb );

static int hb_sefaz_ends_with_pfx( const char * pszFile )
{
   size_t len;
   if( ! pszFile ) return 0;
   len = strlen( pszFile );
   return len >= 4 && ( lstrcmpiA( pszFile + len - 4, ".pfx" ) == 0 || lstrcmpiA( pszFile + len - 4, ".p12" ) == 0 );
}

static HCERTSTORE hb_sefaz_open_pfx_store( const char * pszFile, const char * pszPassword )
{
   HANDLE hFile;
   DWORD fileSize, readSize;
   BYTE * fileData;
   CRYPT_DATA_BLOB blob;
   WCHAR wszPassword[ 512 ];
   HCERTSTORE hStore;

   hFile = CreateFileA( pszFile, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL );
   if( hFile == INVALID_HANDLE_VALUE )
   {
      hb_sefaz_set_error( "PFX-CreateFile" );
      return NULL;
   }

   fileSize = GetFileSize( hFile, NULL );
   if( fileSize == INVALID_FILE_SIZE || fileSize == 0 )
   {
      hb_sefaz_set_error( "PFX-GetFileSize" );
      CloseHandle( hFile );
      return NULL;
   }

   fileData = ( BYTE * ) hb_xgrab( fileSize );
   if( ! ReadFile( hFile, fileData, fileSize, &readSize, NULL ) || readSize != fileSize )
   {
      hb_sefaz_set_error( "PFX-ReadFile" );
      hb_xfree( fileData );
      CloseHandle( hFile );
      return NULL;
   }
   CloseHandle( hFile );

   ZeroMemory( wszPassword, sizeof( wszPassword ) );
   if( pszPassword && pszPassword[ 0 ] )
      MultiByteToWideChar( CP_ACP, 0, pszPassword, -1, wszPassword, sizeof( wszPassword ) / sizeof( WCHAR ) );

   blob.cbData = fileSize;
   blob.pbData = fileData;
   hStore = PFXImportCertStore( &blob, ( pszPassword && pszPassword[ 0 ] ) ? wszPassword : L"", CRYPT_USER_KEYSET );
   if( ! hStore )
   {
      hb_sefaz_set_error( "PFXImportCertStore" );
      hStore = PFXImportCertStore( &blob, ( pszPassword && pszPassword[ 0 ] ) ? wszPassword : L"", CRYPT_MACHINE_KEYSET );
   }

   hb_xfree( fileData );
   return hStore;
}

static PCCERT_CONTEXT hb_sefaz_find_cert_with_private_key( HCERTSTORE hStore, const char * pszSubject, const char * pszThumb )
{
   PCCERT_CONTEXT pCert = NULL;
   PCCERT_CONTEXT pChosen = NULL;

   if( pszThumb && pszThumb[ 0 ] )
      return hb_sefaz_find_cert( hStore, pszSubject, pszThumb );

   while( ( pCert = CertEnumCertificatesInStore( hStore, pCert ) ) != NULL )
   {
      char subject[ 2048 ];
      DWORD cbInfo = 0;
      DWORD len = CertGetNameStringA( pCert, CERT_NAME_SIMPLE_DISPLAY_TYPE, 0, NULL, subject, sizeof( subject ) );
      CertGetCertificateContextProperty( pCert, CERT_KEY_PROV_INFO_PROP_ID, NULL, &cbInfo );
      if( len > 1 && cbInfo > 0 )
      {
         if( pszSubject && pszSubject[ 0 ] )
         {
            if( strstr( subject, pszSubject ) != NULL )
            {
               pChosen = CertDuplicateCertificateContext( pCert );
               break;
            }
         }
         else
         {
            pChosen = CertDuplicateCertificateContext( pCert );
            break;
         }
      }
   }
   return pChosen;
}
static PCCERT_CONTEXT hb_sefaz_find_cert( HCERTSTORE hStore, const char * pszSubject, const char * pszThumb )
{
   PCCERT_CONTEXT pCert = NULL;
   if( pszThumb && pszThumb[ 0 ] )
   {
      BYTE hash[ 64 ];
      DWORD cbHash = sizeof( hash );
      CRYPT_HASH_BLOB blob;
      if( ! hb_sefaz_thumbprint_to_bytes( pszThumb, hash, &cbHash ) ) return NULL;
      blob.cbData = cbHash;
      blob.pbData = hash;
      return CertFindCertificateInStore( hStore, X509_ASN_ENCODING | PKCS_7_ASN_ENCODING, 0, CERT_FIND_HASH, &blob, NULL );
   }

   while( ( pCert = CertEnumCertificatesInStore( hStore, pCert ) ) != NULL )
   {
      char subject[ 2048 ];
      DWORD cbInfo = 0;
      DWORD len = CertGetNameStringA( pCert, CERT_NAME_SIMPLE_DISPLAY_TYPE, 0, NULL, subject, sizeof( subject ) );
      CertGetCertificateContextProperty( pCert, CERT_KEY_PROV_INFO_PROP_ID, NULL, &cbInfo );
      if( len > 1 && cbInfo > 0 )
      {
         if( pszSubject && pszSubject[ 0 ] )
         {
            if( strstr( subject, pszSubject ) != NULL ) return CertDuplicateCertificateContext( pCert );
         }
         else if( strstr( subject, "LTDA" ) || strstr( subject, "CNPJ" ) || strstr( subject, "e-CNPJ" ) || strstr( subject, "E-CNPJ" ) )
            return CertDuplicateCertificateContext( pCert );
      }
   }
   return NULL;
}

HB_FUNC( __SEFAZNATIVESIGNSHA1HASH )
{
   const BYTE * pbHash = ( const BYTE * ) hb_parc( 1 );
   DWORD cbHash = ( DWORD ) hb_parclen( 1 );
   const char * pszSubject = hb_parc( 2 );
   const char * pszThumb = hb_parc( 3 );
   const char * pszPassword = hb_parc( 4 );
   HCERTSTORE hStore = NULL;
   PCCERT_CONTEXT pCert = NULL;
   ULONG_PTR hKey = 0;
   DWORD dwKeySpec = 0;
   BOOL fCallerFree = FALSE;
   HCRYPTHASH hHash = 0;
   DWORD cbSig = 0;
   BYTE * pbSig = NULL;
   BOOL ok = FALSE;
   BOOL lPfx = hb_sefaz_ends_with_pfx( pszSubject );

   if( cbHash != 20 )
   {
      s_dwSefazLastError = 0;
      lstrcpynA( s_szSefazLastStage, "hash-size", sizeof( s_szSefazLastStage ) );
      hb_retc_null();
      return;
   }

   if( lPfx )
      hStore = hb_sefaz_open_pfx_store( pszSubject, pszPassword );
   else
      hStore = CertOpenStore( CERT_STORE_PROV_SYSTEM_A, 0, 0, CERT_SYSTEM_STORE_CURRENT_USER | CERT_STORE_READONLY_FLAG, "MY" );

   if( ! hStore )
   {
      if( ! s_szSefazLastStage[ 0 ] ) hb_sefaz_set_error( "CertOpenStore" );
      hb_retc_null();
      return;
   }

   pCert = lPfx ? hb_sefaz_find_cert_with_private_key( hStore, "", pszThumb ) : hb_sefaz_find_cert( hStore, pszSubject, pszThumb );
   if( ! pCert ) hb_sefaz_set_error( "find-cert" );
   if( pCert && CryptAcquireCertificatePrivateKey( pCert, CRYPT_ACQUIRE_COMPARE_KEY_FLAG | CRYPT_ACQUIRE_ALLOW_NCRYPT_KEY_FLAG | CRYPT_ACQUIRE_PREFER_NCRYPT_KEY_FLAG, NULL, ( HCRYPTPROV * ) &hKey, &dwKeySpec, &fCallerFree ) )
   {
      if( dwKeySpec == CERT_NCRYPT_KEY_SPEC )
         ok = hb_sefaz_ncrypt_sign_sha1( ( HB_SEFAZ_NCRYPT_KEY_HANDLE ) hKey, pbHash, cbHash );
      else
      {
         HCRYPTPROV hProv = ( HCRYPTPROV ) hKey;
         if( CryptCreateHash( hProv, CALG_SHA1, 0, 0, &hHash ) )
         {
            if( CryptSetHashParam( hHash, HP_HASHVAL, ( BYTE * ) pbHash, 0 ) )
            {
               if( CryptSignHashA( hHash, dwKeySpec, NULL, 0, NULL, &cbSig ) && cbSig > 0 )
               {
                  pbSig = ( BYTE * ) hb_xgrab( cbSig );
                  if( CryptSignHashA( hHash, dwKeySpec, NULL, 0, pbSig, &cbSig ) )
                  {
                     DWORD i;
                     for( i = 0; i < cbSig / 2; ++i )
                     {
                        BYTE tmp = pbSig[ i ];
                        pbSig[ i ] = pbSig[ cbSig - 1 - i ];
                        pbSig[ cbSig - 1 - i ] = tmp;
                     }
                     hb_retclen( ( const char * ) pbSig, cbSig );
                     ok = TRUE;
                  }
                  else hb_sefaz_set_error( "CryptSignHash-data" );
                  hb_xfree( pbSig );
               }
               else hb_sefaz_set_error( "CryptSignHash-size" );
            }
            else hb_sefaz_set_error( "CryptSetHashParam" );
            CryptDestroyHash( hHash );
         }
         else hb_sefaz_set_error( "CryptCreateHash-SHA1" );
      }
   }
   else if( pCert ) hb_sefaz_set_error( "CryptAcquireCertificatePrivateKey" );

   if( fCallerFree && hKey )
   {
      if( dwKeySpec == CERT_NCRYPT_KEY_SPEC )
      {
         HMODULE hNCrypt = LoadLibraryA( "ncrypt.dll" );
         if( hNCrypt )
         {
            HB_SEFAZ_NCRYPT_FREE_OBJECT pNCryptFreeObject = ( HB_SEFAZ_NCRYPT_FREE_OBJECT ) GetProcAddress( hNCrypt, "NCryptFreeObject" );
            if( pNCryptFreeObject ) pNCryptFreeObject( ( HB_SEFAZ_NCRYPT_KEY_HANDLE ) hKey );
            FreeLibrary( hNCrypt );
         }
      }
      else CryptReleaseContext( ( HCRYPTPROV ) hKey, 0 );
   }
   if( pCert ) CertFreeCertificateContext( pCert );
   if( hStore ) CertCloseStore( hStore, 0 );
   if( ! ok ) hb_retc_null();
}
HB_FUNC( __SEFAZNATIVECRYPTOLASTERROR )
{
   char buffer[ 128 ];
   wsprintfA( buffer, "%s:%lu", s_szSefazLastStage, ( unsigned long ) s_dwSefazLastError );
   hb_retc( buffer );
}

HB_FUNC( __SEFAZNATIVECERTDER )
{
   const char * pszSubject = hb_parc( 1 );
   const char * pszThumb = hb_parc( 2 );
   const char * pszPassword = hb_parc( 3 );
   BOOL lPfx = hb_sefaz_ends_with_pfx( pszSubject );
   HCERTSTORE hStore = lPfx ? hb_sefaz_open_pfx_store( pszSubject, pszPassword ) : CertOpenStore( CERT_STORE_PROV_SYSTEM_A, 0, 0, CERT_SYSTEM_STORE_CURRENT_USER | CERT_STORE_READONLY_FLAG, "MY" );
   PCCERT_CONTEXT pCert = NULL;

   if( ! hStore )
   {
      if( ! s_szSefazLastStage[ 0 ] ) hb_sefaz_set_error( "CertOpenStore" );
      hb_retc_null();
      return;
   }

   pCert = lPfx ? hb_sefaz_find_cert_with_private_key( hStore, "", pszThumb ) : hb_sefaz_find_cert( hStore, pszSubject, pszThumb );
   if( pCert )
   {
      hb_retclen( ( const char * ) pCert->pbCertEncoded, pCert->cbCertEncoded );
      CertFreeCertificateContext( pCert );
   }
   else
   {
      hb_sefaz_set_error( "find-cert" );
      hb_retc_null();
   }
   CertCloseStore( hStore, 0 );
}
#pragma ENDDUMP

/*
ZE_SPEDXMLCLASS - CLASSES PARA NFE/CTE/MDFE/CCE
2010.07.19 Jos� Quintas

2018.07.26 - Uso de MultipleNodeToArray - Tem nota com 1 unico produto come�ando em 17
*/

#include "hbclass.ch"
#include "sefazclass.ch"

CREATE CLASS NfeCadastroClass STATIC

   VAR  Nome                INIT ""
   VAR  Fantasia            INIT ""
   VAR  Cnpj                INIT ""
   VAR  InscricaoEstadual   INIT ""
   VAR  InscricaoMunicipal  INIT ""
   VAR  CNAE                INIT ""
   VAR  CRT                 INIT ""
   VAR  IndIEDest           INIT ""
   VAR  Endereco            INIT ""
   VAR  Numero              INIT ""
   VAR  Complemento         INIT ""
   VAR  Bairro              INIT ""
   VAR  Cidade              INIT ""
   VAR  CidadeIbge          INIT ""
   VAR  Uf                  INIT ""
   VAR  Cep                 INIT ""
   VAR  Pais                INIT ""
   VAR  PaisBACEN           INIT ""
   VAR  Telefone            INIT ""

   ENDCLASS

CREATE CLASS NfeEnderecoEntregaClass STATIC

   VAR  Cnpj        INIT ""
   VAR  Endereco    INIT ""
   VAR  Numero      INIT ""
   VAR  Compl       INIT ""
   VAR  Bairro      INIT ""
   VAR  Cidade      INIT ""
   VAR  CidadeIbge  INIT ""
   VAR  Uf          INIT ""

   ENDCLASS

CREATE CLASS NfeVolumesClass STATIC // From NfeTransporteClass

   VAR  Qtde         INIT 0
   VAR  Especie      INIT ""
   VAR  Marca        INIT ""
   VAR  PesoLiquido  INIT 0
   VAR  PesoBruto    INIT 0
   VAR  Numeros      INIT ""

   ENDCLASS

CREATE CLASS NfeTransporteClass STATIC

   VAR  ModFrete          INIT ""
   VAR  Nome              INIT ""
   VAR  Cnpj              INIT ""
   VAR  InscricaoEstadual INIT ""
   VAR  Endereco          INIT ""
   VAR  Cidade            INIT ""
   VAR  CidadeIbge        INIT ""
   VAR  Uf                INIT ""
   VAR  Placa             INIT ""
   VAR  PlacaUf           INIT ""
   VAR  Volumes
   METHOD Init()

   ENDCLASS

METHOD Init() CLASS NfeTransporteClass

   ::Volumes := NfeVolumesClass():New()

   RETURN SELF

CREATE CLASS NfeTotaisClass STATIC

   VAR  IcmBas               INIT 0
   VAR  IcmVal               INIT 0
   VAR  SubBas               INIT 0
   VAR  SubVal               INIT 0
   VAR  MonBas               INIT 0
   VAR  MonVal               INIT 0
   VAR  IpiVal               INIT 0
   VAR  IIVal                INIT 0
   VAR  IssVal               INIT 0
   VAR  PisVal               INIT 0
   VAR  CofVal               INIT 0
   VAR  ValPro               INIT 0
   VAR  ValSeg               INIT 0
   VAR  ValFre               INIT 0
   VAR  ValDesc              INIT 0
   VAR  ValOut               INIT 0
   VAR  ValNot               INIT 0
   VAR  ValTrib              INIT 0
   VAR  VIcmsDeson           INIT 0

   VAR  VFCPUFDest           INIT 0
   VAR  VICMSUFDest          INIT 0
   VAR  VICMSUFRemet         INIT 0
   VAR  VFCP                 INIT 0
   VAR  VFCPST               INIT 0
   VAR  VFCPSTRet            INIT 0
   VAR  VIPIDevol            INIT 0

   * Reforma Tribut�ria - totais
   VAR  RT_vBCIBSCBS         INIT 0
   VAR  RT_vIBSUF            INIT 0
   VAR  RT_vIBSMun           INIT 0
   VAR  RT_vIBS              INIT 0
   VAR  RT_vCBS              INIT 0
   VAR  RT_vCredPresIBS      INIT 0
   VAR  RT_vCredPresCBS      INIT 0
   VAR  RT_vCredPresCondIBS  INIT 0
   VAR  RT_vCredPresCondCBS  INIT 0

   ENDCLASS

CREATE CLASS NfeTributosClass STATIC

   VAR TriCBS INIT ""
   VAR TriIS  INIT ""

   * Reforma Tribut�ria - item
   VAR RTCST              INIT ""
   VAR RTcClassTrib       INIT ""
   VAR RTvBC              INIT 0

   VAR RTpIBSUF           INIT 0
   VAR RTpRedAliqIBSUF    INIT 0
   VAR RTpAliqEfetIBSUF   INIT 0
   VAR RTvIBSUF           INIT 0

   VAR RTpIBSMUN          INIT 0
   VAR RTpRedAliqIBSMUN   INIT 0
   VAR RTpAliqEfetIBSMUN  INIT 0
   VAR RTvIBSMUN          INIT 0

   VAR RTvIBS             INIT 0

   VAR RTpCBS             INIT 0
   VAR RTpRedAliqCBS      INIT 0
   VAR RTpAliqEfetCBS     INIT 0
   VAR RTvCBS             INIT 0

   VAR RTpIS              INIT 0
   VAR RTvIS              INIT 0

   ENDCLASS

CREATE CLASS NfeIIClass STATIC

   VAR  Base     INIT 0
   VAR  Aliquota INIT 0
   VAR  Valor    INIT 0

   ENDCLASS

CREATE CLASS NfeIpiClass STATIC

   VAR  Cst      INIT ""
   VAR  Enq      INIT ""
   VAR  Base     INIT 0
   VAR  Aliquota INIT 0
   VAR  Valor    INIT 0

   ENDCLASS

CREATE CLASS NfeIssClass STATIC

   VAR  Base     INIT 0
   VAR  Aliquota INIT 0
   VAR  Valor    INIT 0

   ENDCLASS

CREATE CLASS NfeIcmsClass STATIC

   VAR  Cst      INIT ""
   VAR  Base     INIT 0
   VAR  ModBC    INIT 0
   VAR  Reducao  INIT 0
   VAR  Aliquota INIT 0
   VAR  Valor    INIT 0
   VAR  VDeson   INIT 0 // Jackson 2018/03/27

   ENDCLASS

CREATE CLASS NfeIcmsStClass STATIC

   VAR  Base             INIT 0
   VAR  IVA              INIT 0
   VAR  Reducao          INIT 0
   VAR  Aliquota         INIT 0
   VAR  Valor            INIT 0

   VAR  BaseRet          INIT 0
   VAR  ValorRet         INIT 0
   VAR  ValorSubstituto  INIT 0
   VAR  pST              INIT 0

   VAR  pRedBCEfet       INIT 0
   VAR  vBCEfet          INIT 0
   VAR  pICMSEfet        INIT 0
   VAR  vICMSEfet        INIT 0

   ENDCLASS

CREATE CLASS NfeIcmsMonoClass STATIC

   VAR Base     INIT 0
   VAR Aliquota INIT 0
   VAR Valor    INIT 0

   ENDCLASS

CREATE CLASS NfePisClass STATIC

   VAR  Cst      INIT ""
   VAR  Base     INIT 0
   VAR  Aliquota INIT 0
   VAR  Valor    INIT 0

   ENDCLASS

CREATE CLASS NfeCofinsClass STATIC

   VAR  Cst      INIT ""
   VAR  Base     INIT 0
   VAR  Aliquota INIT 0
   VAR  Valor    INIT 0

   ENDCLASS

CREATE CLASS NfeRastroClass STATIC

   VAR nLote INIT ""
   VAR qLote INIT 0
   VAR dFab  INIT Ctod("")
   VAR dVal  INIT Ctod("")

   ENDCLASS

CREATE CLASS NfeProdutoClass STATIC

   VAR  Codigo        INIT ""
   VAR  Nome          INIT ""
   VAR  CfOp          INIT ""
   VAR  NCM           INIT ""
   VAR  GTIN          INIT ""
   VAR  GTINTRIB      INIT ""
   VAR  CEST          INIT ""
   VAR  CBenef        INIT ""
   VAR  Anp           INIT ""
   VAR  Unidade       INIT ""
   VAR  UnidTrib      INIT "" // 2019.01.08 Fernando Queiroz
   VAR  Pedido        INIT "" // 2018.01.23 Jackson
   VAR  Qtde          INIT 0
   VAR  QtdeTrib      INIT 0
   VAR  ValorUnitario INIT 0
   VAR  ValUnitTrib   INIT 0 // 2019.01.08 Fernando Queiroz
   VAR  ValorTotal    INIT 0
   VAR  Desconto      INIT 0 // 2018.01.23 Jackson
   VAR  Tributos
   VAR  Icms
   VAR  IcmsSt
   VAR  IcmsMono
   VAR  Iss
   VAR  Ipi
   VAR  Pis
   VAR  Cofins
   VAR  II
   VAR  InfAdicional  INIT "" // 2018.01.23 Jackson
   VAR  Rastro        INIT {}
   VAR  FCI           INIT ""
   METHOD Init()

   ENDCLASS

METHOD Init() CLASS NfeProdutoClass

   ::Icms     := NfeIcmsClass():New()
   ::IcmsSt   := NfeIcmsStClass():New()
   ::IcmsMono := NfeIcmsMonoClass():New()
   ::Iss      := NfeIssClass():New()
   ::II       := NfeIIClass():New()
   ::Ipi      := NfeIpiClass():New()
   ::Pis      := NfePisClass():New()
   ::Cofins   := NfeCofinsClass():New()
   ::Tributos := NfeTributosClass():New()

   RETURN SELF

CREATE CLASS NfePagamentosClass STATIC

   VAR  IndPag       INIT ""
   VAR  TipoPago     INIT ""
   VAR  ValorPago    INIT 0
   VAR  Integracao   INIT ""
   VAR  Cnpj_Ope     INIT ""
   VAR  Bandeira     INIT ""
   VAR  Autorizacao  INIT ""

   END CLASS

CREATE CLASS NfeDuplicataClass STATIC

   VAR  Fatura     INIT ""
   VAR  Duplicata  INIT ""  // 2018.01.23 Jackson
   VAR  Vencimento INIT Ctod("" )
   VAR  Valor      INIT 0

   ENDCLASS

CREATE CLASS DocSpedClass STATIC

   VAR  cChave                  INIT ""
   VAR  cModFis                 INIT ""
   VAR  TipoNFe                 INIT ""
   VAR  TipoEmissao             INIT ""
   VAR  cEvento                 INIT ""
   VAR  Protocolo               INIT ""
   VAR  cNumDoc                 INIT ""
   VAR  cSerie                  INIT ""
   VAR  DataEmissao             INIT Ctod( "" )
   VAR  DataHora                INIT ""
   VAR  DataSaida               INIT Ctod( "" )
   VAR  DataSaidaHora           INIT ""
   VAR  cAmbiente               INIT ""
   VAR  NaturezaOperacao        INIT ""

   * IDE
   VAR  cUF                     INIT ""
   VAR  cNF                     INIT ""
   VAR  cDV                     INIT ""
   VAR  idDest                  INIT ""
   VAR  tpImp                   INIT ""
   VAR  tpEmis                  INIT ""
   VAR  finNFe                  INIT ""
   VAR  indFinal                INIT ""
   VAR  indPres                 INIT ""
   VAR  indIntermed             INIT ""
   VAR  procEmi                 INIT ""
   VAR  verProc                 INIT ""
   VAR  cMunFG                  INIT ""

   * Protocolo / retorno
   VAR  VerAplic                INIT ""
   VAR  DigVal                  INIT ""
   VAR  DhRecbto                INIT ""
   VAR  xMotivo                 INIT ""

   VAR  Emitente
   VAR  Destinatario
   VAR  Remetente
   VAR  EnderecoEntrega
   VAR  Produto                 INIT {}
   VAR  Transporte
   VAR  Duplicata               INIT {}
   VAR  Totais
   VAR  ExportacaoUfEmbarque    INIT ""
   VAR  ExportacaoLocalEmbarque INIT ""
   VAR  InfAdicionais           INIT ""
   VAR  InfAdFisco              INIT ""
   VAR  cAssinatura             INIT ""
   VAR  cSequencia              INIT "01"
   VAR  Valor                   INIT 0
   VAR  cErro                   INIT ""
   VAR  PesoCarga               INIT 0
   VAR  ValorCarga              INIT 0
   VAR  Status                  INIT ""
   VAR  Pagamentos              INIT {}
   VAR  DocList                 INIT {}
   METHOD Init()

   ENDCLASS

METHOD Init() CLASS DocSpedClass

   ::Emitente        := NfeCadastroClass():New()
   ::Destinatario    := NfeCadastroClass():New()
   ::Remetente       := NfeCadastroClass():New()
   ::EnderecoEntrega := NfeEnderecoEntregaClass():New()
   ::Transporte      := NfeTransporteClass():New()
   ::Totais          := NfeTotaisClass():New()

   RETURN SELF

FUNCTION XmlToDoc( cXmlInput, lAutorizado )

   LOCAL oDocSped

   hb_Default( @lAutorizado, .T. )

   IF ! ["] $ cXmlInput  // Petrobras usa aspas simples
      cXmlInput := StrTran( cXmlInput, ['], ["] )
   ENDIF
   oDocSped := DocSpedClass():New()
   DO CASE
   CASE "<ProcInutNFe" $ cXmlInput
      oDocSped:cModFis := "55"
      oDocSped:cEvento := "110999"
      XmlToDocNfeInut( cXmlInput, @oDocSped )
   CASE "<nfeProc" $ cXmlInput
      oDocSped:cModFis := "55"
      oDocSped:cEvento  := "110100"
      XmlToDocNfeEmi( cXmlInput, @oDocSped )
   CASE "<cteProc" $ cXmlInput .OR. "<procCTe" $ cXmlInput // proc=CTE 3.0
      oDocSped:cModFis := "57"
      oDocSped:cEvento  := "110100"
      XmlToDocCteEmi( cXmlInput, @oDocSped )
   CASE "<mdfeProc" $ cXmlInput
      oDocSped:cModFis := "58"
      oDocSped:cEvento  := "110100"
      XmlToDocMDFEEmi( cXmlInput, @oDocSped )
   CASE "<procEventoNFe" $ cXmlInput .AND. "<descEvento>Cancelamento" $ cXmlInput
      oDocSped:cModFis := "55"
      oDocSped:cEvento  := "110111"
      XmlToDocNfeCancel( cXmlInput, @oDocSped )
   CASE "<procEventoNFe" $ cXmlInput .AND. "<descevento>EPEC" $ cXmlInput
      oDocSped:cModFis := "55"
      oDocSped:cEvento := "110140"
      XmlToDocNfeEvento( cXmlInput, @oDocSped )
   CASE "<procEventoNFe" $ cXmlInput
      oDocSped:cModFis := "55"
      oDocSped:cEvento := XmlNode( cXmlInput, "tpEvento" )
      IF Len( SoNumero( oDocSped:cEvento ) ) == 6
         XmlToDocNfeEvento( cXmlInput, @oDocSped )
      ENDIF
   CASE "<procCancNFe" $ cXmlInput .AND. "<xServ>CANCELAR" $ cXmlInput
      oDocSped:cModFis := "55"
      oDocSped:cEvento  := "110111"
      XmlToDocNFECancel( cXmlInput, @oDocSped )
   CASE "<procEventoCTe" $ cXmlInput .AND. "<descEvento>Cancelamento" $ cXmlInput
      oDocSped:cModFis := "57"
      oDocSped:cEvento  := "110111"
      XmlToDocCTeCancel( cXmlInput, @oDocSped )
   CASE "<procEventoMDFe" $ cXmlInput .AND. "<descEvento>Cancelamento" $ cXmlInput
      oDocSped:cModFis := "58"
      oDocSped:cEvento  := "110111"
      XmlToDocMDFECancel( cXmlInput, @oDocSped )
   CASE "<procEventoMDFe" $ cXmlInput .AND. "<descEvento>Encerramento" $ cXmlInput
      oDocSped:cModFis := "58"
      oDocSped:cEvento  := "110112"
      IF Len( SoNumero( oDocSped:cEvento ) ) == 6
         XmlToDocMDFEEvento( cXmlInput, @oDocSped )
      ENDIF
   CASE "<procEventoMDFe" $ cXmlInput
      oDocSped:cModFis := "58"
      oDocSped:cEvento  := XmlNode( cXmlInput, "tpEvento" )
      IF Len( SoNumero( oDocSped:cEvento ) ) == 6
         XmlToDocMDFEEvento( cXmlInput, @oDocSped )
      ENDIF
   CASE "<infMDFe" $ cXmlInput
      oDocSped:cModFis := "58"
      oDocSped:cEvento  := "000000"
      XmlToDocMDFEEmi( cXmlInput, @oDocSped )
   CASE "<infCte" $ cXmlInput
      oDocSped:cModFis := "57"
      oDocSped:cEvento  := "000000"
      XmlToDocCteEmi( cXmlInput, @oDocSped )
   CASE "<infNFe" $ cXmlInput
      oDocSped:cModFis := "55"
      oDocSped:cEvento  := "000000"
      XmlToDocNfeEmi( cXmlInput, @oDocSped )
   //CASE "<infEvento" $ cXmlInput
   //   // pode ser pra qualquer documento
   //   oDocSped:cModFis := "XX"
   //   oDocSped:cEvento  := "XX"
   OTHERWISE
      oDocSped:cErro := "Documento n�o identificado"
   ENDCASE
   IF Empty( oDocSped:Destinatario:Cnpj ) .AND. Empty( oDocSped:Destinatario:Nome )
      oDocSped:Destinatario := oDocSped:Emitente
   ENDIF
   oDocSped:cChave := SoNumeroCnpj( oDocSped:cChave )
   IF Len( oDocSped:cChave ) == 44
      oDocSped:cModFis := DfeModFis( oDocSped:cChave )
      oDocSped:cSerie  := Substr( oDocSped:cChave, 23, 3 )
   ENDIF
   DO CASE
   CASE ! Empty( oDocSped:cErro )
   CASE Len( oDocSped:cChave ) != 44
      oDocSped:cErro := "Tamanho da chave de acesso inv�lido"
   CASE Right( oDocSped:cChave, 1 ) != CalculaDigito( Substr( oDocSped:cChave, 1, 43 ), "11" )
      oDocSped:cErro := "D�gito da chave de acesso inv�lido"
   CASE Substr( oDocSped:cChave, 5, 2 ) < "01" .OR. Substr( oDocSped:cChave, 5, 2 ) > "12"
      oDocSped:cErro := "Mes da chave inv�lido"
   CASE ! ValidCnpjCpf( DfeEmitente( oDocSped:cChave ) )
      oDocSped:cErro := "CNPJ inv�lido na chave de acesso"
   CASE Val( oDocSped:Protocolo ) == 0 .AND. lAutorizado
      oDocSped:cErro := "Sem protocolo"
   CASE Empty( oDocSped:cAssinatura ) .AND. lAutorizado
      oDocSped:cErro := "Sem assinatura"
   CASE oDocSped:cAmbiente != WS_AMBIENTE_PRODUCAO
      oDocSped:cErro := "N�o � ambiente de produ��o"
   CASE oDocSped:cEvento = "110100" .AND. Empty( oDocSped:cNumDoc )
      oDocSped:cErro := "N�mero de documento vazio"
   ENDCASE
   IF ! Empty( oDocSped:cErro )
      oDocSped:cModFis := "XX"
      oDocSped:cEvento := "XXXXXX"
   ENDIF

   RETURN oDocSped

STATIC FUNCTION XmlNodeC( cXml, cTag )

   RETURN AllTrim( XmlNode( cXml, cTag ) )

STATIC FUNCTION XmlNodeN( cXml, cTag )

   RETURN Val( XmlNode( cXml, cTag ) )

STATIC FUNCTION XmlNodeDateOnly( cXml, cTag )

   LOCAL cRet := XmlNode( cXml, cTag )
   LOCAL cNum := SoNumero( cRet )

   IF Len( cNum ) >= 8
      RETURN Stod( Left( cNum, 8 ) )
   ENDIF

   RETURN Ctod("")

STATIC FUNCTION XmlNodeDateTime( cXml, cTag )

   RETURN AllTrim( XmlNode( cXml, cTag ) )

STATIC FUNCTION XmlPickNode( cXml, aTags )

   LOCAL xTag
   LOCAL cRet

   FOR EACH xTag IN aTags
      cRet := XmlNode( cXml, xTag )
      IF ! Empty( AllTrim( cRet ) )
         RETURN cRet
      ENDIF
   NEXT

   RETURN ""

STATIC FUNCTION XmlUpper( cText )

   RETURN Upper( AllTrim( cText ) )

STATIC FUNCTION XmlToDocNfeEmi( cXmlInput, oDocSped )

   LOCAL aList, aList2
   LOCAL cBlocoInfNfeComTag, cBlocoChave, cBlocoIde, cBlocoInfAdic
   LOCAL cBlocoEmit, cBlocoEndereco, cBlocoDest, cBlocoTransporte, cBlocoTransp, cBlocoVeiculo, cBlocoVol
   LOCAL cBlocoICMSTot, cBlocoIBSTot, cBlocoIBSGeral, cBlocoIBSUF, cBlocoIBSMUN, cBlocoCBS
   LOCAL cBlocoItem, cBlocoProd, cBlocoIpi, cBlocoIcms, cBlocoPis, cBlocoCofins, cBlocoRastro
   LOCAL cBlocoComb, cBlocoCobranca, cBlocoDup, cBlocoPG, cBlocoTributos, cBlocoPGPai
   LOCAL cBlocoIBSItem, cBlocoIBSItemUF, cBlocoIBSItemMUN, cBlocoIBSItemCBS
   LOCAL cTmp

   cBlocoInfNfeComTag := XmlNode( cXmlInput, "infNFe", .T. )

   cBlocoChave := XmlElement( cBlocoInfNfeComTag, "Id" )
   cBlocoChave := Substr( cBlocoChave, 4 )
   cBlocoChave := AllTrim( cBlocoChave )

   IF Len( cBlocoChave ) <> 44
      oDocSped:cErro := "Chave de Acesso Inv�lida"
      RETURN Nil
   ENDIF

   WITH OBJECT oDocSped
      :cChave := cBlocoChave
      :cAssinatura := XmlNode( cXmlInput, "Signature" )

      cBlocoIde := XmlNode( cXmlInput, "ide" )

      :cNumDoc := XmlNodeC( cBlocoIde, "nNF" )
      IF Empty( :cNumDoc )
         oDocSped:cErro := "Sem n�mero de documento"
         RETURN Nil
      ENDIF

      :cNumDoc          := StrZero( Val( :cNumDoc ), 9 )
      :TipoNFe          := XmlNodeC( cBlocoIde, "tpNF" )
      :TipoEmissao      := XmlNodeC( cBlocoIde, "tpEmis" )
      :NaturezaOperacao := XmlNodeC( cBlocoIde, "natOp" )

      :cUF         := XmlNodeC( cBlocoIde, "cUF" )
      :cNF         := XmlNodeC( cBlocoIde, "cNF" )
      :cDV         := XmlNodeC( cBlocoIde, "cDV" )
      :idDest      := XmlNodeC( cBlocoIde, "idDest" )
      :tpImp       := XmlNodeC( cBlocoIde, "tpImp" )
      :tpEmis      := XmlNodeC( cBlocoIde, "tpEmis" )
      :finNFe      := XmlNodeC( cBlocoIde, "finNFe" )
      :indFinal    := XmlNodeC( cBlocoIde, "indFinal" )
      :indPres     := XmlNodeC( cBlocoIde, "indPres" )
      :indIntermed := XmlNodeC( cBlocoIde, "indIntermed" )
      :procEmi     := XmlNodeC( cBlocoIde, "procEmi" )
      :verProc     := XmlNodeC( cBlocoIde, "verProc" )
      :cMunFG      := XmlNodeC( cBlocoIde, "cMunFG" )

      IF ! Empty( XmlNode( cBlocoIde, "dhEmi" ) )
         :DataHora    := XmlNodeDateTime( cBlocoIde, "dhEmi" )
         :DataEmissao := XmlNodeDateOnly( cBlocoIde, "dhEmi" )
         :DataSaidaHora := XmlNodeDateTime( cBlocoIde, "dhSaiEnt" )
         :DataSaida   := XmlNodeDateOnly( cBlocoIde, "dhSaiEnt" )
      ELSE
         :DataEmissao := XmlNodeDateOnly( cBlocoIde, "dEmi" )
         :DataSaida   := XmlNodeDateOnly( cBlocoIde, "dSaiEnt" )
      ENDIF

      IF Empty( :DataSaida )
         :DataSaida := :DataEmissao
      ENDIF

      :cAmbiente := XmlNodeC( cBlocoIde, "tpAmb" )

      cBlocoInfAdic := XmlNode( cXmlInput, "infAdic" )
      IF Empty( cBlocoInfAdic )
         cBlocoInfAdic := XmlNode( cXmlInput, "InfAdic" )
      ENDIF

      :InfAdicionais := XmlPickNode( cBlocoInfAdic, { "infCpl", "InfCpl" } )
      :InfAdFisco    := XmlPickNode( cBlocoInfAdic, { "infAdFisco", "InfAdFisco" } )
   ENDWITH

   cBlocoEmit := XmlNode( cXmlInput, "emit" )
   WITH OBJECT oDocSped:Emitente
      :Cnpj              := Transform( DfeEmitente( oDocSped:cChave ), "@R !!.!!!.!!!/!!!!-!!" )
      :Nome              := XmlUpper( XmlNodeC( cBlocoEmit, "xNome" ) )
      :Fantasia          := XmlUpper( XmlNodeC( cBlocoEmit, "xFant" ) )
      :InscricaoEstadual := XmlNodeC( cBlocoEmit, "IE" )
      :InscricaoMunicipal:= XmlNodeC( cBlocoEmit, "IM" )
      :CNAE              := XmlNodeC( cBlocoEmit, "CNAE" )
      :CRT               := XmlNodeC( cBlocoEmit, "CRT" )

      cBlocoEndereco := XmlNode( cBlocoEmit, "enderEmit" )
      :Endereco      := XmlUpper( XmlNodeC( cBlocoEndereco, "xLgr" ) )
      :Numero        := XmlNodeC( cBlocoEndereco, "nro" )
      :Complemento   := XmlNodeC( cBlocoEndereco, "xCpl" )
      :Bairro        := XmlUpper( XmlNodeC( cBlocoEndereco, "xBairro" ) )
      :CidadeIbge    := XmlNodeC( cBlocoEndereco, "cMun" )
      :Cidade        := XmlUpper( XmlNodeC( cBlocoEndereco, "xMun" ) )
      :Uf            := XmlUpper( XmlNodeC( cBlocoEndereco, "UF" ) )
      :Cep           := Transform( XmlNodeC( cBlocoEndereco, "CEP" ), "@R 99999-999" )
      :PaisBACEN     := XmlNodeC( cBlocoEndereco, "cPais" )
      :Pais          := XmlUpper( XmlNodeC( cBlocoEndereco, "xPais" ) )
      :Telefone      := XmlNodeC( cBlocoEndereco, "fone" )
   ENDWITH

   cBlocoDest := XmlNode( cXmlInput, "dest" )
   WITH OBJECT oDocSped:Destinatario
      :Cnpj := Trim( XmlNode( cBlocoDest, "CNPJ" ) )
      IF Len( Trim( :Cnpj ) ) = 0
         :Cnpj := XmlNode( cBlocoDest, "CPF" )
         :Cnpj := Transform( :Cnpj, "@R 999.999.999-99" )
      ELSE
         :Cnpj := Transform( :Cnpj, "@R !!.!!!.!!!/!!!!-!!" )
      ENDIF

      :Nome              := XmlUpper( XmlNodeC( cBlocoDest, "xNome" ) )
      :InscricaoEstadual := XmlNodeC( cBlocoDest, "IE" )
      :InscricaoMunicipal:= XmlNodeC( cBlocoDest, "IM" )
      :IndIEDest         := XmlNodeC( cBlocoDest, "indIEDest" )

      cBlocoEndereco := XmlNode( cBlocoDest, "enderDest" )
      :Endereco      := XmlUpper( XmlNodeC( cBlocoEndereco, "xLgr" ) )
      :Numero        := XmlNodeC( cBlocoEndereco, "nro" )
      :Complemento   := XmlNodeC( cBlocoEndereco, "xCpl" )
      :Bairro        := XmlUpper( XmlNodeC( cBlocoEndereco, "xBairro" ) )
      :CidadeIbge    := XmlNodeC( cBlocoEndereco, "cMun" )
      :Cidade        := XmlUpper( XmlNodeC( cBlocoEndereco, "xMun" ) )
      :Uf            := XmlUpper( XmlNodeC( cBlocoEndereco, "UF" ) )
      :Cep           := Transform( XmlNodeC( cBlocoEndereco, "CEP" ), "@R 99999-999" )
      :PaisBACEN     := XmlNodeC( cBlocoEndereco, "cPais" )
      :Pais          := XmlUpper( XmlNodeC( cBlocoEndereco, "xPais" ) )
      :Telefone      := XmlNodeC( cBlocoEndereco, "fone" )
   ENDWITH

   cBlocoTransporte := XmlNode( cXmlInput, "transp" )
   WITH OBJECT oDocSped:Transporte
      :ModFrete := XmlNodeC( cBlocoTransporte, "modFrete" )

      cBlocoTransp := XmlNode( cBlocoTransporte, "transporta" )
      :Cnpj              := Transform( XmlNodeC( cBlocoTransp, "CNPJ" ), "@R !!.!!!.!!!/!!!!-!!" )
      :Nome              := XmlUpper( XmlNodeC( cBlocoTransp, "xNome" ) )
      :InscricaoEstadual := XmlNodeC( cBlocoTransp, "IE" )
      :Endereco          := XmlUpper( XmlNodeC( cBlocoTransp, "xEnder" ) )
      :Cidade            := XmlUpper( XmlNodeC( cBlocoTransp, "xMun" ) )
      :Uf                := XmlUpper( XmlNodeC( cBlocoTransp, "UF" ) )

      cBlocoVol := XmlNode( cBlocoTransporte, "vol" )
      :Volumes:Qtde        := XmlNodeN( cBlocoVol, "qVol" )
      :Volumes:Especie     := XmlUpper( XmlNodeC( cBlocoVol, "esp" ) )
      :Volumes:Marca       := XmlUpper( XmlNodeC( cBlocoVol, "marca" ) )
      :Volumes:PesoLiquido := XmlNodeN( cBlocoVol, "pesoL" )
      :Volumes:PesoBruto   := XmlNodeN( cBlocoVol, "pesoB" )
      :Volumes:Numeros     := XmlPickNode( cBlocoVol, { "nVol", "nvol" } )

      cBlocoVeiculo := XmlNode( cBlocoTransporte, "veicTransp" )
      :PlacaUf := XmlUpper( XmlNodeC( cBlocoVeiculo, "UF" ) )
      :Placa   := XmlUpper( XmlNodeC( cBlocoVeiculo, "placa" ) )
   ENDWITH

   cBlocoICMSTot := XmlNode( cXmlInput, "ICMSTot" )
   WITH OBJECT oDocSped:Totais
      :IpiVal      := XmlNodeN( cBlocoICMSTot, "vIPI" )
      :IIVal       := XmlNodeN( cBlocoICMSTot, "vII" )
      :IcmBas      := XmlNodeN( cBlocoICMSTot, "vBC" )
      :IcmVal      := XmlNodeN( cBlocoICMSTot, "vICMS" )
      :SubBas      := XmlNodeN( cBlocoICMSTot, "vBCST" )
      :SubVal      := XmlNodeN( cBlocoICMSTot, "vST" )
      :MonBas      := XmlNodeN( cBlocoICMSTot, "qBCMono" )
      :MonVal      := XmlNodeN( cBlocoICMSTot, "vICMSMono" )
      :PisVal      := XmlNodeN( cBlocoICMSTot, "vPIS" )
      :CofVal      := XmlNodeN( cBlocoICMSTot, "vCOFINS" )
      :ValPro      := XmlNodeN( cBlocoICMSTot, "vProd" )
      :ValSeg      := XmlNodeN( cBlocoICMSTot, "vSeg" )
      :ValFre      := XmlNodeN( cBlocoICMSTot, "vFrete" )
      :ValDesc     := XmlNodeN( cBlocoICMSTot, "vDesc" )
      :ValOut      := XmlNodeN( cBlocoICMSTot, "vOutro" )
      :ValNot      := XmlNodeN( cBlocoICMSTot, "vNF" )
      :ValTrib     := XmlNodeN( cBlocoICMSTot, "vTotTrib" )
      :VIcmsDeson  := XmlNodeN( cBlocoICMSTot, "vICMSDeson" )
      :VFCPUFDest  := XmlNodeN( cBlocoICMSTot, "vFCPUFDest" )
      :VICMSUFDest := XmlNodeN( cBlocoICMSTot, "vICMSUFDest" )
      :VICMSUFRemet:= XmlNodeN( cBlocoICMSTot, "vICMSUFRemet" )
      :VFCP        := XmlNodeN( cBlocoICMSTot, "vFCP" )
      :VFCPST      := XmlNodeN( cBlocoICMSTot, "vFCPST" )
      :VFCPSTRet   := XmlNodeN( cBlocoICMSTot, "vFCPSTRet" )
      :VIPIDevol   := XmlNodeN( cBlocoICMSTot, "vIPIDevol" )
   ENDWITH

   cBlocoIBSTot := XmlNode( cXmlInput, "IBSCBSTot" )
   IF ! Empty( cBlocoIBSTot )
      WITH OBJECT oDocSped:Totais
         :RT_vBCIBSCBS := XmlNodeN( cBlocoIBSTot, "vBCIBSCBS" )

         cBlocoIBSGeral := XmlNode( cBlocoIBSTot, "gIBS" )
         cBlocoIBSUF    := XmlNode( cBlocoIBSGeral, "gIBSUF" )
         cBlocoIBSMUN   := XmlNode( cBlocoIBSGeral, "gIBSMun" )
         cBlocoCBS      := XmlNode( cBlocoIBSTot, "gCBS" )

         :RT_vIBSUF           := XmlNodeN( cBlocoIBSUF, "vIBSUF" )
         :RT_vIBSMun          := XmlNodeN( cBlocoIBSMUN, "vIBSMun" )
         :RT_vIBS             := XmlNodeN( cBlocoIBSGeral, "vIBS" )
         :RT_vCredPresIBS     := XmlNodeN( cBlocoIBSGeral, "vCredPres" )
         :RT_vCredPresCondIBS := XmlNodeN( cBlocoIBSGeral, "vCredPresCondSus" )

         :RT_vCBS             := XmlNodeN( cBlocoCBS, "vCBS" )
         :RT_vCredPresCBS     := XmlNodeN( cBlocoCBS, "vCredPres" )
         :RT_vCredPresCondCBS := XmlNodeN( cBlocoCBS, "vCredPresCondSus" )
      ENDWITH
   ENDIF

   aList := MultipleNodeToArray( cXmlInput, "det" )
   FOR EACH cBlocoItem IN aList
      AAdd( oDocSped:Produto, NFEProdutoClass():New() )

      WITH OBJECT Atail( oDocSped:Produto )

         cBlocoProd := XmlNode( cBlocoItem, "prod" )
         :Codigo          := XmlNodeC( cBlocoProd, "cProd" )
         :Nome            := XmlUpper( XmlNodeC( cBlocoProd, "xProd" ) )
         :CFOP            := Transform( XmlNodeC( cBlocoProd, "CFOP" ), "@R 9.9999" )
         :NCM             := XmlNodeC( cBlocoProd, "NCM" )
         :GTIN            := SoNumero( XmlNodeC( cBlocoProd, "cEAN" ) )
         :GTINTRIB        := SoNumero( XmlNodeC( cBlocoProd, "cEANTrib" ) )
         :CEST            := SoNumero( XmlNodeC( cBlocoProd, "CEST" ) )
         IF Empty( :GTINTRIB )
            :GTINTRIB := :GTIN
         ENDIF
         :CBenef          := XmlNodeC( cBlocoProd, "cBenef" )
         :Unidade         := XmlUpper( XmlNodeC( cBlocoProd, "uCom" ) )
         :UnidTrib        := XmlUpper( XmlNodeC( cBlocoProd, "uTrib" ) )
         :Qtde            := XmlNodeN( cBlocoProd, "qCom" )
         :QtdeTrib        := XmlNodeN( cBlocoProd, "qTrib" )
         :ValorUnitario   := XmlNodeN( cBlocoProd, "vUnCom" )
         :ValUnitTrib     := XmlNodeN( cBlocoProd, "vUnTrib" )
         :ValorTotal      := XmlNodeN( cBlocoProd, "vProd" )
         :Desconto        := XmlNodeN( cBlocoProd, "vDesc" )
         :Pedido          := XmlNodeC( cBlocoProd, "xPed" )
         :FCI             := XmlNodeC( cBlocoProd, "nFCI" )

         cBlocoTributos := XmlNode( cBlocoItem, "IBSCBS" )
         IF ! Empty( cBlocoTributos )
            :Tributos:TriCBS       := XmlNodeC( cBlocoTributos, "cClassTrib" )
            :Tributos:RTcClassTrib := XmlNodeC( cBlocoTributos, "cClassTrib" )
            :Tributos:RTCST        := XmlNodeC( cBlocoTributos, "CST" )

            cBlocoIBSItem := XmlNode( cBlocoTributos, "gIBSCBS" )
            :Tributos:RTvBC  := XmlNodeN( cBlocoIBSItem, "vBC" )
            :Tributos:RTvIBS := XmlNodeN( cBlocoIBSItem, "vIBS" )

            cBlocoIBSItemUF := XmlNode( cBlocoIBSItem, "gIBSUF" )
            :Tributos:RTpIBSUF := XmlNodeN( cBlocoIBSItemUF, "pIBSUF" )
            :Tributos:RTvIBSUF := XmlNodeN( cBlocoIBSItemUF, "vIBSUF" )
            :Tributos:RTpRedAliqIBSUF := XmlNodeN( cBlocoIBSItemUF, "pRedAliq" )
            IF :Tributos:RTpRedAliqIBSUF = 0
               cTmp := XmlNode( cBlocoIBSItemUF, "gRed" )
               :Tributos:RTpRedAliqIBSUF  := XmlNodeN( cTmp, "pRedAliq" )
               :Tributos:RTpAliqEfetIBSUF := XmlNodeN( cTmp, "pAliqEfet" )
            ELSE
               :Tributos:RTpAliqEfetIBSUF := XmlNodeN( cBlocoIBSItemUF, "pAliqEfet" )
            ENDIF

            cBlocoIBSItemMUN := XmlNode( cBlocoIBSItem, "gIBSMun" )
            :Tributos:RTpIBSMUN := XmlNodeN( cBlocoIBSItemMUN, "pIBSMun" )
            :Tributos:RTvIBSMUN := XmlNodeN( cBlocoIBSItemMUN, "vIBSMun" )
            :Tributos:RTpRedAliqIBSMUN := XmlNodeN( cBlocoIBSItemMUN, "pRedAliq" )
            IF :Tributos:RTpRedAliqIBSMUN = 0
               cTmp := XmlNode( cBlocoIBSItemMUN, "gRed" )
               :Tributos:RTpRedAliqIBSMUN  := XmlNodeN( cTmp, "pRedAliq" )
               :Tributos:RTpAliqEfetIBSMUN := XmlNodeN( cTmp, "pAliqEfet" )
            ELSE
               :Tributos:RTpAliqEfetIBSMUN := XmlNodeN( cBlocoIBSItemMUN, "pAliqEfet" )
            ENDIF

            cBlocoIBSItemCBS := XmlNode( cBlocoIBSItem, "gCBS" )
            :Tributos:RTpCBS := XmlNodeN( cBlocoIBSItemCBS, "pCBS" )
            :Tributos:RTvCBS := XmlNodeN( cBlocoIBSItemCBS, "vCBS" )
            :Tributos:RTpRedAliqCBS := XmlNodeN( cBlocoIBSItemCBS, "pRedAliq" )
            IF :Tributos:RTpRedAliqCBS = 0
               cTmp := XmlNode( cBlocoIBSItemCBS, "gRed" )
               :Tributos:RTpRedAliqCBS  := XmlNodeN( cTmp, "pRedAliq" )
               :Tributos:RTpAliqEfetCBS := XmlNodeN( cTmp, "pAliqEfet" )
            ELSE
               :Tributos:RTpAliqEfetCBS := XmlNodeN( cBlocoIBSItemCBS, "pAliqEfet" )
            ENDIF

            :Tributos:RTpIS := XmlNodeN( cBlocoTributos, "pIS" )
            :Tributos:RTvIS := XmlNodeN( cBlocoTributos, "vIS" )
         ENDIF

         cBlocoIpi := XmlNode( cBlocoItem, "IPI" )
         :Ipi:Cst         := XmlNodeC( cBlocoIpi, "CST" )
         :Ipi:Enq         := XmlNodeC( cBlocoIpi, "cEnq" )
         :Ipi:Base        := XmlNodeN( cBlocoIpi, "vBC" )
         :Ipi:Aliquota    := XmlNodeN( cBlocoIpi, "pIPI" )
         :Ipi:Valor       := XmlNodeN( cBlocoIpi, "vIPI" )

         cBlocoIcms := XmlNode( cBlocoItem, "ICMS" )
         :Icms:Cst     := XmlNodeC( cBlocoIcms, "orig" ) + XmlNodeC( cBlocoIcms, "CST" )
         :Icms:modBC   := XmlNodeN( cBlocoIcms, "modBC" )
         IF Len( :Icms:Cst ) < 3
            :Icms:Cst := XmlNodeC( cBlocoIcms, "orig" ) + XmlNodeC( cBlocoIcms, "CSOSN" )
         ENDIF
         :Icms:Base       := XmlNodeN( cBlocoIcms, "vBC" )
         :Icms:Reducao    := XmlNodeN( cBlocoIcms, "pRedBC" )
         :Icms:Aliquota   := XmlNodeN( cBlocoIcms, "pICMS" )
         :Icms:Valor      := XmlNodeN( cBlocoIcms, "vICMS" )
         :Icms:VDeson     := XmlNodeN( cBlocoIcms, "vICMSDeson" )

         :IcmsSt:Base            := XmlNodeN( cBlocoIcms, "vBCST" )
         :IcmsSt:IVA             := XmlNodeN( cBlocoIcms, "pMVAST" )
         :IcmsSt:Reducao         := XmlNodeN( cBlocoIcms, "pRedBCST" )
         :IcmsSt:Aliquota        := XmlNodeN( cBlocoIcms, "pICMSST" )
         :IcmsSt:Valor           := XmlNodeN( cBlocoIcms, "vICMSST" )
         :IcmsSt:BaseRet         := XmlNodeN( cBlocoIcms, "vBCSTRet" )
         :IcmsSt:ValorRet        := XmlNodeN( cBlocoIcms, "vICMSSTRet" )
         :IcmsSt:ValorSubstituto := XmlNodeN( cBlocoIcms, "vICMSSubstituto" )
         :IcmsSt:pST             := XmlNodeN( cBlocoIcms, "pST" )
         :IcmsSt:pRedBCEfet      := XmlNodeN( cBlocoIcms, "pRedBCEfet" )
         :IcmsSt:vBCEfet         := XmlNodeN( cBlocoIcms, "vBCEfet" )
         :IcmsSt:pICMSEfet       := XmlNodeN( cBlocoIcms, "pICMSEfet" )
         :IcmsSt:vICMSEfet       := XmlNodeN( cBlocoIcms, "vICMSEfet" )

         :IcmsMono:Base   := XmlNodeN( cBlocoIcms, "qBCMono" )
         :IcmsMono:Aliquota := XmlNodeN( cBlocoIcms, "adRemICMS" )
         :IcmsMono:Valor  := XmlNodeN( cBlocoIcms, "vICMSMono" )

         cBlocoPis := XmlNode( cBlocoItem, "PIS" )
         :Pis:Cst         := XmlNodeC( cBlocoPis, "CST" )
         :Pis:Base        := XmlNodeN( cBlocoPis, "vBC" )
         :Pis:Aliquota    := XmlNodeN( cBlocoPis, "pPIS" )
         :Pis:Valor       := XmlNodeN( cBlocoPis, "vPIS" )

         cBlocoCofins := XmlNode( cBlocoItem, "COFINS" )
         :Cofins:Cst      := XmlNodeC( cBlocoCofins, "CST" )
         :Cofins:Base     := XmlNodeN( cBlocoCofins, "vBC" )
         :Cofins:Aliquota := XmlNodeN( cBlocoCofins, "pCOFINS" )
         :Cofins:Valor    := XmlNodeN( cBlocoCofins, "vCOFINS" )

         cBlocoComb := XmlNode( cBlocoItem, "comb" )
         :Anp := XmlNodeC( cBlocoComb, "cProdANP" )

         aList2 := MultipleNodeToArray( cBlocoItem, "rastro" )
         FOR EACH cBlocoRastro IN aList2
            AAdd( :Rastro, NfeRastroClass():New() )
            WITH OBJECT Atail( :Rastro )
               :nLote := XmlNodeC( cBlocoRastro, "nLote" )
               :qLote := XmlNodeN( cBlocoRastro, "qLote" )
               :dFab  := XmlDate( XmlNode( cBlocoRastro, "dFab" ) )
               :dVal  := XmlDate( XmlNode( cBlocoRastro, "dVal" ) )
            ENDWITH
         NEXT

         :InfAdicional := XmlNodeC( cBlocoItem, "infAdProd" )
      ENDWITH
   NEXT

   cBlocoCobranca := XmlNode( cXmlInput, "cobr" )
   aList := MultipleNodeToArray( cBlocoCobranca, "dup" )
   FOR EACH cBlocoDup IN aList
      AAdd( oDocSped:Duplicata, NFEDuplicataClass():New() )
      WITH OBJECT Atail( oDocSped:Duplicata )
         :Fatura     := XmlNodeC( cBlocoCobranca, "nFat" )
         :Duplicata  := XmlNodeC( cBlocoDup, "nDup" )
         :Vencimento := XmlDate( XmlNode( cBlocoDup, "dVenc" ) )
         :Valor      := XmlNodeN( cBlocoDup, "vDup" )
      ENDWITH
   NEXT

   aList := MultipleNodeToArray( cXmlInput, "detPag" )
   FOR EACH cBlocoPG IN aList
      AAdd( oDocSped:Pagamentos, NfePagamentosClass():New() )
      WITH OBJECT Atail( oDocSped:Pagamentos )
         :IndPag      := XmlNodeC( cBlocoPG, "indPag" )
         :TipoPago    := XmlNodeC( cBlocoPG, "tPag" )
         :ValorPago   := XmlNodeN( cBlocoPG, "vPag" )
         :Integracao  := XmlNodeC( cBlocoPG, "tpIntegra" )
         :Cnpj_Ope    := XmlNodeC( cBlocoPG, "CNPJ" )
         :Bandeira    := XmlNodeC( cBlocoPG, "tBand" )
         :Autorizacao := XmlNodeC( cBlocoPG, "cAut" )
      ENDWITH
   NEXT

   IF Len( oDocSped:Pagamentos ) = 0
      aList := MultipleNodeToArray( cXmlInput, "pag" )
      FOR EACH cBlocoPGPai IN aList
         AAdd( oDocSped:Pagamentos, NfePagamentosClass():New() )
         WITH OBJECT Atail( oDocSped:Pagamentos )
            :IndPag      := XmlNodeC( cBlocoPGPai, "indPag" )
            :TipoPago    := XmlNodeC( cBlocoPGPai, "tPag" )
            :ValorPago   := XmlNodeN( cBlocoPGPai, "vPag" )
            :Integracao  := XmlNodeC( cBlocoPGPai, "tpIntegra" )
            :Cnpj_Ope    := XmlNodeC( cBlocoPGPai, "CNPJ" )
            :Bandeira    := XmlNodeC( cBlocoPGPai, "tBand" )
            :Autorizacao := XmlNodeC( cBlocoPGPai, "cAut" )
         ENDWITH
      NEXT
   ENDIF

   WITH OBJECT oDocSped
      :Protocolo := XmlNodeC( cXmlInput, "nProt" )
      :Status    := XmlNodeC( cXmlInput, "cStat" )
      :VerAplic  := XmlNodeC( cXmlInput, "verAplic" )
      :DhRecbto  := XmlNodeC( cXmlInput, "dhRecbto" )
      :DigVal    := XmlNodeC( cXmlInput, "digVal" )
      :xMotivo   := XmlNodeC( cXmlInput, "xMotivo" )
   ENDWITH

   RETURN Nil

STATIC FUNCTION XmlToDocNfeCancel( cXmlInput, oDocSped )

   LOCAL mChave, mProtocolo, mXmlInfComTag, mXmlInf

   IF "<infEvento" $ cXmlInput // Evento
      mChave := XmlNode( cXmlInput, "chNFe" )
      mProtocolo := XmlNode( XmlNode( cXmlInput, "retEvento" ), "nProt" )
      // tem o protocolo enviado para cancelamento, e o de retorno
   ELSE
      IF "retCancNFe" $ cXmlInput // Tem que ser antes do outro
         mXmlInf := XmlNode( cXmlInput, "infCanc" )
         mChave := XmlNode( mXmlInf, "chNFe" )
         mProtocolo := XmlNode( mXmlInf, "nProt" )
      ELSEIF "CancNFe" $ cXmlInput
         mXmlInfComTag := XmlNode( cXmlInput, "infCanc",.T. )
         mChave := XmlElement( mXmlInfComTag, "Id" )
         IF Substr( mChave,1, 2 ) == "ID"
            mChave := Substr( mChave, 3 )
         ENDIF
         mProtocolo := XmlNode( mXmlInfComTag, "nProt" )
      ELSE
         //SayScroll( "Formato do arquivo de cancelamento diferente. Avise JPA" )
         mChave := ""
         mProtocolo := ""
      End If
   ENDIF
   IF Len( AllTrim( mChave ) ) == 0
      oDocSped:cErro := "Sem chave de acesso"
      RETURN .F.
   ELSE
      oDocSped:cChave   := mChave
      oDocSped:Protocolo     := mProtocolo
      oDocSped:cAmbiente     := XmlNode( cXmlInput, "tpAmb" )
      oDocSped:Emitente:Cnpj := Transform( DfeEmitente( mChave ), "@R !!.!!!.!!!/!!!!-!!" )
      oDocSped:cNumDoc       := DfeNumero( mChave )
      oDocSped:cAssinatura   := XmlNode( cXmlInput, "Signature" )
      oDocSped:Status        := "111"
   ENDIF

   RETURN Nil

STATIC FUNCTION XmlToDocNfeEvento( XmlInput, oDocSped )

   LOCAL mXmlProcEvento, mXmlEvento, mXmlInfEvento, mXmlRetEvento

   mXmlProcEvento := XmlNode( XmlInput, "procEventoNFe" )
      mXmlEvento := XmlNode( mXmlProcEvento, "evento" )
         mXmlInfEvento := XmlNode( mXmlEvento, "infEvento" )
            oDocSped:cAmbiente         := XmlNode( mXmlInfEvento, "tpAmb" )
            oDocSped:Emitente:Cnpj     := Transform( XmlNode( mXmlInfEvento, "CNPJ" ), "@R !!.!!!.!!!/!!!!-!!" )
            oDocSped:Destinatario:Cnpj := oDocSped:Emitente:Cnpj
            oDocSped:cChave       := XmlNode( mXmlInfEvento, "chNFe" )
            //oDocSped:TipoEvento      := XmlNode( mXmlInfEvento, "tpEvento" )
            oDocSped:cSequencia        := StrZero( Val( XmlNode( mXmlInfEvento, "nSeqEvento" ) ), 2 )
            // mXmldetEvento           := XmlNode( mXmlInfEvento, "detEvento" )
               //oDocSped:Texto        := XmlNode( mXmlDetEvento, "xCorrecao" )
         oDocSped:cAssinatura          := XmlNode( mXmlEvento, "Signature" )
      mXmlRetEvento := XmlNode( mXmlProcEvento, "retEvento" )
         mXmlInfEvento := XmlNode( mXmlRetEvento, "infEvento" )
            //oDocSped:Status          := XmlNode( mXmlInfEvento, "cStat" )
            oDocSped:Protocolo         := XmlNode( mXmlInfEvento, "nProt" )

   RETURN Nil

STATIC FUNCTION XmlToDocMDFEEmi( cXmlInput, oMDFE )

   LOCAL cBlocoInfNfeComTag, cBlocoChave, cBlocoIde, cBlocoInfAdic
   LOCAL cBlocoEmit, cBlocoEndereco

   cXmlInput := XmlTransform( cXmlInput )

   cBlocoInfNfeComTag := XmlNode( cXmlInput, "infMDFe", .T. )

   cBlocoChave := XmlElement( cBlocoInfNfeComTag, "Id" )
   cBlocoChave := Substr( cBlocoChave, 5, 44 )
   cBlocoChave := AllTrim( cBlocoChave )
   IF Len( cBlocoChave ) <> 44
      oMDFE:cErro := "Chave de acesso inv�lida"
      RETURN Nil
   ENDIF
   oMDFE:cChave := cBlocoChave
   oMDFE:cAssinatura := XmlNode( cXmlInput, "Signature" )
   cBlocoIde := XmlNode( cXmlInput, "ide" )
      oMDFE:cNumDoc := XmlNode( cBlocoIde, "nMDF" )
      IF Len( Trim( oMDFE:cNumDoc ) ) = 0
         oMDFE:cErro := "Sem n�mero de documento"
         RETURN Nil
      ENDIF
      oMDFE:cNumDoc     := StrZero( Val( oMDFE:cNumDoc ), 9 )
      oMDFE:DataEmissao := XmlDate( XmlNode( cBlocoIde, "dhEmi" ) )
      oMDFE:cAmbiente   := XmlNode( cBlocoIde, "tpAmb" )

   cBlocoInfAdic := XmlNode( cXmlInput, "InfAdic" )
      oMDFE:InfAdicionais := XmlNode( cBlocoInfAdic, "InfCpl" )

   cBlocoEmit := XmlNode( cXmlInput, "emit" )
      oMDFE:Emitente:Cnpj              := Trim( Transform( XmlNode( cBlocoEmit, "CNPJ" ), "@R !!.!!!.!!!/!!!!-!!" ) )
      oMDFE:Emitente:Nome              := Upper( XmlNode( cBlocoEmit, "xNome" ) )
      oMDFE:Emitente:InscricaoEstadual := XmlNode( cBlocoEmit, "IE" )
      cBlocoEndereco := XmlNode( cBlocoEmit, "enderEmit" )
         oMDFE:Emitente:Endereco   := Upper( XmlNode( cBlocoEndereco, "xLgr" ) )
         oMDFE:Emitente:Numero     := XmlNode( cBlocoEndereco, "nro" )
         oMDFE:Emitente:Complemento:= XmlNode( cBlocoEndereco, "xCpl" )
         oMDFE:Emitente:Bairro     := Upper( XmlNode( cBlocoEndereco, "xBairro" ) )
         oMDFE:Emitente:CidadeIbge := XmlNode( cBlocoEndereco, "cMun" )
         oMDFE:Emitente:Cidade     := Upper( XmlNode( cBlocoEndereco, "xMun" ) )
         oMDFE:Emitente:Uf         := Upper( XmlNode( cBlocoEndereco, "UF" ) )
         oMDFE:Emitente:Cep        := Transform( XmlNode( cBlocoEndereco, "CEP" ), "@R 99999-999" )
         oMDFE:Emitente:Telefone   := XmlNode( cBlocoEndereco, "fone" )

   oMDFE:Protocolo := XmlNode( cXmlInput, "nProt" )
   oMDFE:Status    := XmlNode( cXmlInput, "cStat" )

   RETURN Nil

STATIC FUNCTION XmlToDocMDFEEvento( XmlInput, oDocSped )

   LOCAL mXmlProcEvento, mXmlEvento, mXmlInfEvento

   mXmlProcEvento := XmlNode( XmlInput, "procEventoMDFe" )
      mXmlEvento := XmlNode( mXmlProcEvento, "eventoMDFe" )
         mXmlInfEvento := XmlNode( mXmlEvento, "infEvento" )
            oDocSped:cAmbiente         := XmlNode( mXmlInfEvento, "tpAmb" )
            oDocSped:Emitente:Cnpj     := Transform( XmlNode( mXmlInfEvento, "CNPJ" ), "@R !!.!!!.!!!/!!!!-!!" )
            oDocSped:Destinatario:Cnpj := oDocSped:Emitente:Cnpj
            oDocSped:cChave       := XmlNode( mXmlInfEvento, "chMDFe" )
            //oDocSped:TipoEvento      := XmlNode( mXmlInfEvento, "tpEvento" )
            oDocSped:cSequencia        := StrZero(Val( XmlNode( mXmlInfEvento, "nSeqEvento" ) ), 2 )
            // mXmldetEvento           := XmlNode( mXmlInfEvento, "detEvento" )
               //oDocSped:Texto        := XmlNode( mXmlDetEvento, "xCorrecao" )
         oDocSped:cAssinatura          := XmlNode( mXmlEvento, "Signature" )
      oDocSped:Protocolo               := XmlNode( mXmlEvento, "nProt" )

   RETURN Nil

STATIC FUNCTION XmlToDocMDFECancel( cXmlInput, oDocSped )

   LOCAL mChave, mProtocolo

   IF "<infEvento" $ cXmlInput // Evento
      mChave := XmlNode( cXmlInput, "chMDFe" )
      mProtocolo := XmlNode( XmlNode( cXmlInput, "retEventoMDFe" ), "nProt" )
      // tem o protocolo enviado para cancelamento, e o de retorno
   ENDIF
   IF Len( AllTrim( mChave ) ) == 0
      oDocSped:cErro := "Sem chave de acesso"
      RETURN .F.
   ELSE
      oDocSped:cAmbiente     := XmlNode( cXmlInput, "tpAmb" )
      oDocSped:cSequencia    := StrZero( Val( XmlNode( cXmlInput, "nSeqEvento" ) ), 2 )
      oDocSPed:cChave   := mChave
      oDocSped:Protocolo     := mProtocolo
      oDocSped:Emitente:Cnpj := Transform( DfeEmitente( mChave ), "@R !!.!!!.!!!/!!!!-!!" )
      oDocSPed:cNumDoc       := DfeNumero( mChave )
      oDocSped:cAssinatura   := XmlNode( cXmlInput, "Signature" )
      oDocSped:Status        := "111"
   ENDIF

   RETURN Nil

STATIC FUNCTION XmlToDocNfeInut( cXmlInput, oDocSped )

   LOCAL nPosIni, cModelo, cSerie

   oDocSped:cAmbiente := XmlNode( cXmlInput, "tpAmb" )
   nPosIni := At( cXmlInput, [<InfInut] )
   IF nPosIni != 0
      oDocSped:DataEmissao   := Stod( Left( SoNumero( XmlNode( cXmlInput, "dhRecbto" ) ), 8 ) )
      oDocSped:Emitente:Cnpj := Transform( XmlNode( cXmlInput, "CNPJ" ), "@R !!.!!!.!!!/!!!!-!!" )
      oDocSped:cAssinatura   := XmlNode( cXmlInput, "Signature" )
      oDocSped:cSequencia    := "01"
      oDocSped:Protocolo     := XmlNode( cXmlInput, "infInut" )
      oDocSped:Status        := "111"
      oDocSped:DataEmissao   := Stod( Left( SoNumero( XmlNode( cXmlInput, "dhRecbto" ) ), 8 ) )
      cModelo                := StrZero( Val( XmlNode( cXmlInput, "mod" ) ), 2 )
      cSerie                 := Str( Val( XmlNode( cXmlInput, "serie" ) ), 1 )
      oDocSped:cNumDoc       := StrZero( Val( XmlNode( cXmlInput, "nNFIni" ) ), 9 )
      oDocSped:cChave        := Substr( SoNumero( Substr( cXmlInput, nPosIni, 60 ) ), 1, 2 ) + ;
                                Substr( Dtos( oDocSped:DataEmissao ), 3, 4 ) + ;
                                SoNumero( oDocSped:Emitente:Cnpj ) + ;
                                cModelo + ;
                                cSerie + ;
                                StrZero( Val( oDocSped:cNumDoc ), 9 ) + ;
                                "1" + ;
                                StrZero( 0, 8 )
      oDocSped:cChave         := oDocSped:cChave + CalculaDigito( oDocSped:cChave, "11" )
   ENDIF

   RETURN Nil

STATIC FUNCTION XmlToDocCteEmi( XmlInput, oDocSped )

   LOCAL XmlProc, XmlCte, XmlInfCte, XmlIde, mTemp, XmlEmit, XmlEndereco
   LOCAL XmlRemetente, XmlDestinatario, XmlPrest, XmlProt, XmlInfProt, XmlInfCteComTag

   IF Empty( XmlProc := XmlNode( XmlInput, "cteProc" ) )
      XmlProc := XmlNode( XmlInput, "procCTe" )
      IF Empty( XmlProc )
         XmlProc := XmlInput
      ENDIF
   ENDIF

      XmlCte := XmlNode( XmlProc, "CTe" )
         XmlInfCteComTag := XmlNode( XmlProc, "CTe", .T. )
         XmlInfCte := XmlNode( XmlCte, "infCte" )
            oDocSped:cChave := Substr( XmlElement( XmlInfCteComTag, "id" ), 4 )  // id minusculo
            IF Empty( oDocSped:cChave )
               oDocSped:cChave := Substr( XmlElement( XmlInfCteComTag, "Id" ), 4 ) // id maiusculo
            ENDIF
            XmlIde := XmlNode( XmlInfCte, "ide" )
               oDocSped:cNumDoc := StrZero( Val( XmlNode( XmlIde, "nCT" ) ), 9 )
               mTemp := XmlNode( XmlIde, "dhEmi" ) // Data/hora
               mTemp := Substr( mTemp, 1, 10 ) // Data aaaa-mm-dd
               mTemp := Substr( mTemp, 9, 2 ) + "/" + Substr( mTemp, 6, 2 ) + "/" + Substr( mTemp, 1, 4 )
               oDocSped:DataEmissao := Ctod( mTemp )
               oDocSped:cAmbiente   := XmlNode( XmlIde, "tpAmb" )
            XmlEmit := XmlNode( XmlInfCte, "emit" )
               oDocSped:Emitente:Cnpj := Trim( Transform( XmlNode( XmlEmit, "CNPJ" ), "@R !!.!!!.!!!/!!!!-!!" ) )
               oDocSped:Emitente:Nome := XmlNode( XmlEmit, "xNome" )
               XmlEndereco := XmlNode( XmlEmit, "enderEmit" )
                  oDocSped:Emitente:Endereco := XmlNode( XmlEndereco, "xLgr" ) + " " + XmlNode( XmlEndereco, "nro" )
                  oDocSped:Emitente:Bairro   := XmlNode( XmlEndereco, "xBairro" )
                  oDocSped:Emitente:Cidade   := XmlNode( XmlEndereco, "xMun" )
                  oDocSped:Emitente:Uf       := XmlNode( XmlEndereco, "UF" )
                  oDocSped:Emitente:Cep      := Transform( XmlNode( XmlEndereco, "CEP" ), "@R 99999-999" )
                  oDocSped:Emitente:Telefone := XmlNode( XmlEndereco, "fone" )
            XmlRemetente := XmlNode( XmlInfCte, "rem" )
               oDocSped:Remetente:Cnpj := Trim( Transform( XmlNode( XmlRemetente, "CNPJ" ), "@R !!.!!!.!!!/!!!!-!!" ) )
               oDocSped:Remetente:Nome := XmlNode( XmlRemetente, "xNome" )
               XmlEndereco := XmlNode( XmlRemetente, "enderReme" )
                  oDocSped:Remetente:Endereco := XmlNode( XmlRemetente, "xLgr" ) + " " + XmlNode( XmlEndereco, "nro" )
                  oDocSped:Remetente:Bairro   := XmlNode( XmlRemetente, "xBairro" )
                  oDocSped:Remetente:Cidade   := XmlNode( XmlRemetente, "xMun" )
                  oDocSped:Remetente:Uf       := XmlNode( XmlRemetente, "UF" )
                  oDocSped:Remetente:Cep      := Transform( XmlNode( XmlRemetente, "CEP" ), "@R 99999-999" )
                  oDocSped:Remetente:Telefone := XmlNode( XmlRemetente, "fone" )
            XmlDestinatario := XmlNode( XmlInfCte, "dest" )
               oDocSped:Destinatario:Cnpj := Trim( XmlNode( XmlDestinatario, "CNPJ" ) )
               IF Empty( oDocSped:Destinatario:Cnpj )
                  oDocSped:Destinatario:Cnpj := Transform( XmlNode( XmlDestinatario, "CPF" ), "@R 999.999.999-99" )
               ELSE
                  oDocSped:Destinatario:Cnpj := Transform( oDocSped:Destinatario:Cnpj, "@R !!.!!!.!!!/!!!!-!!" )
               ENDIF
               oDocSped:Destinatario:Nome := XmlNode( XmlDestinatario, "xNome" )
               XmlEndereco := XmlNode( XmlDestinatario, "enderDest" )
                  oDocSped:Destinatario:Endereco := XmlNode( XmlDestinatario, "xLgr" ) + " " + XmlNode( XmlEndereco, "nro" )
                  oDocSped:Destinatario:Bairro   := XmlNode( XmlDestinatario, "xBairro" )
                  oDocSped:Destinatario:Cidade   := XmlNode( XmlDestinatario, "xMun" )
                  oDocSped:Destinatario:Uf       := XmlNode( XmlDestinatario, "UF" )
                  oDocSped:Destinatario:Cep      := XmlNode( XmlDestinatario, "CEP" )
                  oDocSped:Destinatario:Telefone := XmlNode( XmlDestinatario, "fone" )
               XmlPrest := XmlNode( XmlInfCte, "vPrest" )
                  oDocSped:Valor := Val( XmlNode(XmlPrest, "vTPrest" ) )
      oDocSped:PesoCarga  := Val( XmlNode( XmlCte, "qCarga" ) )
      oDocSped:ValorCarga := Val( XmlNode( XmlCte, "vCarga" ) )
      oDocSped:cAssinatura := XmlNode( XmlCte, "Signature" )

   mTemp := XmlNode( XmlProc, "infDoc" )
   AAdd( oDocSped:DocList, XmlNode( mTemp, "chave" ) )

   XmlProt := XmlNode(XmlProc, "protCTe" )
      XmlInfProt := XmlNode( XmlProt, "infProt" )
      oDocSped:Protocolo := XmlNode( XmlInfProt, "nProt" )
      oDocSped:Status    := XmlNode( XmlProt, "cStat" )

   RETURN oDocSped

STATIC FUNCTION XmlToDocCteCancel( cXmlInput, oDocSped )

   LOCAL mXmlInfCanc, mXmlInfCancComTag, mChave, mProtocolo

   mProtocolo := ""
   mChave     := ""
   IF "procEventoCTe" $ cXmlInput
      mChave := XmlNode( cXmlInput, "chCTe" )
      mProtocolo := XmlNode( XmlNode( cXmlInput, "retEventoCTe" ), "nProt" )
   ELSEIF "procCancCTe" $ cXmlInput
      mXmlInfCanc := XmlNode( cXmlInput, "procCancCTe" )
      mXmlInfCancComTag := XmlNode( cXmlInput, "procCancCTe", .T. )
      mChave      := XmlElement( mXmlInfCancComTag, "Id" )
      mChave      := Substr( mChave, 3 )
      mProtocolo  := XmlNode( mXmlInfCanc, "nProt" )
   ELSEIF "retCancCTe" $ cXmlInput
      mXmlInfCanc := XmlNode( cXmlInput, "retCancCTe" )
      mChave      := XmlNode( mXmlInfCanc, "chCTe" )
      mProtocolo  := XmlNode( mXmlInfCanc, "nProt" )
   ENDIF
   IF Len( Trim( mChave ) ) != 0
      oDocSped:cChave        := mChave
      oDocSped:Protocolo     := mProtocolo
      oDocSped:cAmbiente     := XmlNode( cXmlInput, "tpAmb" )
      oDocSped:Emitente:Cnpj := Transform( DfeEmitente( mChave ), "@R !!.!!!.!!!/!!!!-!!" )
      oDocSped:cNumDoc       := DfeNumero( mChave )
      oDocSped:cAssinatura   := XmlNode( cXmlInput, "Signature" )
      oDocSped:Status        := "111"
   ENDIF

   RETURN oDocSped

FUNCTION PicNfe( cChave )

   RETURN Transform( cChave, "@R !!-!!/!!-!!.!!!.!!!/!!!!-!!.!!.!!!.!!!!!!!!!.!.!!!!!!!!.!" )

FUNCTION DfeModFis( cKey )

   RETURN Substr( cKey, 21, 2 )

FUNCTION DfeSerie( cKey )

   RETURN Substr( cKey, 23, 3 )

FUNCTION DfeNumero( cKey )

   RETURN Substr( cKey, 26, 9 )

FUNCTION DfeEmitente( cText )

   cText := Substr( cText, 7, 14 )

   IF Left( cText, 3 ) == "000"
      // 11 d�gitos pode ser CPF
      // mas ainda pode ser cnpj
      IF ! ValidCnpj( cText )
         cText := Right( cText, 11 )
      ENDIF
   ENDIF

   RETURN cText

FUNCTION DFeUF( cKey )

   RETURN SefazClass():UFSigla( cKey )

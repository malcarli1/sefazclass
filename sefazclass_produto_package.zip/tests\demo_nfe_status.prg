#include "sefazclass.ch"

PROCEDURE Main()
   LOCAL oSefaz := SefazClass():New()
   LOCAL cIni := IIf( hb_ArgC() >= 1, hb_ArgV( 1 ), "sefaz.ini" )
   LOCAL hCert, cRet

   IF ! File( cIni )
      ? "Arquivo INI nao encontrado:", cIni
      ? "Copie tests\\sefaz.ini.example para sefaz.ini e ajuste certificado/UF/ambiente."
      RETURN
   ENDIF

   oSefaz:LoadConfigIni( cIni )
   hCert := oSefaz:ValidarCertificado()
   IF ! hCert[ "ok" ]
      ? "Certificado invalido:", hCert[ "motivo" ]
      ? oSefaz:Diagnostico()
      RETURN
   ENDIF

   cRet := oSefaz:NFeStatus( oSefaz:cUF, oSefaz:cCertificado, oSefaz:cAmbiente )
   hb_MemoWrit( "ret_nfe_status.xml", cRet )
   ? "Status:", oSefaz:cStatus
   ? "Motivo:", oSefaz:cMotivo
   ? "Transporte:", oSefaz:cUltimoTransporte
   ? "Retorno salvo em ret_nfe_status.xml"
RETURN

#include "sefazclass.ch"

PROCEDURE Main()
   LOCAL cXml, cRet, cCert, cSenha, cModo

   IF hb_ArgC() < 4
      ? "Uso:"
      ? "  demo_assinatura xml_entrada xml_saida subject certificado"
      ? "  demo_assinatura xml_entrada xml_saida thumbprint hash"
      ? "  demo_assinatura xml_entrada xml_saida pfx arquivo.pfx senha"
      RETURN
   ENDIF

   cXml := hb_MemoRead( hb_ArgV( 1 ) )
   cModo := Lower( hb_ArgV( 3 ) )
   cCert := hb_ArgV( 4 )
   cSenha := IIf( hb_ArgC() >= 5, hb_ArgV( 5 ), "" )

   DO CASE
   CASE cModo == "subject"
      cRet := SefazAssinaXmlSha1( @cXml, cCert, cSenha )
   CASE cModo == "thumbprint"
      cRet := SefazAssinaXmlSha1Thumbprint( @cXml, cCert, cSenha )
   CASE cModo == "pfx"
      cRet := SefazAssinaXmlSha1Pfx( @cXml, cCert, cSenha )
   OTHERWISE
      ? "Modo invalido:", cModo
      RETURN
   ENDCASE

   IF cRet != "OK"
      ? cRet
      RETURN
   ENDIF

   hb_MemoWrit( hb_ArgV( 2 ), cXml )
   ? "XML assinado gerado:", hb_ArgV( 2 )
RETURN

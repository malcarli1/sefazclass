#include "sefazclass.ch"

PROCEDURE Main()
   LOCAL oSefaz := SefazClass():New()

   ? "Demo de configuracao curl.exe para transporte SOAP."
   ? "Este demo nao envia para a SEFAZ; serve como modelo de uso."
   ?
   ? "PFX/P12:"
   ? '  oSefaz:CertificadoPfx( "C:\certificados\empresa.pfx", "senha" )'
   ? '  oSefaz:UseCurl( .T., "C:\certificados\empresa.pfx", "senha", "P12" )'
   ?
   ? "PEM:"
   ? '  oSefaz:UseCurl( .T., "C:\certificados\cert.pem", "senha", "PEM", "C:\certificados\key.pem" )'
   ?

   oSefaz:UseCurl( .T., "C:\certificados\empresa.pfx", "senha", "P12" )
   oSefaz:lCurlKeepTemp := .T.

   ? "lUseCurl.......:", oSefaz:lUseCurl
   ? "cCurlCertFile..:", oSefaz:cCurlCertFile
   ? "cCurlCertType..:", oSefaz:cCurlCertType
   ? "lCurlKeepTemp..:", oSefaz:lCurlKeepTemp
RETURN

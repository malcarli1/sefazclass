#include "hbclass.ch"

CREATE CLASS TSefazProdutoDanfe

   DATA oProduto

   METHOD New( oProduto )
   METHOD SimplificadoHtml( cXml, cLogoHtml )
   METHOD SimplificadoTexto( cXml )
   METHOD SimplificadoSalvarHtml( cArquivoSaida, cXml, cLogoHtml )

ENDCLASS

METHOD New( oProduto ) CLASS TSefazProdutoDanfe
   ::oProduto := oProduto
RETURN Self

METHOD SimplificadoHtml( cXml, cLogoHtml ) CLASS TSefazProdutoDanfe
   IF Empty( cXml )
      cXml := IIf( Empty( ::oProduto:oBase:cXmlAutorizado ), ::oProduto:oBase:cXmlRetorno, ::oProduto:oBase:cXmlAutorizado )
   ENDIF
RETURN SefazDanfeSimplificadoHtml( cXml, cLogoHtml )

METHOD SimplificadoTexto( cXml ) CLASS TSefazProdutoDanfe
   IF Empty( cXml )
      cXml := IIf( Empty( ::oProduto:oBase:cXmlAutorizado ), ::oProduto:oBase:cXmlRetorno, ::oProduto:oBase:cXmlAutorizado )
   ENDIF
RETURN SefazDanfeSimplificadoTexto( cXml )

METHOD SimplificadoSalvarHtml( cArquivoSaida, cXml, cLogoHtml ) CLASS TSefazProdutoDanfe
   IF Empty( cXml )
      cXml := IIf( Empty( ::oProduto:oBase:cXmlAutorizado ), ::oProduto:oBase:cXmlRetorno, ::oProduto:oBase:cXmlAutorizado )
   ENDIF
RETURN SefazDanfeSimplificadoSalvarHtml( cXml, cArquivoSaida, cLogoHtml )


#include "hbclass.ch"

CREATE CLASS TSefazProduto

   DATA oBase

   METHOD New()
   METHOD LoadConfigIni( cIni )
   METHOD Base()
   METHOD Diagnostico()
   METHOD Retorno( cXml, cOperacao )
   METHOD RetornoResumo( xRet )
   METHOD RetornoEventoCount( xRet )
   METHOD RetornoEvento( xRet, nIndex )
   METHOD Call( cMetodo, aParams, cOperacao )
   METHOD Ambiente( cAmbiente )
   METHOD UF( cUF )
   METHOD CertificadoNome( cCertificado )
   METHOD TempoEspera( nTempo )
   METHOD SoapTimeout( nTimeout )
   METHOD NFCe( lNFCe, cIdToken, cCSC )
   METHOD Contingencia( lContingencia )
   METHOD Transporte( cTransporte, lFallback )
   METHOD WinHttp( lUse, cPfxFile, cPassword, lIgnoreSsl )
   METHOD Curl( lUse, cCertFile, cPassword, cCertType, cKeyFile )
   METHOD Debug( lDebug, cLogDir )

   METHOD Certificado()
   METHOD NFe()
   METHOD CTe()
   METHOD MDFe()
   METHOD BPe()
   METHOD Danfe()

ENDCLASS

METHOD New() CLASS TSefazProduto
   ::oBase := SefazClass():New()
RETURN Self

METHOD LoadConfigIni( cIni ) CLASS TSefazProduto
   ::oBase:LoadConfigIni( hb_DefaultValue( cIni, "sefaz.ini" ) )
RETURN Self

METHOD Base() CLASS TSefazProduto
RETURN ::oBase

METHOD Diagnostico() CLASS TSefazProduto
RETURN ::oBase:Diagnostico()

METHOD Retorno( cXml, cOperacao ) CLASS TSefazProduto
RETURN SefazProdutoRetornoPadrao( ::oBase, cXml, cOperacao )

METHOD RetornoResumo( xRet ) CLASS TSefazProduto
RETURN SefazRetornoResumo( hb_DefaultValue( xRet, ::oBase:oRetorno ) )

METHOD RetornoEventoCount( xRet ) CLASS TSefazProduto
RETURN SefazRetornoEventoCount( hb_DefaultValue( xRet, ::oBase:oRetorno ) )

METHOD RetornoEvento( xRet, nIndex ) CLASS TSefazProduto
RETURN SefazRetornoEvento( hb_DefaultValue( xRet, ::oBase:oRetorno ), nIndex )

METHOD Call( cMetodo, aParams, cOperacao ) CLASS TSefazProduto

   LOCAL cXml

   hb_Default( @aParams, {} )

   DO CASE
   CASE Len( aParams ) == 0 ; cXml := __objSendMsg( ::oBase, cMetodo )
   CASE Len( aParams ) == 1 ; cXml := __objSendMsg( ::oBase, cMetodo, aParams[ 1 ] )
   CASE Len( aParams ) == 2 ; cXml := __objSendMsg( ::oBase, cMetodo, aParams[ 1 ], aParams[ 2 ] )
   CASE Len( aParams ) == 3 ; cXml := __objSendMsg( ::oBase, cMetodo, aParams[ 1 ], aParams[ 2 ], aParams[ 3 ] )
   CASE Len( aParams ) == 4 ; cXml := __objSendMsg( ::oBase, cMetodo, aParams[ 1 ], aParams[ 2 ], aParams[ 3 ], aParams[ 4 ] )
   CASE Len( aParams ) == 5 ; cXml := __objSendMsg( ::oBase, cMetodo, aParams[ 1 ], aParams[ 2 ], aParams[ 3 ], aParams[ 4 ], aParams[ 5 ] )
   CASE Len( aParams ) == 6 ; cXml := __objSendMsg( ::oBase, cMetodo, aParams[ 1 ], aParams[ 2 ], aParams[ 3 ], aParams[ 4 ], aParams[ 5 ], aParams[ 6 ] )
   CASE Len( aParams ) == 7 ; cXml := __objSendMsg( ::oBase, cMetodo, aParams[ 1 ], aParams[ 2 ], aParams[ 3 ], aParams[ 4 ], aParams[ 5 ], aParams[ 6 ], aParams[ 7 ] )
   CASE Len( aParams ) == 8 ; cXml := __objSendMsg( ::oBase, cMetodo, aParams[ 1 ], aParams[ 2 ], aParams[ 3 ], aParams[ 4 ], aParams[ 5 ], aParams[ 6 ], aParams[ 7 ], aParams[ 8 ] )
   CASE Len( aParams ) == 9 ; cXml := __objSendMsg( ::oBase, cMetodo, aParams[ 1 ], aParams[ 2 ], aParams[ 3 ], aParams[ 4 ], aParams[ 5 ], aParams[ 6 ], aParams[ 7 ], aParams[ 8 ], aParams[ 9 ] )
   CASE Len( aParams ) == 10 ; cXml := __objSendMsg( ::oBase, cMetodo, aParams[ 1 ], aParams[ 2 ], aParams[ 3 ], aParams[ 4 ], aParams[ 5 ], aParams[ 6 ], aParams[ 7 ], aParams[ 8 ], aParams[ 9 ], aParams[ 10 ] )
   CASE Len( aParams ) == 11 ; cXml := __objSendMsg( ::oBase, cMetodo, aParams[ 1 ], aParams[ 2 ], aParams[ 3 ], aParams[ 4 ], aParams[ 5 ], aParams[ 6 ], aParams[ 7 ], aParams[ 8 ], aParams[ 9 ], aParams[ 10 ], aParams[ 11 ] )
   CASE Len( aParams ) == 12 ; cXml := __objSendMsg( ::oBase, cMetodo, aParams[ 1 ], aParams[ 2 ], aParams[ 3 ], aParams[ 4 ], aParams[ 5 ], aParams[ 6 ], aParams[ 7 ], aParams[ 8 ], aParams[ 9 ], aParams[ 10 ], aParams[ 11 ], aParams[ 12 ] )
   CASE Len( aParams ) == 13 ; cXml := __objSendMsg( ::oBase, cMetodo, aParams[ 1 ], aParams[ 2 ], aParams[ 3 ], aParams[ 4 ], aParams[ 5 ], aParams[ 6 ], aParams[ 7 ], aParams[ 8 ], aParams[ 9 ], aParams[ 10 ], aParams[ 11 ], aParams[ 12 ], aParams[ 13 ] )
   CASE Len( aParams ) == 14 ; cXml := __objSendMsg( ::oBase, cMetodo, aParams[ 1 ], aParams[ 2 ], aParams[ 3 ], aParams[ 4 ], aParams[ 5 ], aParams[ 6 ], aParams[ 7 ], aParams[ 8 ], aParams[ 9 ], aParams[ 10 ], aParams[ 11 ], aParams[ 12 ], aParams[ 13 ], aParams[ 14 ] )
   CASE Len( aParams ) == 15 ; cXml := __objSendMsg( ::oBase, cMetodo, aParams[ 1 ], aParams[ 2 ], aParams[ 3 ], aParams[ 4 ], aParams[ 5 ], aParams[ 6 ], aParams[ 7 ], aParams[ 8 ], aParams[ 9 ], aParams[ 10 ], aParams[ 11 ], aParams[ 12 ], aParams[ 13 ], aParams[ 14 ], aParams[ 15 ] )
   CASE Len( aParams ) == 16 ; cXml := __objSendMsg( ::oBase, cMetodo, aParams[ 1 ], aParams[ 2 ], aParams[ 3 ], aParams[ 4 ], aParams[ 5 ], aParams[ 6 ], aParams[ 7 ], aParams[ 8 ], aParams[ 9 ], aParams[ 10 ], aParams[ 11 ], aParams[ 12 ], aParams[ 13 ], aParams[ 14 ], aParams[ 15 ], aParams[ 16 ] )
   OTHERWISE
      cXml := '<erro text="Metodo com parametros demais para TSefazProduto:Call" />'
   ENDCASE

RETURN ::Retorno( cXml, cOperacao )

METHOD Ambiente( cAmbiente ) CLASS TSefazProduto
   ::oBase:cAmbiente := cAmbiente
RETURN Self

METHOD UF( cUF ) CLASS TSefazProduto
   ::oBase:cUF := cUF
RETURN Self

METHOD CertificadoNome( cCertificado ) CLASS TSefazProduto
   ::oBase:cCertificado := cCertificado
RETURN Self

METHOD TempoEspera( nTempo ) CLASS TSefazProduto
   ::oBase:nTempoEspera := nTempo
RETURN Self

METHOD SoapTimeout( nTimeout ) CLASS TSefazProduto
   ::oBase:nSoapTimeOut := nTimeout
RETURN Self

METHOD NFCe( lNFCe, cIdToken, cCSC ) CLASS TSefazProduto
   ::oBase:lConsumidor := hb_DefaultValue( lNFCe, .T. )
   IF cIdToken != NIL
      ::oBase:cIdToken := cIdToken
   ENDIF
   IF cCSC != NIL
      ::oBase:cCSC := cCSC
   ENDIF
RETURN Self

METHOD Contingencia( lContingencia ) CLASS TSefazProduto
   ::oBase:lContingencia := hb_DefaultValue( lContingencia, .T. )
RETURN Self

METHOD Transporte( cTransporte, lFallback ) CLASS TSefazProduto
   ::oBase:SetTransporte( cTransporte, lFallback )
RETURN Self

METHOD WinHttp( lUse, cPfxFile, cPassword, lIgnoreSsl ) CLASS TSefazProduto
   ::oBase:UseWinHttp( lUse, cPfxFile, cPassword, lIgnoreSsl )
RETURN Self

METHOD Curl( lUse, cCertFile, cPassword, cCertType, cKeyFile ) CLASS TSefazProduto
   ::oBase:UseCurl( lUse, cCertFile, cPassword, cCertType, cKeyFile )
RETURN Self

METHOD Debug( lDebug, cLogDir ) CLASS TSefazProduto
   ::oBase:SetDebug( lDebug, cLogDir )
RETURN Self

METHOD Certificado() CLASS TSefazProduto
RETURN TSefazProdutoCertificado():New( Self )

METHOD NFe() CLASS TSefazProduto
RETURN TSefazProdutoDocumento():New( Self, "NFe" )

METHOD CTe() CLASS TSefazProduto
RETURN TSefazProdutoDocumento():New( Self, "CTe" )

METHOD MDFe() CLASS TSefazProduto
RETURN TSefazProdutoDocumento():New( Self, "MDFe" )

METHOD BPe() CLASS TSefazProduto
RETURN TSefazProdutoDocumento():New( Self, "BPe" )

METHOD Danfe() CLASS TSefazProduto
RETURN TSefazProdutoDanfe():New( Self )

FUNCTION SefazProdutoRetornoPadrao( oBase, cXml, cOperacao )

   LOCAL h := {=>}, hParsed := {=>}

   hb_Default( @cXml, "" )
   hb_Default( @cOperacao, "" )

   IF Empty( cXml ) .AND. oBase != NIL
      cXml := oBase:cXmlRetorno
   ENDIF

   IF ! Empty( cXml )
      hParsed := SefazRetornoParse( cXml )
   ENDIF

   h[ "ok" ]             := SefazProdutoRetornoOk( oBase, hParsed )
   h[ "operacao" ]       := cOperacao
   h[ "status" ]         := SefazProdutoHashGet( hParsed, "status", IIf( oBase == NIL, "", oBase:cStatus ) )
   h[ "motivo" ]         := SefazProdutoHashGet( hParsed, "motivo", IIf( oBase == NIL, "", oBase:cMotivo ) )
   h[ "xml" ]            := cXml
   h[ "recibo" ]         := SefazProdutoHashGet( hParsed, "recibo", "" )
   h[ "protocolo" ]      := SefazProdutoHashGet( hParsed, "protocolo", "" )
   h[ "chave" ]          := SefazProdutoHashGet( hParsed, "chave", "" )
   h[ "codigoErro" ]     := SefazProdutoHashGet( hParsed, "codigoErro", "" )
   h[ "erroFiscal" ]     := ! h[ "ok" ] .AND. ! Empty( h[ "status" ] )
   h[ "erroTecnico" ]    := ! h[ "ok" ] .AND. Empty( h[ "status" ] )
   h[ "transporte" ]     := IIf( oBase == NIL, "", oBase:cUltimoTransporte )
   h[ "httpStatus" ]     := IIf( oBase == NIL, 0, oBase:nWinHttpStatus )
   h[ "erroTransporte" ] := IIf( oBase == NIL, "", oBase:cUltimoErroTransporte )
   h[ "diagnostico" ]    := IIf( oBase == NIL, "", oBase:Diagnostico() )

RETURN h

FUNCTION SefazProdutoHashGet( hHash, cKey, xDefault )
   IF ValType( hHash ) == "H" .AND. hb_HHasKey( hHash, cKey )
      RETURN hHash[ cKey ]
   ENDIF
RETURN xDefault

FUNCTION SefazProdutoRetornoOk( oBase, hParsed )

   LOCAL cStatus := SefazProdutoHashGet( hParsed, "status", IIf( oBase == NIL, "", oBase:cStatus ) )

   cStatus := AllTrim( IIf( ValType( cStatus ) == "N", Str( cStatus ), cStatus ) )

   IF Empty( cStatus )
      RETURN .F.
   ENDIF

RETURN ( "," + cStatus + "," ) $ ",100,101,102,103,104,105,107,128,135,136,201,"

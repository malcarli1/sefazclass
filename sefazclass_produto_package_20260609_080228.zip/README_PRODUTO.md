# SefazClass Produto

Esta pasta e uma nova versao organizada da SefazClass.

A pasta original foi preservada. Esta versao reaproveita a `SefazClass` original como motor fiscal e adiciona uma camada nova, modular, com retorno padronizado.

## Objetivo

Manter a cobertura completa da classe original e facilitar a vida do programador.

Em vez de chamar tudo diretamente em uma classe enorme, a nova API separa por area:

```harbour
oSefaz := TSefazProduto():New()
oSefaz:LoadConfigIni( "sefaz.ini" )
oSefaz:UF( "SP" ):Ambiente( "2" ):Transporte( "WINHTTP", .T. )

hRet := oSefaz:NFe():Status()
hRet := oSefaz:CTe():Status()
hRet := oSefaz:MDFe():Status()
hRet := oSefaz:BPe():Status()
```

## Retorno padronizado

Todas as chamadas da API nova retornam hash:

```harbour
hRet[ "ok" ]
hRet[ "operacao" ]
hRet[ "status" ]
hRet[ "motivo" ]
hRet[ "xml" ]
hRet[ "recibo" ]
hRet[ "protocolo" ]
hRet[ "chave" ]
hRet[ "codigoErro" ]
hRet[ "erroFiscal" ]
hRet[ "erroTecnico" ]
hRet[ "transporte" ]
hRet[ "httpStatus" ]
hRet[ "erroTransporte" ]
hRet[ "diagnostico" ]
```

Para lote com varios eventos:

```harbour
nQtd := oSefaz:RetornoEventoCount( hRet )
FOR nI := 1 TO nQtd
   hEvento := oSefaz:RetornoEvento( hRet, nI )
NEXT

? oSefaz:RetornoResumo( hRet )
```

## Configuracao rapida

```harbour
oSefaz:UF( "SP" )
oSefaz:Ambiente( "1" )              // producao
oSefaz:Ambiente( "2" )              // homologacao
oSefaz:CertificadoNome( "NOME DO CERTIFICADO" )
oSefaz:TempoEspera( 10 )
oSefaz:SoapTimeout( 15000 )
oSefaz:NFCe( .T., "000001", "CSC..." )
oSefaz:Contingencia( .T. )
oSefaz:Debug( .T., "logs" )
```

Transportes:

```harbour
oSefaz:Transporte( "WINHTTP", .T. )
oSefaz:WinHttp( .T., "C:\certificados\empresa.pfx", "senha", .F. )

oSefaz:Transporte( "CURL", .T. )
oSefaz:Curl( .T., "C:\certificados\empresa.pfx", "senha", "P12" )
```

## Certificado

```harbour
hCert := oSefaz:Certificado():A1( "C:\certificados\empresa.pfx", "senha" )
hCert := oSefaz:Certificado():A3( "NOME OU THUMBPRINT" )
hCert := oSefaz:Certificado():Validar()
```

## Documentos

Cada modulo de documento tem metodos padrao:

```harbour
oSefaz:NFe():Status()
oSefaz:NFe():Enviar( cXml )
oSefaz:NFe():RetEnvio( cRecibo )
oSefaz:NFe():Protocolo( cChave )
oSefaz:NFe():Cancelar( ... )
oSefaz:NFe():CartaCorrecao( ... )
oSefaz:NFe():Inutilizar( ... )
oSefaz:NFe():Distribuicao( ... )
oSefaz:NFe():Cadastro( ... )
oSefaz:NFe():Manifestacao( ... )
oSefaz:NFe():GTIN( ... )
oSefaz:NFe():Contingencia( ... )
oSefaz:NFe():Destinadas( ... )
oSefaz:NFe():Download( ... )
oSefaz:NFe():AutorizarXml( ... )
oSefaz:NFe():CancelarSubstituicao( ... )
oSefaz:NFe():DataEntrega( ... )
oSefaz:NFe():AddCancelamento( ... )
oSefaz:NFe():GeraAutorizado( ... )
oSefaz:NFe():GeraEventoAutorizado( ... )
```

Tambem existem:

```harbour
oSefaz:CTe()
oSefaz:MDFe()
oSefaz:BPe()
```

Metodos especiais por documento:

```harbour
oSefaz:CTe():Entrega( ... )
oSefaz:CTe():InsucessoEntrega( ... )
oSefaz:CTe():CancelarEntrega( ... )
oSefaz:CTe():CancelarInsucessoEntrega( ... )
oSefaz:CTe():Desacordo( ... )

oSefaz:MDFe():EmAberto( ... )
oSefaz:MDFe():Encerramento( ... )
oSefaz:MDFe():Condutor( ... )
oSefaz:MDFe():Pagamento( ... )
```

Se existir algum metodo antigo que o programador queira chamar literalmente, use:

```harbour
hRet := oSefaz:NFe():Call( "NFeEventoDataEntrega", { ... } )
```

Isso garante que a cobertura completa da `SefazClass` original continue acessivel, mesmo para apelidos/compatibilidade.

## DANFE simplificado

```harbour
cHtml := oSefaz:Danfe():SimplificadoHtml( cXml )
cTxt  := oSefaz:Danfe():SimplificadoTexto( cXml )
oSefaz:Danfe():SimplificadoSalvarHtml( "danfe_simplificado.html", cXml )
```

## Build

```bat
set PATH=C:\xbase\bcc582\Bin;C:\xbase\harbour_1608\bin;%PATH%
set HB_COMPILER=bcc
hbmk2 -comp=bcc sefazclass_produto_core.hbp
```

Ou:

```bat
tests\compilar_produto.bat
```

## Demos

```bat
tests\demo_produto_diagnostico.exe
tests\demo_produto_danfe.exe nfe_teste_danfe_simplificado.xml
tests\demo_produto_status.exe sefaz.ini
```

`demo_produto_status` faz chamada real e precisa de certificado/ambiente configurado.

## Importante

Esta versao e uma camada nova. A `SefazClass` original continua disponivel em:

```harbour
oOriginal := oSefaz:Base()
```

Assim nada da cobertura original fica perdido.

#include "sefazclass.ch"

FUNCTION SefazRetornoParse( cXml )

   LOCAL hRet := hb_Hash(), cWork, cFault, cBase, aEventos := {}

   cWork := SefazRetornoNormalizeXml( hb_DefaultValue( cXml, "" ) )
   cBase := SefazRetornoMainBlock( cWork )

   hRet[ "xml" ] := cXml
   hRet[ "xmlNormalizado" ] := cWork
   hRet[ "tipo" ] := SefazRetornoTipo( cBase )
   hRet[ "status" ] := 0
   hRet[ "motivo" ] := ""
   hRet[ "ok" ] := .F.
   hRet[ "recibo" ] := ""
   hRet[ "protocolo" ] := ""
   hRet[ "chave" ] := ""
   hRet[ "codigoErro" ] := ""
   hRet[ "soapFault" ] := .F.
   hRet[ "eventos" ] := aEventos

   cFault := XmlNode( cWork, "Fault", .T. )
   IF ! Empty( cFault )
      hRet[ "soapFault" ] := .T.
      hRet[ "tipo" ] := "SOAPFAULT"
      hRet[ "status" ] := 999
      hRet[ "motivo" ] := SefazRetornoFirstNode( cFault, { "faultstring", "Text", "Reason", "Message" } )
      hRet[ "codigoErro" ] := "SOAP_FAULT"
      IF Empty( hRet[ "motivo" ] )
         hRet[ "motivo" ] := "SOAP Fault"
      ENDIF
      RETURN hRet
   ENDIF

   IF Empty( cWork )
      hRet[ "status" ] := 999
      hRet[ "motivo" ] := "Retorno vazio"
      hRet[ "codigoErro" ] := "RETORNO_VAZIO"
      RETURN hRet
   ENDIF

   IF "*ERRO*" $ Upper( cWork ) .OR. "<erro" $ Lower( cWork )
      hRet[ "status" ] := 999
      hRet[ "motivo" ] := SefazRetornoErroText( cWork )
      hRet[ "codigoErro" ] := SefazRetornoCodigoErro( hRet[ "motivo" ] )
      RETURN hRet
   ENDIF

   hRet[ "status" ] := Val( SefazRetornoFirstNode( cBase, { "cStat", "cdResposta" } ) )
   hRet[ "motivo" ] := SefazRetornoFirstNode( cBase, { "xMotivo", "descResposta", "descricao", "msg", "mensagem" } )
   hRet[ "recibo" ] := SefazRetornoFirstNode( cBase, { "nRec", "recibo", "numeroRecibo" } )
   hRet[ "protocolo" ] := SefazRetornoFirstNode( cBase, { "nProt", "protocolo", "protocoloEnvio", "nrRecibo", "nRecEvt" } )
   hRet[ "chave" ] := SefazRetornoFirstNode( cBase, { "chNFe", "chCTe", "chMDFe", "chBPe", "chDFe" } )

   SefazRetornoAddEventos( @aEventos, cBase, "retEvento" )
   SefazRetornoAddEventos( @aEventos, cBase, "procEventoNFe" )
   SefazRetornoAddEventos( @aEventos, cBase, "procEventoCTe" )
   SefazRetornoAddEventos( @aEventos, cBase, "procEventoMDFe" )
   SefazRetornoAddEventos( @aEventos, cBase, "procEventoBPe" )
   SefazRetornoAddProtocolos( @aEventos, cBase, "protNFe" )
   SefazRetornoAddProtocolos( @aEventos, cBase, "protCTe" )
   SefazRetornoAddProtocolos( @aEventos, cBase, "protMDFe" )
   SefazRetornoAddProtocolos( @aEventos, cBase, "protBPe" )

   IF Empty( hRet[ "protocolo" ] ) .AND. Len( aEventos ) > 0
      hRet[ "protocolo" ] := aEventos[ 1 ][ "protocolo" ]
   ENDIF
   IF Empty( hRet[ "chave" ] ) .AND. Len( aEventos ) > 0
      hRet[ "chave" ] := aEventos[ 1 ][ "chave" ]
   ENDIF

   hRet[ "eventCount" ] := Len( aEventos )
   hRet[ "ok" ] := SefazRetornoStatusOk( hRet[ "status" ] )
   IF ! hRet[ "ok" ]
      hRet[ "codigoErro" ] := SefazRetornoCodigoErro( hRet[ "motivo" ] )
      IF Empty( hRet[ "codigoErro" ] )
         hRet[ "codigoErro" ] := "SEFAZ_REJEICAO"
      ENDIF
   ENDIF

RETURN hRet

FUNCTION SefazRetornoAplicar( Self, cXml )

   LOCAL hRet := SefazRetornoParse( cXml )

   IF hRet[ "status" ] != 0
      Self:nStatus := hRet[ "status" ]
   ENDIF
   IF ! Empty( hRet[ "motivo" ] )
      Self:cMotivo := hRet[ "motivo" ]
   ENDIF
   IF ! Empty( hRet[ "recibo" ] )
      Self:cRecibo := hRet[ "recibo" ]
   ENDIF
   IF ! Empty( hRet[ "protocolo" ] )
      Self:cXmlProtocolo := cXml
   ENDIF
   Self:oRetorno := hRet
   Self:aRetornoEventos := hRet[ "eventos" ]

RETURN hRet

FUNCTION SefazRetornoEventoCount( xRet )

   LOCAL hRet := SefazRetornoAsHash( xRet )
RETURN Len( hRet[ "eventos" ] )

FUNCTION SefazRetornoEvento( xRet, nIndex )

   LOCAL hRet := SefazRetornoAsHash( xRet )

   hb_Default( @nIndex, 1 )
   IF nIndex == 0
      nIndex := 1
   ENDIF
   IF nIndex < 1 .OR. nIndex > Len( hRet[ "eventos" ] )
      RETURN hb_Hash()
   ENDIF
RETURN hRet[ "eventos" ][ nIndex ]

FUNCTION SefazRetornoSucesso( xRet )

   LOCAL hRet := SefazRetornoAsHash( xRet ), hEvt

   IF ! hRet[ "ok" ]
      RETURN .F.
   ENDIF
   FOR EACH hEvt IN hRet[ "eventos" ]
      IF ! hEvt[ "ok" ]
         RETURN .F.
      ENDIF
   NEXT
RETURN .T.

FUNCTION SefazRetornoResumo( xRet )

   LOCAL hRet := SefazRetornoAsHash( xRet )
RETURN AllTrim( Str( hRet[ "status" ] ) ) + " - " + hRet[ "motivo" ] + ;
   IIf( Empty( hRet[ "recibo" ] ), "", " Recibo: " + hRet[ "recibo" ] ) + ;
   IIf( Empty( hRet[ "protocolo" ] ), "", " Protocolo: " + hRet[ "protocolo" ] ) + ;
   IIf( hRet[ "eventCount" ] == 0, "", " Eventos: " + AllTrim( Str( hRet[ "eventCount" ] ) ) )

STATIC FUNCTION SefazRetornoAsHash( xRet )
RETURN IIf( ValType( xRet ) == "H", xRet, SefazRetornoParse( hb_DefaultValue( xRet, "" ) ) )

STATIC FUNCTION SefazRetornoNormalizeXml( cXml )

   LOCAL cWork := hb_DefaultValue( cXml, "" )
   LOCAL aPrefix := { "soap:", "soap12:", "soapenv:", "env:", "S:", "nfe:", "cte:", "mdfe:", "bpe:", "ns1:", "ns2:", "ns3:", "ns4:" }
   LOCAL cPrefix

   cWork := XmlTransform( cWork )
   FOR EACH cPrefix IN aPrefix
      cWork := StrTran( cWork, "<" + cPrefix, "<" )
      cWork := StrTran( cWork, "</" + cPrefix, "</" )
   NEXT
RETURN cWork

STATIC FUNCTION SefazRetornoMainBlock( cXml )

   LOCAL cBody, cResult
   LOCAL aNodes := { "Body", "EnviarLoteEventosResult", "ConsultarLoteEventosResult", "nfeResultMsg", "cteResultMsg", "mdfeResultMsg", "bpeResultMsg" }
   LOCAL cNode

   cResult := cXml
   cBody := XmlNode( cResult, "Body" )
   IF ! Empty( cBody )
      cResult := cBody
   ENDIF
   FOR EACH cNode IN aNodes
      cBody := XmlNode( cResult, cNode )
      IF ! Empty( cBody )
         cResult := cBody
      ENDIF
   NEXT
RETURN cResult

STATIC FUNCTION SefazRetornoTipo( cXml )

   LOCAL aMap := { ;
      { "retEnviNFe", "ENVIO_NFE" }, { "retConsReciNFe", "CONSULTA_RECIBO_NFE" }, ;
      { "retConsSitNFe", "CONSULTA_PROTOCOLO_NFE" }, { "retEnvEvento", "EVENTO_NFE" }, ;
      { "retInutNFe", "INUTILIZACAO_NFE" }, { "retCTe", "ENVIO_CTE" }, ;
      { "retConsReciCTe", "CONSULTA_RECIBO_CTE" }, { "retConsSitCTe", "CONSULTA_PROTOCOLO_CTE" }, ;
      { "retEventoCTe", "EVENTO_CTE" }, { "retInutCTe", "INUTILIZACAO_CTE" }, ;
      { "retMDFe", "ENVIO_MDFE" }, { "retConsReciMDFe", "CONSULTA_RECIBO_MDFE" }, ;
      { "retConsSitMDFe", "CONSULTA_PROTOCOLO_MDFE" }, { "retEventoMDFe", "EVENTO_MDFE" }, ;
      { "retBPe", "ENVIO_BPE" }, { "retConsSitBPe", "CONSULTA_PROTOCOLO_BPE" }, ;
      { "retornoProcessamentoLoteEventos", "RETORNO_LOTE_EVENTOS" }, ;
      { "retornoEvento", "RETORNO_EVENTO" } }
   LOCAL aItem

   FOR EACH aItem IN aMap
      IF "<" + aItem[ 1 ] $ cXml .OR. "<" + aItem[ 1 ] + " " $ cXml
         RETURN aItem[ 2 ]
      ENDIF
   NEXT
RETURN "RETORNO"

STATIC FUNCTION SefazRetornoFirstNode( cXml, aTags )

   LOCAL cTag
   FOR EACH cTag IN aTags
      IF ! Empty( XmlNode( cXml, cTag ) )
         RETURN XmlToString( XmlNode( cXml, cTag ) )
      ENDIF
   NEXT
RETURN ""

STATIC FUNCTION SefazRetornoErroText( cXml )

   LOCAL cText := XmlElement( cXml, "text" )
   IF Empty( cText )
      cText := XmlNode( cXml, "xml" )
   ENDIF
   IF Empty( cText )
      cText := cXml
   ENDIF
RETURN XmlToString( cText )

STATIC FUNCTION SefazRetornoAddEventos( aEventos, cXml, cNode )

   LOCAL aNodes := MultipleNodeToArray( cXml, cNode, .T. )
   LOCAL cItem, hEvt

   FOR EACH cItem IN aNodes
      hEvt := SefazRetornoEventoHash( cItem )
      IF hEvt[ "status" ] != 0 .OR. ! Empty( hEvt[ "chave" ] ) .OR. ! Empty( hEvt[ "protocolo" ] )
         AAdd( aEventos, hEvt )
      ENDIF
   NEXT
RETURN NIL

STATIC FUNCTION SefazRetornoAddProtocolos( aEventos, cXml, cNode )

   LOCAL aNodes := MultipleNodeToArray( cXml, cNode, .T. )
   LOCAL cItem, hEvt

   FOR EACH cItem IN aNodes
      hEvt := SefazRetornoProtocoloHash( cItem )
      IF hEvt[ "status" ] != 0 .OR. ! Empty( hEvt[ "chave" ] ) .OR. ! Empty( hEvt[ "protocolo" ] )
         AAdd( aEventos, hEvt )
      ENDIF
   NEXT
RETURN NIL

STATIC FUNCTION SefazRetornoEventoHash( cXml )

   LOCAL hEvt := hb_Hash()
   LOCAL cInf := XmlNode( cXml, "infEvento", .T. )
   IF Empty( cInf )
      cInf := cXml
   ENDIF
   hEvt[ "tipo" ] := "EVENTO"
   hEvt[ "status" ] := Val( SefazRetornoFirstNode( cXml, { "cStat", "cdResposta" } ) )
   hEvt[ "motivo" ] := SefazRetornoFirstNode( cXml, { "xMotivo", "descResposta", "descricao" } )
   hEvt[ "ok" ] := SefazRetornoStatusOk( hEvt[ "status" ] )
   hEvt[ "chave" ] := SefazRetornoFirstNode( cXml, { "chNFe", "chCTe", "chMDFe", "chBPe", "chDFe" } )
   hEvt[ "protocolo" ] := SefazRetornoFirstNode( cXml, { "nProt", "protocolo", "nrRecibo", "nRecEvt" } )
   hEvt[ "tpEvento" ] := XmlNode( cInf, "tpEvento" )
   hEvt[ "nSeqEvento" ] := XmlNode( cInf, "nSeqEvento" )
   hEvt[ "dhRegEvento" ] := XmlNode( cInf, "dhRegEvento" )
   hEvt[ "orgao" ] := SefazRetornoFirstNode( cXml, { "cOrgao", "cOrgaoAutor" } )
RETURN hEvt

STATIC FUNCTION SefazRetornoProtocoloHash( cXml )

   LOCAL hEvt := hb_Hash()
   LOCAL cInf := XmlNode( cXml, "infProt", .T. )
   IF Empty( cInf )
      cInf := cXml
   ENDIF
   hEvt[ "tipo" ] := "PROTOCOLO"
   hEvt[ "status" ] := Val( XmlNode( cInf, "cStat" ) )
   hEvt[ "motivo" ] := XmlToString( XmlNode( cInf, "xMotivo" ) )
   hEvt[ "ok" ] := SefazRetornoStatusOk( hEvt[ "status" ] )
   hEvt[ "chave" ] := SefazRetornoFirstNode( cInf, { "chNFe", "chCTe", "chMDFe", "chBPe", "chDFe" } )
   hEvt[ "protocolo" ] := XmlNode( cInf, "nProt" )
   hEvt[ "dhRecbto" ] := XmlNode( cInf, "dhRecbto" )
   hEvt[ "digVal" ] := XmlNode( cInf, "digVal" )
RETURN hEvt

STATIC FUNCTION SefazRetornoStatusOk( nStatus )

   LOCAL aOk := { 100, 101, 102, 103, 104, 105, 128, 135, 136, 155, 201 }
RETURN hb_AScan( aOk, { | n | n == nStatus } ) != 0

STATIC FUNCTION SefazRetornoCodigoErro( cMotivo )

   LOCAL cText := Upper( hb_DefaultValue( cMotivo, "" ) )

   DO CASE
   CASE Empty( cText )
      RETURN ""
   CASE "CERTIFICADO" $ cText .OR. "PERMISSION" $ cText .OR. "PRIVATE KEY" $ cText
      RETURN "CERTIFICADO"
   CASE "NO OPEN" $ cText .OR. "SEND FALHOU" $ cText .OR. "ENDERECO" $ cText .OR. "SOAP ACTION" $ cText
      RETURN "COMUNICACAO"
   CASE "BODY" $ cText .AND. "IDENTIFICADO" $ cText
      RETURN "SOAP_BODY"
   CASE "ASSINATURA" $ cText .OR. "SIGN" $ cText
      RETURN "ASSINATURA"
   CASE "SCHEMA" $ cText .OR. "VALIDA" $ cText
      RETURN "VALIDACAO_XML"
   CASE "REJEI" $ cText
      RETURN "SEFAZ_REJEICAO"
   ENDCASE
RETURN ""

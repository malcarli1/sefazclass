#include "hbclass.ch"

CREATE CLASS TSefazProdutoDocumento

   DATA oProduto
   DATA cDoc

   METHOD New( oProduto, cDoc )
   METHOD Status()
   METHOD Enviar( cXml )
   METHOD RetEnvio( cRecibo )
   METHOD Protocolo( cChave )
   METHOD Inutilizar( ... )
   METHOD Evento( ... )
   METHOD Cancelar( ... )
   METHOD CartaCorrecao( ... )
   METHOD Distribuicao( ... )
   METHOD Cadastro( ... )
   METHOD Manifestacao( ... )
   METHOD GTIN( ... )
   METHOD EmAberto( ... )
   METHOD Call( cMetodo, aParams )

ENDCLASS

METHOD New( oProduto, cDoc ) CLASS TSefazProdutoDocumento
   ::oProduto := oProduto
   ::cDoc     := cDoc
RETURN Self

METHOD Status() CLASS TSefazProdutoDocumento
RETURN ::Call( ::cDoc + "Status", { ::oProduto:oBase:cUF, ::oProduto:oBase:cCertificado, ::oProduto:oBase:cAmbiente } )

METHOD Enviar( cXml ) CLASS TSefazProdutoDocumento
RETURN ::Call( ::cDoc + "Envio", { cXml } )

METHOD RetEnvio( cRecibo ) CLASS TSefazProdutoDocumento
RETURN ::Call( ::cDoc + "RetEnvio", { cRecibo } )

METHOD Protocolo( cChave ) CLASS TSefazProdutoDocumento
RETURN ::Call( ::cDoc + "Protocolo", { cChave } )

METHOD Inutilizar( ... ) CLASS TSefazProdutoDocumento
RETURN ::Call( ::cDoc + "Inutiliza", hb_AParams() )

METHOD Evento( ... ) CLASS TSefazProdutoDocumento
RETURN ::Call( ::cDoc + "Evento", hb_AParams() )

METHOD Cancelar( ... ) CLASS TSefazProdutoDocumento
RETURN ::Call( ::cDoc + "EventoCancela", hb_AParams() )

METHOD CartaCorrecao( ... ) CLASS TSefazProdutoDocumento
RETURN ::Call( ::cDoc + "EventoCarta", hb_AParams() )

METHOD Distribuicao( ... ) CLASS TSefazProdutoDocumento
RETURN ::Call( ::cDoc + "Distribuicao", hb_AParams() )

METHOD Cadastro( ... ) CLASS TSefazProdutoDocumento
RETURN ::Call( ::cDoc + "Cadastro", hb_AParams() )

METHOD Manifestacao( ... ) CLASS TSefazProdutoDocumento
RETURN ::Call( ::cDoc + "EventoManifestacao", hb_AParams() )

METHOD GTIN( ... ) CLASS TSefazProdutoDocumento
RETURN ::Call( ::cDoc + "GTIN", hb_AParams() )

METHOD EmAberto( ... ) CLASS TSefazProdutoDocumento
RETURN ::Call( ::cDoc + "EmAberto", hb_AParams() )

METHOD Call( cMetodo, aParams ) CLASS TSefazProdutoDocumento
RETURN ::oProduto:Call( cMetodo, aParams, ::cDoc + "." + cMetodo )


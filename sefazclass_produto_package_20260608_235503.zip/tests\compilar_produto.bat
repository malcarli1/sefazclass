@echo off
setlocal
set PATH=C:\xbase\bcc582\Bin;C:\xbase\harbour_1608\bin;%PATH%
set HB_COMPILER=bcc

cd ..
hbmk2 -comp=bcc sefazclass_produto_core.hbp || exit /b 1
cd tests
hbmk2 -comp=bcc demo_produto_diagnostico.hbp || exit /b 1
hbmk2 -comp=bcc demo_produto_danfe.hbp || exit /b 1
hbmk2 -comp=bcc demo_produto_status.hbp || exit /b 1

echo.
echo SefazClass Produto compilada com sucesso.
endlocal

